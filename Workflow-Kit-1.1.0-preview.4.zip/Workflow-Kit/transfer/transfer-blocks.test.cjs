const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const vm = require("node:vm");

const source = fs.readFileSync(path.join(__dirname, "transfer-blocks.js"), "utf8");
const root = "C:/example";
const old = {id:"old", hostId:"local", kind:"codex", cwd:root, title:"Test_3", projectId:"test-project"};
const newChat = {id:"new", hostId:"local", kind:"codex", cwd:root, title:"Test_4", projectId:"test-project"};
const confirmation = "Задача: Архивный поиск\nТочка: Кадр 125\nФакт: Строка из проектного файла.";
const commandAt = 1700000000000;

async function simulate(options = {}) {
  const cache = new Map();
  const actions = [];
  let clock = commandAt;
  let oldPinned = true;
  let newPinned = false;
  const assemble = vm.runInNewContext(source, {Date:{now:()=>clock}});
  const mock = async (name, args) => {
    actions.push({name,args});
    switch (name) {
      case "list_projects":
        return {projects:[{path:root,projectKind:"local",hostId:"local",projectId:old.projectId}]};
      case "read_thread":
        if (args.threadId === old.id) return {thread:old,turns:[{startedAt:commandAt/1000,items:[
          {type:"userMessage",content:[{type:"text",text:options.commandText??"Переноси. Проверь кадр 200."}]}
        ]}]};
        clock = commandAt + 18000;
        return {thread:newChat,turns:[{id:options.mismatchedTurn?"wrong":"first",status:"completed",completedAt:commandAt/1000+13,
          items:[{type:"agentMessage",phase:"final_answer",text:options.invalidFact?confirmation.replace("Строка из проектного файла.","Недостоверный факт."):confirmation}]}]};
      case "list_threads":
        if (args.mode === "history") return {threads:[],nextCursor:null};
        return {threads:[],pinnedThreads:[...(newPinned?[newChat]:[]),...(oldPinned?[old]:[])]};
      case "create_thread":
        clock = commandAt + 5000;
        return {threadId:newChat.id,hostId:"local",createdAt:clock/1000};
      case "navigate_to_codex_page":
        return {navigated:true};
      case "wait_threads":
        clock = commandAt + 17000;
        return {polls:[{thread:{id:newChat.id},latestTurn:{id:"first",status:"completed",completedAt:commandAt/1000+13},
          latestAssistantMessage:{turnId:"first",phase:"final_answer",text:confirmation.replaceAll("\n"," ")}}]};
      case "move_thread_to_sidebar_section":
        if (args.threadId === newChat.id) newPinned = !options.failedPin;
        else oldPinned = false;
        clock = commandAt + 20000;
        return {threadId:args.threadId,sectionId:args.sectionId};
      case "send_message_to_thread":
        if (options.unknownSend) throw Error("Uncertain delivery");
        return {threadId:newChat.id};
      default:
        throw Error("Unexpected tool: " + name);
    }
  };
  const tools = new Proxy({
    exec_command: async args => {
      actions.push({name:"local_snapshot"});
      assert.ok(!args.cmd.includes("$source=Get-Item"),"Block 2 should reuse evidence selected during preparation");
      return {exit_code:0,output:JSON.stringify({matches:["Ветка"],matchCount:1,
        evidence: options.noEvidence ? "" : "Строка из проектного файла.",
        evidenceKind: options.largeSource ? "handoff_line" : "linked_file",
        evidenceName: options.largeSource ? null : "work.md"})};
    }
  }, {get: (target,key) => target[key] ?? (async args => ({structuredContent:await mock(key.replace("mcp__codex_app__",""),args)}))});
  const flow = assemble({tools,store:(k,v)=>cache.set(k,structuredClone(v)),load:k=>cache.get(k)});
  const pre = await flow.prepare({oldId:old.id,hostId:"local",cwd:root,handoffPath:root+"/HANDOFF.md",activePrefix:"Ветка",model:"example",commandConfirmed:options.confirmed??true});
  assert.equal(pre.status,"checked");
  const plan = {ownerAuthorized:true,stopVerified:!options.noStop,task:"Архивный поиск",point:"Кадр 125",
    continueAuthorized:options.continueAuthorized===true,...(options.task===undefined?{}:{continuationTask:options.task})};
  const result = await flow.transfer(old.id,plan);
  const resumed = options.resume ? await flow.resume(old.id) : null;
  return {result,actions,oldPinned,resumed};
}

test("flattened wait preview does not replace original three lines; all five timings are recorded", async () => {
  const {result,actions} = await simulate();
  assert.equal(result.status,"complete");
  assert.equal(result.secondsToCreate,5);
  assert.deepEqual({...result.timings},{
    commandStartedAt:commandAt,chatCreatedAt:commandAt+5000,confirmationReadyAt:commandAt+13000,
    confirmationReceivedAt:commandAt+18000,pinsVerifiedAt:commandAt+20000
  });
  assert.equal(actions.some(x=>x.name==="send_message_to_thread"),false);
});

test("authorized new task is sent verbatim once, after both sidebar checks, with no wait for work", async () => {
  const task = "Проверь кадр 200.\nСверь имя по оригиналу.";
  const {result,actions} = await simulate({continueAuthorized:true,task,resume:true});
  assert.equal(result.continuationStatus,"submitted");
  const sends = actions.filter(x=>x.name==="send_message_to_thread");
  assert.equal(sends.length,1);
  assert.equal(sends[0].args.prompt,task);
  assert.deepEqual(actions.slice(-3).map(x=>x.name),["move_thread_to_sidebar_section","list_threads","send_message_to_thread"]);
});

test("plain continue retains the task and next step", async () => {
  const {result,actions} = await simulate({continueAuthorized:true});
  assert.equal(result.continuationStatus,"submitted");
  assert.match(actions.at(-1).args.prompt,/Кадр 125/);
});

test("new work without authorization does not create or send", async () => {
  const {result,actions} = await simulate({task:"Неявное поручение"});
  assert.equal(result.status,"invalid_plan");
  assert.equal(actions.some(x=>x.name==="create_thread"||x.name==="send_message_to_thread"),false);
});

for (const option of ["mismatchedTurn","invalidFact","failedPin","noStop"]) {
  test(option + " leaves the old pin and never sends work", async () => {
    const {result,actions,oldPinned} = await simulate({[option]:true,continueAuthorized:true,task:"Новое"});
    assert.notEqual(result.status,"complete");
    assert.equal(oldPinned,true);
    assert.equal(actions.some(x=>x.name==="send_message_to_thread"),false);
  });
}

test("an uncertain continuation dispatch is not retried on resume", async () => {
  const {result,actions,resumed} = await simulate({continueAuthorized:true,task:"Новое",unknownSend:true,resume:true});
  assert.equal(result.status,"complete");
  assert.equal(resumed.continuationStatus,"unconfirmed");
  assert.equal(actions.filter(x=>x.name==="send_message_to_thread").length,1);
});
test("a large summary uses the active HANDOFF line and preserves all three prompt fields", async () => {
  const {result,actions} = await simulate({largeSource:true});
  assert.equal(result.status,"complete");
  assert.equal(result.evidenceKind,"handoff_line");
  const create = actions.find(x=>x.name==="create_thread");
  assert.match(create.args.prompt,/факт из строки активной ветки/);
  assert.deepEqual(create.args.prompt.split("\n\n").map(line=>line.split(":")[0]),["Задача","HANDOFF","Точка"]);
  assert.equal(actions.filter(x=>x.name==="local_snapshot").length,1);
});
test("a confirmed transfer turn can start with Спасибо or Хорошо", async () => {
  const {result} = await simulate({commandText:"Хорошо, переноси."});
  assert.equal(result.timings.commandStartedAt,commandAt);
});
test("a turn that merely mentions transfer does not supply a timing mark", async () => {
  const {result} = await simulate({commandText:"Обсудим, как работает слово «Переноси».",confirmed:false});
  assert.equal(result.timings.commandStartedAt,null);
});
test("absence of eligible evidence blocks creation", async () => {
  const {result,actions} = await simulate({noEvidence:true});
  assert.equal(result.status,"evidence_unavailable");
  assert.equal(actions.some(x=>x.name==="create_thread"),false);
});
