import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

KIT = Path(__file__).resolve().parents[1]


class ReleaseLifecycle(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        base = Path(temp.name)
        self.home = base / "Test profile"
        self.project = base / "Projects" / "Example"
        self.project.mkdir(parents=True)
        self.source = base / "Unpacked"
        shutil.copytree(KIT, self.source)
        self.profile = self.home / ".codex"

    def install(self, *args, source=None):
        source = source or self.source
        return subprocess.run(
            [sys.executable, "-B", str(source / "install.py"), "--tool", "codex",
             "--home", str(self.home), "--root", str(self.project.parent), *args],
            capture_output=True, text=True, encoding="utf-8", cwd=self.project,
        )

    def test_stable_source_survives_removal_of_download(self):
        preview = self.install("--dry-run")
        self.assertEqual(preview.returncode, 0, preview.stderr)
        self.assertFalse(self.home.exists())
        result = self.install("--project", str(self.project))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        config = json.loads((self.profile / "memory-kit.json").read_text(encoding="utf-8"))
        installed = Path(config["kit_dir"])
        self.assertTrue(installed.is_relative_to(self.profile), str(installed))
        self.source.rename(self.source.with_name("No longer unpacked"))
        self.assertTrue((installed / "docs/MODEL-ROUTING.md").is_file())
        self.assertIn(installed.as_posix(), (self.profile / "AGENTS.md").read_text(encoding="utf-8"))
        result = self.install("--check", source=installed)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_invalid_package_manifest_is_rejected_before_write(self):
        (self.source / "SHA256SUMS.json").write_text(
            json.dumps({"install.py": "0" * 64}), encoding="utf-8"
        )
        result = self.install()
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Контрольная сумма", result.stdout + result.stderr)
        self.assertFalse(self.home.exists())

    def test_archive_uses_only_its_installed_profile(self):
        for label in ("one", "two"):
            root = self.home / label / ".codex"
            memory = root.parent / "memory"
            (root / "scripts").mkdir(parents=True)
            (root / "memory-kit.json").write_text(
                json.dumps({"tool": "codex", "central": str(memory / "central")}), encoding="utf-8"
            )
            script = root / "scripts/session_archive.py"
            shutil.copyfile(KIT / "scripts/session_archive.py", script)
            probe = subprocess.run(
                [sys.executable, "-B", "-c",
                 "import json, runpy, sys; r=runpy.run_path(sys.argv[1]); print(json.dumps([r['SOURCE'],r['CODEX_SOURCE']]))",
                 str(script)], capture_output=True, text=True, encoding="utf-8",
            )
            self.assertEqual(probe.returncode, 0, probe.stderr)
            claude, codex = json.loads(probe.stdout)
            self.assertIsNone(claude)
            self.assertEqual(Path(codex), root / "sessions")
            session = root / "sessions/2026/11/21"
            session.mkdir(parents=True)
            identity = "11111111-aaaa-bbbb-cccc-000000000001" if label == "one" else "11111111-aaaa-bbbb-cccc-000000000002"
            rows = [
                {"timestamp": "2026-11-21T10:00:00Z", "type": "session_meta",
                 "payload": {"id": identity, "source": "cli", "cwd": str(self.project)}},
                {"timestamp": "2026-11-21T10:01:00Z", "type": "response_item",
                 "payload": {"type": "message", "role": "user",
                             "content": [{"type": "input_text", "text": "Fixture from " + label}]}},
            ]
            data_file = session / ("rollout-2026-11-21T10-00-00-" + identity + ".jsonl")
            data_file.write_text("\n".join(map(json.dumps, rows)) + "\n", encoding="utf-8")
            old = 1700000000
            os.utime(data_file, (old, old))
        for label in ("one", "two"):
            isolated = self.home / label
            archive = subprocess.run([sys.executable, "-B", str(isolated / ".codex/scripts/session_archive.py")],
                                     capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(archive.returncode, 0, archive.stderr)
            results = list((isolated / "memory/sessions").rglob("*.md"))
            self.assertEqual(len(results), 1, archive.stdout)
            self.assertIn("Fixture from " + label, results[0].read_text(encoding="utf-8"))

    def test_update_preserves_an_edited_installed_instruction(self):
        self.assertEqual(self.install().returncode, 0)
        doc = self.profile / "workflow-kit-package/docs/MODEL-ROUTING.md"
        custom = doc.read_bytes() + b"\nCustom fixture\n"
        doc.write_bytes(custom)
        failed = self.install()
        self.assertNotEqual(failed.returncode, 0)
        self.assertEqual(doc.read_bytes(), custom)

    def test_transfer_is_available_from_the_installed_package(self):
        result = self.install()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        package = self.profile / "workflow-kit-package"
        runner = package / "transfer/transfer-blocks.js"
        self.assertTrue(runner.is_file())
        self.assertEqual(runner.read_bytes(), (KIT / "transfer/transfer-blocks.js").read_bytes())
        rules = (self.profile / "AGENTS.md").read_text(encoding="utf-8")
        self.assertIn(runner.as_posix(), rules)
        self.assertIn((package / "docs/TRANSFER.md").as_posix(), rules)

    def test_interruption_leaves_recoverable_prior_state(self):
        result = self.install("--project", str(self.project))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        hook = self.profile / "hooks/session-start-context.js"
        h0 = hook.read_bytes()
        cfg = self.profile / "memory-kit.json"
        data = json.loads(cfg.read_text(encoding="utf-8"))
        data["sync_on_start"] = False
        cfg.write_text(json.dumps(data), encoding="utf-8")
        cfg_before = cfg.read_bytes()
        hooks_before = (self.profile / "hooks.json").read_bytes()
        note = self.project / "HANDOFF.md"
        note_before = note.read_bytes()
        personal = Path(data["central"]) / "personal.md"
        personal.write_text("local fixture", encoding="utf-8")
        version = self.source / "hooks/session-start-context.js"
        version.write_bytes(h0 + b"\n// fixture update\n")
        manifest = self.source / "SHA256SUMS.json"
        if manifest.is_file():
            checksums = json.loads(manifest.read_text(encoding="utf-8"))
            checksums["hooks/session-start-context.js"] = hashlib.sha256(version.read_bytes()).hexdigest()
            manifest.write_text(json.dumps(checksums), encoding="utf-8")

        driver = """
import os, runpy, sys
install = runpy.run_path(sys.argv[1])
writer = install["Doer"].copy
def interrupt(self, source, destination):
    result = writer(self, source, destination)
    if destination.replace(chr(92), "/").endswith("/.codex/hooks/session-start-context.js"):
        os._exit(87)
    return result
install["Doer"].copy = interrupt
sys.argv = [sys.argv[1], *sys.argv[2:]]
install["main"]()
"""
        job = subprocess.run(
            [sys.executable, "-B", "-c", driver, str(self.source / "install.py"), "--tool", "codex",
             "--home", str(self.home), "--root", str(self.project.parent)],
            capture_output=True, text=True, encoding="utf-8", cwd=self.project,
        )
        self.assertEqual(job.returncode, 87, job.stdout + job.stderr)
        self.assertNotEqual(hook.read_bytes(), h0)
        reverted = self.install("--rollback")
        self.assertEqual(reverted.returncode, 0, reverted.stdout + reverted.stderr)
        self.assertEqual(hook.read_bytes(), h0)
        self.assertEqual(cfg.read_bytes(), cfg_before)
        self.assertEqual((self.profile / "hooks.json").read_bytes(), hooks_before)
        self.assertEqual(note.read_bytes(), note_before)
        self.assertEqual(personal.read_text(encoding="utf-8"), "local fixture")
        updated = self.install()
        self.assertEqual(updated.returncode, 0, updated.stdout + updated.stderr)
        self.assertEqual(hook.read_bytes(), version.read_bytes())
        self.assertFalse(json.loads(cfg.read_text(encoding="utf-8"))["sync_on_start"])
        self.assertEqual(note.read_bytes(), note_before)
        self.assertEqual(personal.read_text(encoding="utf-8"), "local fixture")


if __name__ == "__main__":
    unittest.main()
