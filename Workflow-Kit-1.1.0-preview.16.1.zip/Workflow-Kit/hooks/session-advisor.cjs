'use strict';
// Warn about the context reserve. This process never opens chats or blocks tools.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const EVENTS = new Set(['UserPromptSubmit', 'PreToolUse', 'PostToolUse', 'PreCompact', 'Stop']);
const EARLY = 0.75;
const PREPARE = 0.80;
const TRANSFER_REMINDER = 'В связи с большой контекстной нагрузкой, рекомендую перенос диалога в новый чат. Автоматический перенос выполняется по команде "переноси"';
const COMPACTION_NOTICE = 'Контекст этого чата был сжат.';
const CONTINUE_TO_END = /(?<!\p{L})(?:до\s+(?:конца|завершения|границы\s+переноса)|пока\s+не\s+закончишь)(?!\p{L})/iu;
const CONTINUE_RULE = 'Если пользователь по смыслу просит продолжать текущую задачу до конца или до границы переноса, работай в текущем ходе до завершения задачи или до безопасной границы переноса, в зависимости от того, что наступит раньше. После промежуточного результата самостоятельно переходи к следующей доступной части. Если действительно нужны уточнение, разрешение или подтверждение пользователя, сначала выполни всё независимое и запроси только необходимое решение. На границе переноса выполни полный СТОП по действующему протоколу Workflow Kit и дождись отдельной прямой команды на перенос.';
const DIRECT_CONTINUATION = /(?:^|[.,!;\n]\s*)(?:хорошо[,!\s]+)?(?:продолжай\s+до\s+(?:конца|завершения|границы\s+переноса)|доведи\s+(?:работу|задачу)\s+до\s+завершения)(?=$|[.,!;\s])/iu;
const QUOTED_TEXT = /«[^»]*»|“[^”]*”|"[^"]*"|`+[^`]*`+/gu;
const FENCED_TEXT = /^[ \t]*(`{3,}|~{3,})[^\n]*\n[\s\S]*?(?:^[ \t]*\1[ \t]*\r?$|(?![\s\S]))/gmu;
const UNTIL_TRANSFER = /(?<![\p{L}\p{N}])продолжай\s+до\s+переноса(?![\p{L}\p{N}])/iu;
const COMMAND_WORDS = /^(?:продолжай(?:\s+до(?:\s+переноса)?)?|до(?:\s+переноса)?|переноса)$/iu;
const COMMAND_MENTION_PREFIX = /(?:^|[^\p{L}])(?:фраз[аеуы]|команд[аеуы]|пример(?:\s+команды)?|сообщение|что\s+значит|означает|объясни|проверь|напис(?:ать|ал[аи]?|ал[аи]сь|ано)|напиш(?:у|ешь|ет|ем|ете|ут)|сказ(?:ать|ал[аи]?|ано)|скажу|ввести|ввёл[аи]?)\s*:?\s*$/iu;
const COMMAND_NEGATION = /(?:^|[^\p{L}])не\s+$/iu;
const COMMAND_CANCELLED = /(?:^|[.!?;\n])\s*(?:отмена|отмени\s+(?:эту\s+)?команду)(?!\p{L})/iu;
const TRANSFER_SCOPE = '«Продолжай до переноса» означает: продолжай активную работу в этом чате, даже если отдельного ТЗ нет. Если закончен этап, переходи к следующему доступному этапу той же работы в этом же ходе. Используй исходное поручение, согласованные границы и точку продолжения в HANDOFF, когда она есть. Остановись, когда пора сохранять контекст для нового чата, вся работа завершена или дальнейшие действия требуют решения владельца. При необходимости решения сначала выполни всё независимое. На границе переноса выполни полный СТОП и дождись отдельной команды владельца.';
const TASK_SCOPE = 'Если «продолжай до конца» дано отдельным сообщением, восстанови всю активную задачу по исходному поручению и согласованным границам. Следующий шаг в HANDOFF или последнем отчёте задаёт точку продолжения. Завершение партии, периода или проверки одного источника само по себе задачу не закрывает. Проверь, остался ли следующий доступный шаг в согласованных границах, и выполни его в этом же ходе. Если пользователь явно ограничил задачу периодом или источником, соблюдай эту границу.';
const END_REPORT = 'В финальном ответе укажи отдельной строкой одно проверяемое основание остановки: «Работа до конца — завершена: <что выполнено и проверено по всей задаче>», «Работа до конца — нужно решение: <что именно требуется и почему доступные шаги исчерпаны>» или «Работа до конца — граница переноса: СТОП выполнен, <что сохранено>». Используй строку только при фактическом выполнении её условия.';
const REVIEW_STOP = 'Сверь итог с исходной задачей. Если остался доступный шаг, продолжи.';
const END_REPORT_LINE = /^[ \t]*(?:(?:#{1,6}|[-+]|\d+[.)])[ \t]+)?Работа\s+до\s+конца[ \t]*[—–-][ \t]*(завершена|нужно решение|граница переноса):[ \t]*(?:\r?\n[ \t]*)?([^\s>#][^\r\n]*)$/gmu;
const VAGUE_OUTCOME = /^(?:готово|вс[её] (?:готово|сделано|проверено|выполнено)|задача завершена|нужн[оы] уточнени[ея]|нужно решение|нужен ответ|нет данных)[.!\s]*$/iu;
const AVAILABLE_STEP = /(?:^|\n)\s*(?:следующий доступный шаг|дальше можно)[ \t:—-]|(?:проверен\p{L}*|сверен\p{L}*|выполнен\p{L}*)\s+(?:только|одна партия|одну партию)(?!\p{L})/iu;
const NEXT_STAGE = /(?<!\p{L})(?:следующ(?:ий\s+(?:этап|шаг)|ая\s+(?:задача|проверка))\s*[:—–-]|дальше\s+(?:перейду|продолжу|проверю|сверю|сделаю)\s+)[^\r\n.]*/giu;
const OUTSIDE_SCOPE = /(?:за пределами|вне)\s+(?:текущего\s+|текущей\s+)?(?:поручения|задачи|согласованных границ)/iu;
const INCOMPLETE_STOP = /(?<!\p{L})не\s+(?:сохран\p{L}*|обновл\p{L}*|зафиксирован\p{L}*|выполнен\p{L}*|отправлен\p{L}*)/iu;
const PENDING_RESULT = /пока\s+не\s+(?:найден\p{L}*|установлен\p{L}*|получен\p{L}*)/iu;
const SCAN_BATCH = 6;
const TRANSFER = /^(?:да[,\s]+)?(?:переноси(?:\s+(?:и закоммить|в новый чат))?|продолжай перенос)[.!\s]*$/iu;
const SCAN_RANGE = /(?:кадр\p{L}*|скан\p{L}*|разворот\p{L}*|страниц\p{L}*)\s*(?:с\s+)?(\d+)\s*(?:[-–—]|\sпо\s)\s*(\d+)/giu;

function transcriptTail(file, since = 0) {
  if (!file) return '';
  let descriptor;
  try {
    descriptor = fs.openSync(file, 'r');
    const size = fs.fstatSync(descriptor).size;
    const bytes = Buffer.alloc(Math.min(Math.max(0, size - since), 512 * 1024));
    const read = fs.readSync(descriptor, bytes, 0, bytes.length, size - bytes.length);
    return bytes.toString('utf8', 0, read);
  } catch {
    return '';
  } finally {
    if (descriptor !== undefined) fs.closeSync(descriptor);
  }
}

function isCompaction(entry) {
  return entry?.type === 'compacted' || entry?.payload?.type === 'context_compacted';
}

function restoreCompactionHistory(file, state) {
  if (!file || state.compactionHistoryChecked || state.compactionNoticeActive) return;
  try {
    const transcript = fs.readFileSync(file, 'utf8');
    state.compactionNoticeActive = transcript.split('\n').some(line => {
      if (!line.includes('"compacted"') && !line.includes('"context_compacted"')) return false;
      try { return isCompaction(JSON.parse(line)); } catch { return false; }
    });
    state.compactionHistoryChecked = true;
  } catch { /* Try again once Codex exposes the transcript. */ }
}

function metrics(file) {
  for (const line of transcriptTail(file).split('\n').reverse()) {
    let entry;
    try { entry = JSON.parse(line); } catch { continue; }
    if (isCompaction(entry)) return null;
    if (entry?.type !== 'event_msg' || entry.payload?.type !== 'token_count') continue;
    const info = entry.payload.info;
    if (!info) continue;
    const used = info.last_token_usage?.input_tokens;
    const window = info.model_context_window;
    if (Number.isFinite(used) && Number.isFinite(window) && used >= 0 && window > 0 && used <= window) {
      return { used, window };
    }
    return null;
  }
  return null;
}

function scanBatch(input) {
  if (input.hook_event_name === 'UserPromptSubmit') {
    return Array.from(String(input.prompt ?? '').matchAll(SCAN_RANGE))
      .some(([, first, last]) => Number(last) - Number(first) + 1 >= SCAN_BATCH);
  }
  const args = input.tool_input;
  if (!args || typeof args !== 'object') return false;
  if (['images', 'image_paths', 'imagePaths', 'scans'].some(key =>
    Array.isArray(args[key]) && args[key].length >= SCAN_BATCH)) return true;
  const code = typeof args.code === 'string' ? args.code.slice(0, 24000) : '';
  return (code.match(/\b(?:view_image|emitImage|screenshot)\s*\(/gu) ?? []).length >= SCAN_BATCH;
}

function warn(event, message) {
  return {
    systemMessage: message,
    hookSpecificOutput: { hookEventName: event, additionalContext: message }
  };
}

function untilTransferCommand(prompt) {
  const plain = prompt.normalize('NFKC')
    .replace(FENCED_TEXT, ' ')
    .replace(/^[ \t]*>[^\r\n]*/gmu, ' ')
    .replace(/[\u200B-\u200F\u2060\uFEFF*_]/gu, '');
  const commandText = plain.replace(QUOTED_TEXT, quoted => {
    const inner = quoted.replace(/^[«“"`]+|[»”"`]+$/gu, '').trim();
    if (quoted.startsWith('`') && COMMAND_WORDS.test(inner)) return ' ' + inner + ' ';
    return inner.match(UNTIL_TRANSFER)?.[0] === inner ? ' ' + inner + ' ' : ' ';
  });
  for (const match of Array.from(commandText.matchAll(new RegExp(UNTIL_TRANSFER, 'giu'))).reverse()) {
    const before = commandText.slice(0, match.index);
    if (COMMAND_MENTION_PREFIX.test(before)) continue;
    const after = commandText.slice(match.index + match[0].length);
    return !COMMAND_NEGATION.test(before) && !COMMAND_CANCELLED.test(after);
  }
  return false;
}

function stopOutcome(message, reachedReserve, untilTransfer) {
  const text = message.replace(FENCED_TEXT, ' ')
    .replace(/^[ \t]*\*[ \t]+/gmu, '- ')
    .replace(/\*{1,3}|_{1,3}/gu, '');
  const prose = text.replace(/^[ \t]*>[^\r\n]*/gmu, ' ');
  const [, kind, detail] = Array.from(prose.matchAll(END_REPORT_LINE)).at(-1) ?? [];
  if (!kind || VAGUE_OUTCOME.test(detail)) return null;
  if (kind === 'граница переноса') {
    const saved = /^СТОП выполнен[,.:]\s+.+/iu.test(detail) && !INCOMPLETE_STOP.test(prose);
    const prompt = /^## Промпт[ \t]*\r?\n\s*>\s*\S/mu.test(text);
    return saved && (reachedReserve || prompt) ? kind : null;
  }
  if (AVAILABLE_STEP.test(prose)) return null;
  if (kind === 'завершена' && untilTransfer && Array.from(prose.matchAll(NEXT_STAGE)).some(([step]) =>
    !OUTSIDE_SCOPE.test(step))) return null;
  if (kind === 'завершена' && PENDING_RESULT.test(prose) &&
      !/(?:все|весь|всю)\s+(?:доступн\p{L}*|согласованн\p{L}*)/iu.test(detail)) return null;
  return kind;
}

function assess(input, state) {
  const event = input.hook_event_name;
  const prompt = String(input.prompt ?? '').trim();
  const untilTransfer = event === 'UserPromptSubmit' && untilTransferCommand(prompt);
  const continueToEnd = event === 'UserPromptSubmit' && (untilTransfer || CONTINUE_TO_END.test(prompt));
  // Preserve the recommendation across compaction and upgrades from an earlier advisor.
  if (state.prepareWarned) state.transferReminderActive = true;
  if (event === 'UserPromptSubmit') {
    // This legacy hint only labels reserve diagnostics. Codex interprets transfer requests.
    if (prompt !== REVIEW_STOP) {
      if (input.turn_id && (untilTransfer || DIRECT_CONTINUATION.test(prompt.replace(QUOTED_TEXT, ' ')))) {
        state.continueTurn = { id: input.turn_id, untilTransfer };
      }
      else delete state.continueTurn;
    }
    state.transferCommand = TRANSFER.test(prompt);
    state.skipTransferNotice = state.transferCommand || /^стоп[.!…\s]*$/iu.test(prompt);
    state.batchWarned = false;
    restoreCompactionHistory(input.transcript_path, state);
  }

  const last = metrics(input.transcript_path);
  const pressure = last ? last.used / last.window : null;
  if (state.continueTurn?.id === input.turn_id && input.turn_id && pressure !== null && pressure >= PREPARE) {
    state.continueTurn.reachedReserve = true;
  }
  const prepareNow = pressure !== null && pressure >= PREPARE && !state.prepareWarned;
  const warnUserNow = prepareNow && !state.skipTransferNotice;
  if (pressure !== null && pressure >= PREPARE) state.transferReminderActive = true;

  if (event === 'PreCompact') {
    const inTransfer = state.transferCommand;
    const automatic = input.trigger === 'auto';
    const message = inTransfer && automatic
      ? 'Автосжатие при переносе: резерва не хватило. Сверь сохранённые решения и уже выполненные шаги СТОП перед продолжением.'
      : 'Зафиксировано сжатие контекста. Сверь сохранённые решения и ближайшую безопасную точку.';
    if (inTransfer && automatic) state.transferCompactions = (state.transferCompactions ?? 0) + 1;
    state.afterCompact = message;
    try {
      state.compactionOffset = fs.statSync(input.transcript_path).size;
    } catch { delete state.compactionOffset; }
    state.earlyWarned = state.prepareWarned = state.batchWarned = false;
    return { systemMessage: warnUserNow && automatic ? TRANSFER_REMINDER + '\n' + message : message };
  }

  if (Number.isSafeInteger(state.compactionOffset) && transcriptTail(input.transcript_path, state.compactionOffset)
    .split('\n').some(line => {
      try { return isCompaction(JSON.parse(line)); } catch { return false; }
    })) {
    state.compactionNoticeActive = state.compactionNoticePending = true;
    delete state.compactionOffset;
  }

  // Tool-free turns may produce their first high measurement only at Stop.
  if (event === 'Stop') {
    if (state.continueTurn?.id === input.turn_id && input.turn_id) {
      const outcome = stopOutcome(input.last_assistant_message ?? '', state.continueTurn.reachedReserve, state.continueTurn.untilTransfer);
      if (outcome === 'граница переноса') return {};
      if (!outcome && !state.continueTurn.rechecked && !input.stop_hook_active) {
        state.continueTurn.rechecked = true;
        return { decision: 'block', reason: REVIEW_STOP };
      }
    }
    if (!warnUserNow) return {};
    state.prepareWarned = state.earlyWarned = true;
    return { systemMessage: TRANSFER_REMINDER };
  }

  const messages = [];
  if (state.afterCompact) {
    messages.push(state.afterCompact + ' Обнови Оценка_контекста.md, если этого требуют правила проекта.');
    delete state.afterCompact;
  }
  if (prepareNow) {
    const next = state.transferCommand
      ? 'Проверь, что подготовка к СТОП уже началась, и продолжай с ближайшего незавершённого шага.'
      : 'На ближайшей безопасной границе начни подготовку к СТОП.';
    messages.push('Последний измеренный вход достиг порога 80%. ' + next + ' Новый чат открывай только по прямой команде владельца.');
    state.prepareWarned = state.earlyWarned = true;
  } else if (pressure !== null && pressure >= EARLY && !state.earlyWarned) {
    messages.push('Последний измеренный вход достиг порога 75%. До следующей партии оцени, хватит ли окна на неё и резерв 20% для полного СТОП. Это замер последнего входа.');
    state.earlyWarned = true;
  }
  if (!state.batchWarned && scanBatch(input)) {
    if (pressure === null) {
      messages.push('Намечена большая партия сканов, метрика недоступна. До начала задай ограниченную контрольную точку и оцени запас на полный СТОП.');
    } else {
      messages.push('Намечена большая партия сканов. До её начала проверь, сохранится ли резерв 20% на полный СТОП. Если есть риск израсходовать резерв, уменьши партию или начни подготовку раньше.');
    }
    state.batchWarned = true;
  }
  const result = messages.length ? warn(event, messages.join(' ')) : {};
  if (warnUserNow) result.systemMessage += '\n' + TRANSFER_REMINDER;
  if (state.compactionNoticePending) state.compactionNoticeActive = true;
  const showCompaction = state.compactionNoticeActive && !state.skipTransferNotice
    && (event === 'UserPromptSubmit' || (event === 'PostToolUse' && state.compactionNoticePending));
  const showTransfer = state.transferReminderActive && !state.skipTransferNotice && (event === 'UserPromptSubmit' || showCompaction || warnUserNow);
  if (showCompaction || showTransfer) {
    const notices = [];
    if (showCompaction) {
      notices.push(COMPACTION_NOTICE);
      delete state.compactionNoticePending;
    }
    if (showTransfer) notices.push(TRANSFER_REMINDER);
    const exception = 'Определи по смыслу всего сообщения, есть ли прямая просьба перенести чат или выполнить СТОП. Если есть, в этом ответе пропусти все строки ниже, включая напоминание о переносе и строку о сжатии. Упоминание команды, обсуждение или отказ от переноса сами по себе не считаются поручением.\n';
    const instruction = exception + (showTransfer && !showCompaction ? 'Начни ответ со следующего напоминания' : 'Начни ответ со следующего сообщения')
      + (showTransfer
        ? ' ровно один раз. Напоминание о высокой нагрузке можно сформулировать своими словами, сохранив рекомендацию переноса. '
        : ' дословно и ровно один раз. ')
      + 'Затем оставь пустую строку и дай основной ответ:\n' + notices.join('\n');
    result.hookSpecificOutput = {
      hookEventName: event,
      additionalContext: [
        ...messages,
        instruction,
        ...(warnUserNow ? ['Если правило выше разрешает показать напоминание и работа в этом ходе продолжается, сразу покажи пользователю напоминание отдельным сообщением до следующего действия. В этом случае не повторяй его в итоговом ответе этого же хода.'] : []),
      ].join('\n\n'),
    };
  }
  if (continueToEnd) {
    const context = result.hookSpecificOutput?.additionalContext;
    result.hookSpecificOutput = {
      hookEventName: event,
      additionalContext: [context, untilTransfer ? TRANSFER_SCOPE : CONTINUE_RULE + '\n\n' + TASK_SCOPE,
        state.continueTurn?.id === input.turn_id && input.turn_id ? END_REPORT : ''].filter(Boolean).join('\n\n'),
    };
  }
  return result;
}

function run(input, { stateDir = path.join(process.env.CODEX_HOME || path.join(os.homedir(), '.codex'), 'session-advisor-reserve') } = {}) {
  if (!EVENTS.has(input?.hook_event_name) || !input.session_id) return {};
  fs.mkdirSync(stateDir, { recursive: true });
  const key = crypto.createHash('sha256').update(String(input.session_id)).digest('hex');
  const stateFile = path.join(stateDir, key + '.json');
  const lock = stateFile + '.lock';
  try { fs.mkdirSync(lock); } catch { return {}; }
  try {
    let state = {};
    try { state = JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch { /* First event. */ }
    const original = JSON.stringify(state);
    const result = assess(input, state);
    const updated = JSON.stringify(state);
    if (updated !== original) {
      const temp = stateFile + '.' + process.pid + '.tmp';
      fs.writeFileSync(temp, updated);
      fs.renameSync(temp, stateFile);
    }
    return result;
  } finally {
    fs.rmdirSync(lock);
  }
}

module.exports = { run, metrics };
if (require.main === module) {
  try {
    process.stdout.write(JSON.stringify(run(JSON.parse(fs.readFileSync(0, 'utf8')))));
  } catch {
    process.stdout.write('{}');
  }
}
