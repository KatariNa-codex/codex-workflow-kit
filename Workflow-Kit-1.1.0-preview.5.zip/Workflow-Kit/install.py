#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Установщик Workflow Kit для Codex Desktop на Windows.

Что делает (и только это):
  * создаёт папку общей памяти и её подпапки, шапку оглавления;
  * копирует хуки и скрипты в выбранный профиль Codex (обычно ~/.codex);
  * прописывает хуки в настройки агента, сохранив прежний файл рядом (.bak-дата);
  * дописывает раздел правил в общий файл правил агента и шаблон HANDOFF в файл правил
    корневой папки проектов — строго между метками memory-kit, остальное не трогает.

Запуск:
  python install.py --root <корневая папка проектов> --dry-run     # показать, что изменится
  python install.py --root <корневая папка проектов>               # установить
  python install.py --root <...> --project <папка проекта>          # и завести в проекте HANDOFF.md
  python install.py --root <...> --check                            # проверить установку
  python install.py --root <...> --uninstall                        # снять хуки и раздел правил

  --tool codex              можно опустить
  --memory <папка>           где держать память; по умолчанию ~/.agent-memory
  --home <папка>             другая домашняя папка (для проверки в песочнице)

Память при --uninstall не удаляется никогда.
"""
import argparse
import glob
import hashlib
import json
import os
import re
import runpy
import shutil
import subprocess
import sys
import time

import tempfile
from pathlib import Path

KIT = os.path.dirname(os.path.abspath(__file__))
codex_project_rules_budget = runpy.run_path(os.path.join(KIT, "scripts", "kit_check.py"))["codex_project_rules_budget"]
START, END = "<!-- memory-kit:start -->", "<!-- memory-kit:end -->"
HOOK_FILES = ["kit.js", "session-start-context.js", "session-summary-check.js", "memory-index-hook.py",
              "memory-recall-hook.py"]
SCRIPT_FILES = ["memory_index.py", "memory_search.py", "session_archive.py", "project_index.py", "kit_check.py",
                "memory_report.py", "memory_upkeep.py",
                "find-zombies.ps1"]
MEMORY_DIRS = ["feedback", "ref", "projects", "plans", "research", "reviews"]
STAMP = time.strftime("%Y%m%d-%H%M%S")
HOOKS_ALIVE = "memory-kit: хуки работают"      # та же строка — в hooks/kit.js

TOOLS = {
    # start_max_chars: Codex пропускает к модели около 6,5 тыс. знаков вывода хука, остальное вырезает
    "codex": {"dir": ".codex", "hooks_file": "hooks.json", "rules": "AGENTS.md", "inject_project_index": True,
              "start_max_chars": 5800},
}

AUTOLOAD = {
    "codex": (
        "Оглавления памяти (`MEMORY.md` общей памяти и памяти проекта) подкладывает в контекст хук\n"
        "начала сессии. Файлы правил открывай по ссылкам из оглавления, когда задача их касается.\n"
        "Всё, что нужно запомнить, пиши файлами в папки выше по правилам ниже — так память\n"
        "остаётся общей для всех агентов на этой машине."
    ),
}

# Строка-метка должна совпадать с HOOKS_ALIVE в hooks/kit.js
HOOKCHECK_HEAD = (
    "Это правило выполняется раньше любого другого и раньше ответа на вопрос человека.\n"
    "Найди в контексте дословную строку `memory-kit: хуки работают` (её кладёт хук начала\n"
    "сессии). Строка есть — ничего не говори об этом и работай. Строки НЕТ — свой первый ответ\n"
    "в сессии, каким бы коротким ни был вопрос, начни с этого предупреждения дословно\n"
    "и только потом отвечай по делу:\n\n"
)
HOOKCHECK = {
    "codex": HOOKCHECK_HEAD + (
        "> ⚠️ Память memory-kit не подключена: Codex не запускает хуки, пока им не доверили.\n"
        "> Набери `/hooks`, подтверди хуки memory-kit и открой новую сессию.\n\n"
        "Сам подтвердить хуки ты не можешь, это делает только человек. Одного раза за сессию\n"
        "достаточно; в следующей сессии проверь заново."
    ),
}


def say(text=""):
    print(text)


def fwd(path):
    return path.replace("\\", "/")


def slug(path):
    """Имя папки памяти для пути — правило Claude Code: всё, кроме латинских букв и цифр, в дефис."""
    return re.sub(r"[^A-Za-z0-9]", "-", os.path.abspath(path))


def slug_dir(projects_dir, path):
    """Существующая папка с таким именем без учёта регистра (буква диска на Windows гуляет) или новая."""
    want = slug(path)
    if os.path.isdir(projects_dir):
        for name in os.listdir(projects_dir):
            if name.lower() == want.lower():
                return os.path.join(projects_dir, name)
    return os.path.join(projects_dir, want)


def read(path):
    with open(path, "rb") as fh:
        return fh.read().decode("utf-8-sig", errors="replace")


def profile_dir(args, home, tool):
    explicit = args.codex_home if tool == "codex" else None
    if tool == "codex" and not args.home and not explicit:
        explicit = os.environ.get("CODEX_HOME")
    return os.path.abspath(explicit) if explicit else os.path.join(home, TOOLS[tool]["dir"])


def atomic_write(path, data):
    path = Path(path)
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as temporary:
        temp = Path(temporary.name)
        temporary.write(data)
        temporary.flush()
        os.fsync(temporary.fileno())
    try:
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def digest(data):
    return hashlib.sha256(data).hexdigest() if data is not None else None


def installed_bytes(path):
    return path.read_bytes() if path.exists() else None


class InstallTransaction:
    def __init__(self, directory):
        self.directory = directory
        self.journal = directory / "journal.json"
        self.record = {"committed": False, "files": []}

    def begin(self):
        self.directory.parent.mkdir(parents=True, exist_ok=True)
        self.directory.mkdir()
        self.save()

    def save(self):
        atomic_write(self.journal, dump_json(self.record).encode("utf-8"))

    def replace(self, path, data):
        path = Path(path)
        old = installed_bytes(path)
        if old == data:
            return
        index = len(self.record["files"])
        if old is not None:
            atomic_write(self.directory / f"old-{index}", old)
        self.record["files"].append({"path": str(path.resolve()), "old": digest(old),
                                     "new": digest(data), "index": index})
        self.save()
        atomic_write(path, data)

    def complete(self):
        self.record["committed"] = True
        self.save()
        self.clean()

    def clean(self):
        for path in self.directory.glob("old-*"):
            path.unlink()
        self.journal.unlink(missing_ok=True)
        self.directory.rmdir()

    def recover(self, allowed_roots):
        if not self.directory.exists():
            return False
        if self.journal.is_file():
            self.record = json.loads(self.journal.read_text(encoding="utf-8"))
        if not self.record["committed"]:
            restore = []
            for entry in reversed(self.record["files"]):
                path = Path(entry["path"]).resolve()
                roots = [Path(root).resolve() for root in allowed_roots]
                if not any(root in path.parents for root in roots):
                    raise ValueError("Путь восстановления вне установки: " + str(path))
                current = digest(installed_bytes(path))
                if current == entry["old"]:
                    continue
                if current != entry["new"]:
                    raise ValueError("Файл изменён после прерывания: " + str(path))
                original = None
                if entry["old"] is not None:
                    original = (self.directory / f"old-{entry['index']}").read_bytes()
                    if digest(original) != entry["old"]:
                        raise ValueError("Резервная копия повреждена: " + str(path))
                restore.append((path, original))
            for path, original in restore:
                if original is None:
                    path.unlink(missing_ok=True)
                else:
                    atomic_write(path, original)
        self.clean()
        return True


class Doer:
    """Все записи идут через него: в режиме --dry-run только печатает."""

    def __init__(self, dry, transaction=None):
        self.dry = dry
        self.transaction = transaction
        self.changed = 0

    def mkdir(self, path):
        if not os.path.isdir(path):
            say("  + папка   " + fwd(path))
            self.changed += 1
            if not self.dry:
                os.makedirs(path, exist_ok=True)

    def write(self, path, text, backup=True):
        old = read(path) if os.path.exists(path) else None
        if old is not None and old.replace("\r\n", "\n") == text.replace("\r\n", "\n"):
            return False
        say("  %s файл    %s" % ("~" if old is not None else "+", fwd(path)))
        self.changed += 1
        if self.dry:
            return True
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if old is not None and backup:
            shutil.copy2(path, path + ".bak-" + STAMP)
            say("    прежний сохранён: " + fwd(path) + ".bak-" + STAMP)
        self.replace(path, text.encode("utf-8"))
        return True

    def copy(self, src, dst):
        with open(src, "rb") as fh:
            data = fh.read()
        if os.path.exists(dst):
            with open(dst, "rb") as fh:
                if fh.read() == data:
                    return
        say("  %s файл    %s" % ("~" if os.path.exists(dst) else "+", fwd(dst)))
        self.changed += 1
        if self.dry:
            return
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        if os.path.exists(dst):
            shutil.copy2(dst, dst + ".bak-" + STAMP)
        self.replace(dst, data)

    def replace(self, path, data):
        if self.transaction is None:
            atomic_write(path, data)
        else:
            self.transaction.replace(path, data)

    def remove(self, path):
        if os.path.exists(path):
            say("  - файл    " + fwd(path))
            self.changed += 1
            if not self.dry:
                os.remove(path)


# ---------- хуки в настройках агента ----------

def quote(path, tool):
    p = fwd(path)
    if " " not in p:
        return p
    return ("'%s'" if tool == "codex" else '"%s"') % p


def python_cmd():
    exe = sys.executable or ""
    if exe and " " not in exe:
        return fwd(exe)
    return "python" if os.name == "nt" else "python3"


def wanted_hooks(tool, tool_dir):
    hooks = os.path.join(tool_dir, "hooks")
    node = lambda name: "node " + quote(os.path.join(hooks, name), tool)
    py = lambda name, arg: "%s %s %s" % (python_cmd(), quote(os.path.join(hooks, name), tool), arg)
    out = [
        ("SessionStart", "", {"type": "command", "command": node("session-start-context.js")}),
        ("Stop", "", {"type": "command", "command": node("session-summary-check.js")}),
        ("Stop", "", {"type": "command", "command": py("memory-index-hook.py", "stop"), "timeout": 60}),
    ]
    # память в нужный момент: правила перед коммитом и сервером, по словам просьбы, короткий контекст помощнику.
    # Codex зовёт команды оболочки именем Bash и принимает на этих событиях и отказ, и добавку в контекст
    # (его документация по хукам, сверено 13.10.2026)
    out.append(("PreToolUse", "Bash",
                {"type": "command", "command": py("memory-recall-hook.py", "pre"), "timeout": 10}))
    out.append(("UserPromptSubmit", "",
                {"type": "command", "command": py("memory-recall-hook.py", "prompt"), "timeout": 10}))
    out.append(("SubagentStart", "",
                {"type": "command", "command": py("memory-recall-hook.py", "subagent"), "timeout": 10}))
    return out


def hook_key(command, tool_dir):
    """Recognize only an explicit path to an installed memory-kit handler."""
    normalized = fwd(command)
    if os.name == "nt":
        normalized = normalized.casefold()
    for name in HOOK_FILES:
        path = fwd(os.path.join(tool_dir, "hooks", name))
        if os.name == "nt":
            path = path.casefold()
        if re.search(r"""(?:^|[\s"'])""" + re.escape(path) + r"""(?=$|[\s"'])""", normalized):
            mode = next((m for m in ("stop", "post", "pre", "subagent", "precompact")
                         if normalized.rstrip().endswith(" " + m)), "")
            return name + ":" + mode
    return None


def merge_hooks(settings, tool, tool_dir):
    hooks = settings.setdefault("hooks", {})
    for event, matcher, entry in wanted_hooks(tool, tool_dir):
        key = hook_key(entry["command"], tool_dir)
        groups = hooks.setdefault(event, [])
        found = False
        for group in groups:
            handlers = []
            for handler in group.get("hooks", []):
                if hook_key(handler.get("command", ""), tool_dir) != key:
                    handlers.append(handler)
                elif not found:
                    handlers.append({**handler, **entry})
                    found = True
            group["hooks"] = handlers
        if found:
            hooks[event] = [group for group in groups if group.get("hooks")]
            continue
        target = next((group for group in groups if group.get("matcher", "") == matcher), None)
        if target is None:
            target = {"matcher": matcher, "hooks": []}
            groups.append(target)
        target.setdefault("hooks", []).append(entry)
    return settings


def codex_writable_note(doer, tool_dir, roots):
    """Codex: то же право выдаётся в config.toml. Чужой файл настроек правим, только если раздела ещё нет."""
    path = os.path.join(tool_dir, "config.toml")
    text = read(path).replace("\r\n", "\n") if os.path.exists(path) else ""
    flat = fwd(text).replace("//", "/")
    roots = [fwd(r) for r in roots if fwd(r) not in flat]
    if not roots:
        return
    if re.search(r"^\[sandbox_workspace_write\]", text, re.M):
        say("  ! в config.toml уже есть раздел [sandbox_workspace_write] — допиши в его writable_roots:")
        for r in roots:
            say("    " + r)
        return
    block = ("\n# memory-kit: память лежит вне папки проекта, агенту нужно право писать в неё\n"
             "[sandbox_workspace_write]\nwritable_roots = [%s]\n" % ", ".join('"%s"' % r for r in roots))
    doer.write(path, text.rstrip("\n") + "\n" + block if text else block.lstrip("\n"))


def strip_hooks(settings, tool_dir):
    hooks = settings.get("hooks", {})
    for event in list(hooks):
        for g in hooks[event]:
            g["hooks"] = [h for h in g.get("hooks", []) if not hook_key(h.get("command", ""), tool_dir)]
        hooks[event] = [g for g in hooks[event] if g.get("hooks")]
        if not hooks[event]:
            del hooks[event]
    return settings


def load_json(path):
    if not os.path.exists(path):
        return {}
    try:
        return json.loads(read(path) or "{}")
    except ValueError as e:
        raise SystemExit("Не могу разобрать %s (%s). Ничего не тронул — поправь файл и запусти снова." % (fwd(path), e))


def dump_json(data):
    return json.dumps(data, ensure_ascii=False, indent=2) + "\n"


# ---------- раздел правил между метками ----------

def put_block(doer, path, block, title):
    block = START + "\n" + block.strip("\n") + "\n" + END
    if os.path.exists(path):
        text = read(path).replace("\r\n", "\n")
        if START in text and END in text:
            new = text[:text.index(START)] + block + text[text.index(END) + len(END):]
        else:
            new = text.rstrip("\n") + "\n\n" + block + "\n"
    else:
        new = "# " + title + "\n\n" + block + "\n"
    doer.write(path, new)


def cut_block(doer, path):
    if not os.path.exists(path):
        return
    text = read(path).replace("\r\n", "\n")
    if START in text and END in text:
        new = (text[:text.index(START)].rstrip("\n") + "\n" + text[text.index(END) + len(END):].lstrip("\n")).rstrip("\n") + "\n"
        doer.write(path, new)


def render(name, values):
    text = read(os.path.join(KIT, "templates", name)).replace("\r\n", "\n")
    for k, v in values.items():
        text = text.replace("{{" + k + "}}", v)
    return text


def zombies_text(tool_dir):
    if os.name == "nt":
        return ("Запусти `powershell -NoProfile -File %s`.\n"
                "   Он ищет серверы разработки и фоновые команды, которые остались от прошлых сессий без\n"
                "   живого агента-родителя. Найденное покажи списком и спроси, что остановить (флаг `-Kill`).\n"
                "   Сам ничего не убивай." % fwd(os.path.join(tool_dir, "scripts", "find-zombies.ps1")))
    return ("Проверь через `ps`, не остались ли запущенные в этой сессии серверы разработки\n"
            "   и фоновые команды. Найденное покажи списком и спроси, что остановить. Сам ничего не убивай.")


# ---------- действия ----------

def layout(args):
    home = os.path.abspath(os.path.expanduser(args.home or "~"))
    root = os.path.abspath(os.path.expanduser(args.root))
    tools = ["codex"]
    if not args.memory:
        cfg = load_json(os.path.join(profile_dir(args, home, "codex"), "memory-kit.json"))
        if cfg.get("central"):
            central = os.path.abspath(os.path.expanduser(cfg["central"]))
            memory_home = os.path.dirname(central) if os.path.basename(central) == "central" else central
            projects_dir = cfg.get("projects_dir") or os.path.join(memory_home, "projects")
            return home, root, tools, os.path.abspath(os.path.expanduser(projects_dir)), central, memory_home
    memory_home = os.path.abspath(os.path.expanduser(args.memory)) if args.memory else os.path.join(home, ".agent-memory")
    central = os.path.join(memory_home, "central")
    projects_dir = os.path.join(memory_home, "projects")
    return home, root, tools, projects_dir, central, memory_home


def review_existing_install(args, home, tools):
    for tool in tools:
        spec = TOOLS[tool]
        tool_dir = profile_dir(args, home, tool)
        cfg = load_json(os.path.join(tool_dir, "memory-kit.json"))
        registrations = load_json(os.path.join(tool_dir, spec["hooks_file"])).get("hooks", {})
        if any("/workflow-kit/wk_runtime.py" in fwd(handler.get("command", "")).casefold()
               for groups in registrations.values() for group in groups for handler in group.get("hooks", [])):
            raise SystemExit("Обнаружены хуки Workflow Kit 1.0.0. Перед установкой отключи их штатным способом или выбери отдельный профиль. Файлы не изменены.")
        previous = cfg.get("kit_dir")
        installed_kit = Path(tool_dir) / "workflow-kit-package"
        tracked = load_json(installed_kit / "installed-files.json")
        for name in package_files():
            dest = installed_kit / name
            if not dest.exists():
                continue
            known = (tracked.get(fwd(name)), digest((Path(KIT) / name).read_bytes()))
            if not dest.is_file() or digest(dest.read_bytes()) not in known:
                raise SystemExit("Локальная правка в установленном комплекте: " + str(dest) +
                                 ". Сначала сохрани её отдельно и проверь обновление.")
        for folder, names in (("hooks", HOOK_FILES), ("scripts", SCRIPT_FILES)):
            for name in names:
                installed = os.path.join(tool_dir, folder, name)
                if not os.path.lexists(installed):
                    continue
                sources = [os.path.join(KIT, folder, name)]
                if isinstance(previous, str) and os.path.isabs(previous):
                    sources.append(os.path.join(previous, folder, name))
                if (not os.path.isfile(installed) or
                        not any(os.path.isfile(source) and read(source).replace("\r\n", "\n") ==
                                read(installed).replace("\r\n", "\n") for source in sources)):
                    raise SystemExit("Не подтверждено происхождение файла: " + fwd(installed) +
                                     ". Проверь локальные правки или прежний исходный набор. Файлы не изменены.")


def transaction_paths(args, locations):
    home, root, tools, projects_dir, central, _ = locations
    profiles = [profile_dir(args, home, tool) for tool in tools]
    return InstallTransaction(Path(profiles[0]) / "workflow-kit.pending"), [*profiles, root, central, projects_dir]


def install(args):
    locations = layout(args)
    home, root, tools, projects_dir, central, _ = locations
    if not os.path.isdir(root):
        raise SystemExit("Корневой папки проектов нет: " + fwd(root))
    transaction, allowed = transaction_paths(args, locations)
    if transaction.directory.exists():
        raise SystemExit("Найдено незавершённое обновление. Запусти установщик с теми же параметрами и --rollback.")
    verify_package_manifest()
    review_existing_install(args, home, tools)
    if args.dry_run:
        return apply_install(args, locations, Doer(True))
    transaction.begin()
    try:
        result = apply_install(args, locations, Doer(False, transaction))
    except BaseException:
        transaction.recover(allowed)
        raise
    transaction.complete()
    return result


def verify_package_manifest():
    root = Path(KIT).resolve()
    manifest = root / "SHA256SUMS.json"
    if not manifest.is_file():
        return
    checksums = load_json(manifest)
    for name in checksums:
        path = (root / name).resolve()
        if root not in path.parents or not path.is_file() or digest(path.read_bytes()) != checksums[name]:
            raise SystemExit("Контрольная сумма комплекта не совпала: " + name)
    missing = set(map(fwd, package_files())) - checksums.keys()
    if missing:
        raise SystemExit("Контрольная сумма отсутствует для файлов: " + ", ".join(sorted(missing)))


def package_files():
    names = ["install.py", "НАЧАТЬ.md", "INSTALL.md", "LICENSE", "LICENSE-WORKFLOW", "release.json"]
    for folder in ("docs", "templates", "hooks", "scripts", "transfer", "tutorial"):
        location = Path(KIT) / folder
        names.extend(str(path.relative_to(KIT)) for path in sorted(location.rglob("*"))
                     if path.is_file() and "__pycache__" not in path.parts)
    return names


def apply_install(args, locations, doer):
    home, root, tools, projects_dir, central, memory_home = locations
    say("memory-kit: %s" % ("пробный прогон, ничего не пишу" if args.dry_run else "установка"))
    say("  агенты:        " + ", ".join(tools))
    say("  корень:        " + fwd(root))
    say("  общая память:  " + fwd(central))
    say("  память проектов: " + fwd(projects_dir) + "/<имя>/memory")
    say()
    for need in ("node", "git"):
        if not shutil.which(need):
            say("  ! не найден %s — хук начала сессии без него работать не будет" % need)

    say("Память:")
    for d in MEMORY_DIRS:
        doer.mkdir(os.path.join(central, d))
    head = os.path.join(central, "MEMORY.head.md")
    fresh = not os.path.exists(head)
    notes = glob.glob(os.path.join(central, "**", "*.md"), recursive=True)
    if fresh and notes:
        # Первая сборка переписывает оглавление и дописывает служебные строки в начало файлов памяти
        backup = central.rstrip("\\/") + ".bak-" + STAMP
        say("  ! первая сборка оглавления: перепишет MEMORY.md и INDEX.md, а в файлы памяти (%d) допишет служебные строки" % len(notes))
        say("    копия всей папки памяти: " + fwd(backup))
        if not args.dry_run:
            shutil.copytree(central, backup)
    if fresh:
        doer.write(head, render("MEMORY.head.md", {}), backup=False)
        feedback = os.path.join(central, "feedback")
        if not os.path.isdir(feedback) or not os.listdir(feedback):
            doer.copy(os.path.join(KIT, "templates", "feedback_example.md"),
                      os.path.join(feedback, "feedback_example.md"))

    for tool in tools:
        spec = TOOLS[tool]
        tool_dir = profile_dir(args, home, tool)
        installed_kit = os.path.join(tool_dir, "workflow-kit-package")
        installed_files = {}
        for name in package_files():
            source = Path(KIT) / name
            doer.copy(source, os.path.join(installed_kit, name))
            installed_files[fwd(name)] = digest(source.read_bytes())
        doer.write(os.path.join(installed_kit, "installed-files.json"), dump_json(installed_files))
        say()
        say("%s (%s):" % (tool, fwd(tool_dir)))
        for name in HOOK_FILES:
            doer.copy(os.path.join(KIT, "hooks", name), os.path.join(tool_dir, "hooks", name))
        for name in SCRIPT_FILES:
            doer.copy(os.path.join(KIT, "scripts", name), os.path.join(tool_dir, "scripts", name))
        cfg = {"tool": tool, "root": root, "projects_dir": projects_dir, "central": central,
               "inject_index": True, "inject_project_index": spec["inject_project_index"],
               "sync_on_start": True, "journal_entries": 3,
               "kit_dir": fwd(installed_kit)}           # по нему хук начала сессии и kit_check сверяют установку с набором
        if spec.get("start_max_chars"):
            cfg["start_max_chars"] = spec["start_max_chars"]
        cfg_path = os.path.join(tool_dir, "memory-kit.json")
        if os.path.exists(cfg_path):                 # ручные правки настроек переживают переустановку
            try:
                kept = json.loads(read(cfg_path))
                for k, v in kept.items():            # всё, кроме адресов: их задаёт этот запуск
                    if k not in ("tool", "root", "projects_dir", "central", "kit_dir"):
                        cfg[k] = v
            except ValueError:
                pass
        doer.write(cfg_path, dump_json(cfg))
        hooks_path = os.path.join(tool_dir, spec["hooks_file"])
        settings = merge_hooks(load_json(hooks_path), tool, tool_dir)
        doer.write(hooks_path, dump_json(settings))
        if tool == "codex":
            inside = os.path.normcase(projects_dir).startswith(os.path.normcase(memory_home) + os.sep)
            codex_writable_note(doer, tool_dir, [memory_home] + ([] if inside else [projects_dir]))
        root_rules = os.path.join(root, spec["rules"])
        values = {"CENTRAL": fwd(central), "PROJECTS_DIR": fwd(projects_dir), "ROOT": fwd(root),
                  "ROOT_RULES": fwd(root_rules), "AUTOLOAD": AUTOLOAD[tool], "HOOKCHECK": HOOKCHECK[tool], "ZOMBIES": zombies_text(tool_dir),
                  "SEARCH": "%s %s" % (python_cmd(), fwd(os.path.join(tool_dir, "scripts", "memory_search.py")))}
        values["STOP"] = render("STOP.md", values).strip()
        values["HANDOFF_TEMPLATE"] = render("HANDOFF.md", {"PROJECT": "<проект>",
                                                            "NOW": "ГГГГ-ММ-ДД ЧЧ:ММ"}).strip()
        values["WORKFLOW_DOCS"] = fwd(os.path.join(installed_kit, "docs"))
        values["TRANSFER_PATH"] = fwd(os.path.join(installed_kit, "transfer", "transfer-blocks.js"))
        put_block(doer, os.path.join(tool_dir, spec["rules"]), render("instructions.md", values), "Общие правила")
        put_block(doer, root_rules, render("root-rules.md", values), os.path.basename(root) + " — правила")
        if tool == "codex" and not args.dry_run:
            size, limit = codex_project_rules_budget(tool_dir, root)
            if size > limit:
                say("  ! Для %s проектные правила Codex превышают лимит: %d из %d байт."
                    % (fwd(root), size, limit))
            elif size > limit * 0.9:
                say("  ! Проектные правила для %s: %d из %d байт, до потолка Codex осталось %d."
                    % (fwd(root), size, limit, limit - size))

    for project in args.project or []:
        project = os.path.abspath(os.path.expanduser(project))
        handoff = os.path.join(project, "HANDOFF.md")
        say()
        say("Проект %s:" % fwd(project))
        if not os.path.isdir(project):
            say("  ! папки нет, пропуск")
        elif os.path.exists(handoff):
            say("  HANDOFF.md уже есть, не трогаю")
        else:
            doer.write(handoff, render("HANDOFF.md", {"PROJECT": os.path.basename(project),
                                                     "NOW": time.strftime("%Y-%m-%d %H:%M")}))

    say()
    if args.dry_run:
        say("Изменений было бы: %d. Запусти без --dry-run, чтобы установить." % doer.changed)
        return 0
    for tool in tools:
        profile = Path(profile_dir(args, home, tool))
        stable = profile / "workflow-kit-package"
        for folder, names in (("hooks", HOOK_FILES), ("scripts", SCRIPT_FILES)):
            for name in names:
                if (profile / folder / name).read_bytes() != (stable / folder / name).read_bytes():
                    raise OSError("Установленный файл не совпал с версией комплекта: " + name)

    # Existing indexes are rebuilt by the normal hooks. Preserve user memory while updating.
    if fresh and not notes:
        first = os.path.join(profile_dir(args, home, tools[0]), "scripts")
        for script, extra in (("memory_index.py", [central]), ("project_index.py", [])):
            result = subprocess.run([sys.executable, os.path.join(first, script)] + extra,
                                    capture_output=True, text=True, encoding="utf-8", errors="replace",
                                    env=dict(os.environ, PYTHONIOENCODING="utf-8"))
            say("  " + (result.stdout + result.stderr).strip().replace("\n", "\n  "))
            if result.returncode != 0:
                raise OSError("Не удалось собрать начальное оглавление: " + script)
    say()
    say("Готово, изменений: %d. Дальше:" % doer.changed)
    say("  1. Проверь установку:  python install.py --root %s --check" % quote(root, "claude"))
    say("  2. Открой НОВУЮ сессию агента в папке проекта, где есть HANDOFF.md, и спроси «что у нас с проектом?»")
    if "codex" in tools:
        say("  3. В Codex набери /hooks и подтверди новые хуки: пока им не доверили, Codex их пропускает.")
        say("     Забудешь — агент сам напомнит об этом в начале сессии")
    return 0


def uninstall(args):
    locations = layout(args)
    transaction, _ = transaction_paths(args, locations)
    if transaction.directory.exists():
        raise SystemExit("До отключения восстанови незавершённую установку через --rollback.")
    home, root, tools, projects_dir, central, memory_home = locations
    doer = Doer(args.dry_run)
    say("memory-kit: снимаю хуки и раздел правил. Память не трогаю: " + fwd(central))
    for tool in tools:
        spec = TOOLS[tool]
        tool_dir = profile_dir(args, home, tool)
        hooks_path = os.path.join(tool_dir, spec["hooks_file"])
        if os.path.exists(hooks_path):
            doer.write(hooks_path, dump_json(strip_hooks(load_json(hooks_path), tool_dir)))
        cut_block(doer, os.path.join(tool_dir, spec["rules"]))
        cut_block(doer, os.path.join(root, spec["rules"]))
        doer.remove(os.path.join(tool_dir, "memory-kit.json"))
    say("Изменений: %d. Файлы хуков и скриптов оставлены на месте — без настроек они ничего не делают." % doer.changed)
    return 0


def check(args):
    home, root, tools, projects_dir, central, memory_home = layout(args)
    bad = 0

    def line(ok, text):
        nonlocal bad
        bad += 0 if ok else 1
        say("  [%s] %s" % ("ок" if ok else "НЕТ", text))

    line(os.path.exists(os.path.join(central, "MEMORY.head.md")), "шапка оглавления общей памяти")
    for tool in tools:
        spec = TOOLS[tool]
        tool_dir = profile_dir(args, home, tool)
        say("%s:" % tool)
        line(os.path.exists(os.path.join(tool_dir, "memory-kit.json")), "настройки memory-kit.json")
        for name in HOOK_FILES:
            line(os.path.exists(os.path.join(tool_dir, "hooks", name)), "хук " + name)
        registered = json.dumps(load_json(os.path.join(tool_dir, spec["hooks_file"])).get("hooks", {}))
        for event, _, entry in wanted_hooks(tool, tool_dir):
            line(hook_key(entry["command"], tool_dir).split(":")[0] in registered, "хук прописан: " + event)
        rules = os.path.join(tool_dir, spec["rules"])
        line(os.path.exists(rules) and START in read(rules), "раздел правил в " + spec["rules"])
        if shutil.which("node"):
            r = subprocess.run(["node", os.path.join(tool_dir, "hooks", "session-start-context.js")],
                               cwd=root, capture_output=True, text=True, encoding="utf-8", errors="replace")
            try:                                     # пустой ответ — не успех: хук обязан отдать метку и оглавление
                ctx = json.loads(r.stdout)["hookSpecificOutput"]["additionalContext"]
            except (ValueError, KeyError, TypeError):
                ctx = ""
            line(r.returncode == 0 and HOOKS_ALIVE in ctx, "хук начала сессии отдаёт метку «%s»" % HOOKS_ALIVE)
            index = os.path.join(central, "MEMORY.md")
            if os.path.exists(index) and read(index).strip():
                # в тесном режиме (Codex) вместо оглавления приходит его адрес
                line(read(index).replace("\r\n", "\n").strip()[:200] in ctx.replace("\r\n", "\n")
                     or fwd(index) in ctx,
                     "общее оглавление или его адрес доходит до агента (контекст %d знаков)" % len(ctx))
        if tool == "codex":
            size, limit = codex_project_rules_budget(tool_dir, root)
            line(size <= limit, "проектные правила для %s влезают в потолок Codex: %d из %d байт"
                 % (fwd(root), size, limit))
        r = subprocess.run([sys.executable, os.path.join(tool_dir, "scripts", "memory_index.py"), central, "--dry"],
                           capture_output=True, text=True, encoding="utf-8", errors="replace",
                           env=dict(os.environ, PYTHONIOENCODING="utf-8"))
        line(r.returncode == 0, "сборщик оглавления: " + (r.stdout + r.stderr).strip()[:200])
    say()
    say("Всё на месте." if not bad else "Не хватает пунктов: %d. Запусти установку ещё раз." % bad)
    return 1 if bad else 0


def main():
    for stream in (sys.stdout, sys.stderr):          # чужая консоль может быть не в UTF-8
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    ap = argparse.ArgumentParser(description="Установщик Workflow Kit для Codex Desktop на Windows")
    ap.add_argument("--root", required=True, help="корневая папка, в которой лежат проекты")
    ap.add_argument("--tool", choices=["codex"], help="профиль Codex (по умолчанию)")
    ap.add_argument("--project", action="append", help="папка проекта, где завести HANDOFF.md (можно несколько раз)")
    ap.add_argument("--memory", help="где держать память (по умолчанию ~/.agent-memory)")
    ap.add_argument("--codex-home", help="полный путь к выбранному профилю Codex")
    ap.add_argument("--home", help="другая домашняя папка (для проверки в песочнице)")
    ap.add_argument("--dry-run", action="store_true", help="только показать, что изменится")
    ap.add_argument("--check", action="store_true", help="проверить установку")
    ap.add_argument("--uninstall", action="store_true", help="снять хуки и раздел правил (память остаётся)")
    ap.add_argument("--rollback", action="store_true", help="восстановить файлы после прерванной установки")
    args = ap.parse_args()
    if args.rollback:
        transaction, allowed = transaction_paths(args, layout(args))
        if args.dry_run:
            say("Есть незавершённая установка." if transaction.directory.exists() else "Восстанавливать нечего.")
        else:
            say("Прежнее состояние восстановлено." if transaction.recover(allowed) else "Восстанавливать нечего.")
        return 0
    if args.check:
        return check(args)
    if args.uninstall:
        return uninstall(args)
    return install(args)


if __name__ == "__main__":
    sys.exit(main())
