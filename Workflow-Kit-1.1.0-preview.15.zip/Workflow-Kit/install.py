#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Установщик Workflow Kit для Codex Desktop на Windows.

Что делает (и только это):
  * создаёт папку общей памяти и её подпапки, шапку оглавления;
  * копирует хуки и скрипты в выбранный профиль Codex (обычно ~/.codex);
  * прописывает хуки в настройки агента, сохранив прежний файл рядом (.bak-дата);
  * дописывает раздел правил в общий файл правил агента и шаблон HANDOFF в файл правил
    корневой папки проектов — строго между метками memory-kit, остальное не трогает.

Запуск:
  python install.py --root <корневая папка проектов> --dry-run     # показать, что изменится
  python install.py --root <корневая папка проектов>               # установить
  python install.py --root <...> --project <папка проекта>          # и завести в проекте HANDOFF.md
  python install.py --root <...> --check                            # проверить установку
  python install.py --root <...> --uninstall                        # снять хуки и раздел правил

  --tool codex              можно опустить
  --memory <папка>           где держать память; по умолчанию ~/.agent-memory
  --home <папка>             другая домашняя папка (для проверки в песочнице)

Память при --uninstall не удаляется никогда.
"""
import argparse
import codecs
import glob
import hashlib
import json
import os
import re
import runpy
import shutil
import subprocess
import sys
import time

import tempfile
from contextlib import ExitStack, contextmanager
from pathlib import Path

KIT = os.path.dirname(os.path.abspath(__file__))
CHECK_HELPERS = runpy.run_path(os.path.join(KIT, "scripts", "kit_check.py"))
codex_project_rules_budget = CHECK_HELPERS["codex_project_rules_budget"]
START, END = "<!-- memory-kit:start -->", "<!-- memory-kit:end -->"
ROOT_OWNERS = "<!-- workflow-kit-root-owners: "
ADVISOR = "session-advisor.cjs"
ADVISOR_EVENTS = ("UserPromptSubmit", "PreToolUse", "PostToolUse", "PreCompact", "Stop")
# Exact hashes from the formerly published standalone archives, versions 1.0.0–1.0.5.
LEGACY_ADVISOR_HASHES = {
    "382d2574be6e05d4fff42cda942ed32bbf61f719db0d11f5cd6b28450cbe9873",
    "95e6a80cc0cd9efe822c89fdaa5d27afd6a3b5f296c204ead65ece27a4d4bbcd",
    "77eee89095264a9eb5924876d5939493770eb991dbffbea30afc5b558a18d2ab",
    "d0a26a5b2cb840563e28f17013a0675b7855fa9e81a3882af7bd2800d67b1145",
    "01afa2c66d2dbde2db0573fd2041afef4b15d02aff6577be2cff009bd00e27d5",
    "9c83e091e6ff0524f7fbe547f7093f362ecb6222e3d54ce3864abcafa87a55f4",
}
HOOK_FILES = ["kit.js", "session-start-context.js", "session-summary-check.js", "memory-index-hook.py",
              "memory-recall-hook.py", "session-advisor.cjs"]
SCRIPT_FILES = ["memory_index.py", "memory_search.py", "session_archive.py", "project_index.py", "kit_check.py",
                "memory_report.py", "memory_upkeep.py",
                "find-zombies.ps1"]
MEMORY_DIRS = ["feedback", "ref", "projects", "plans", "research", "reviews"]
STAMP = time.strftime("%Y%m%d-%H%M%S")
HOOKS_ALIVE = "memory-kit: хуки работают"      # та же строка — в hooks/kit.js

TOOLS = {
    # start_max_chars: Codex пропускает к модели около 6,5 тыс. знаков вывода хука, остальное вырезает
    "codex": {"dir": ".codex", "hooks_file": "hooks.json", "rules": "AGENTS.md", "inject_project_index": True,
              "start_max_chars": 5800},
}

AUTOLOAD = {
    "codex": (
        "Оглавления памяти (`MEMORY.md` общей памяти и памяти проекта) подкладывает в контекст хук\n"
        "начала сессии. Файлы правил открывай по ссылкам из оглавления, когда задача их касается.\n"
        "Всё, что нужно запомнить, пиши файлами в папки выше по правилам ниже — так память\n"
        "остаётся общей для всех агентов на этой машине."
    ),
}

# Строка-метка должна совпадать с HOOKS_ALIVE в hooks/kit.js
HOOKCHECK_HEAD = (
    "Это правило выполняется раньше любого другого и раньше ответа на вопрос человека.\n"
    "Найди в контексте дословную строку `memory-kit: хуки работают` (её кладёт хук начала\n"
    "сессии). Строка есть — ничего не говори об этом и работай. Строки НЕТ — свой первый ответ\n"
    "в сессии, каким бы коротким ни был вопрос, начни с этого предупреждения дословно\n"
    "и только потом отвечай по делу:\n\n"
)
HOOKCHECK = {
    "codex": HOOKCHECK_HEAD + (
        "> ⚠️ Память memory-kit не подключена: Codex не запускает хуки, пока им не доверили.\n"
        "> Набери `/hooks`, подтверди хуки memory-kit и открой новую сессию.\n\n"
        "Сам подтвердить хуки ты не можешь, это делает только человек. Одного раза за сессию\n"
        "достаточно; в следующей сессии проверь заново."
    ),
}


def say(text=""):
    print(text)


def fwd(path):
    return path.replace("\\", "/")


def slug(path):
    """Имя папки памяти: всё, кроме латинских букв и цифр, в дефис."""
    return re.sub(r"[^A-Za-z0-9]", "-", os.path.abspath(path))


def slug_dir(projects_dir, path):
    """Существующая папка с таким именем без учёта регистра (буква диска на Windows гуляет) или новая."""
    want = slug(path)
    if os.path.isdir(projects_dir):
        for name in os.listdir(projects_dir):
            if name.lower() == want.lower():
                return os.path.join(projects_dir, name)
    return os.path.join(projects_dir, want)


def read(path):
    return decode_text(path, Path(path).read_bytes())


def decode_text(path, data):
    try:
        text = data.decode("utf-8-sig")
        if "\0" not in text:
            return text
    except UnicodeDecodeError:
        pass
    raise SystemExit("Файл должен быть в UTF-8 (с BOM или без): " + fwd(os.fspath(path)))


def line_ending(text):
    return "\r\n" if "\r\n" in text and "\n" not in text.replace("\r\n", "") else "\n"


def profile_dir(args, home, tool):
    explicit = args.codex_home if tool == "codex" else None
    if tool == "codex" and not args.home and not explicit:
        explicit = os.environ.get("CODEX_HOME")
    return os.path.abspath(explicit) if explicit else os.path.join(home, TOOLS[tool]["dir"])


def atomic_write(path, data, *, prefix="tmp"):
    path = Path(path)
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix=prefix, delete=False) as temporary:
        temp = Path(temporary.name)
        temporary.write(data)
        temporary.flush()
        os.fsync(temporary.fileno())
    try:
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def digest(data):
    return hashlib.sha256(data).hexdigest() if data is not None else None


def installed_bytes(path):
    return path.read_bytes() if path.exists() else None


class InstallTransaction:
    def __init__(self, directory, root):
        self.directory = directory
        self.journal = directory / "journal.json"
        self.root = Path(root).resolve()
        self.reservation = self.root / ".workflow-kit.pending.json"
        self.profile = directory.parent.resolve()
        self.stage_prefix = ".workflow-kit-" + path_key(self.profile)[:16] + "-"
        self.record = {"committed": False, "files": [], "root": str(self.root)}

    def reservation_owner(self):
        if not os.path.lexists(self.reservation):
            return None
        try:
            marker = json.loads(read(self.reservation))
            profile = marker["profile"]
            if isinstance(profile, str) and Path(profile).is_absolute():
                return Path(profile).resolve()
        except (OSError, ValueError, TypeError, KeyError):
            pass
        raise SystemExit("Не удалось прочитать запись о незавершённой операции: " + fwd(self.reservation))

    def require_available_root(self, recovering=False):
        owner = self.reservation_owner()
        if owner is None:
            return
        if recovering and owner == self.profile and self.directory.is_dir():
            return
        raise SystemExit("Общий корень ожидает восстановления профиля " + fwd(owner) +
                         ". Запусти --rollback с этим корнем и указанным профилем.")

    def begin(self):
        self.directory.parent.mkdir(parents=True, exist_ok=True)
        self.directory.mkdir()
        self.save()
        if self.root.is_dir():
            self.write(self.reservation, dump_json({"profile": str(self.profile)}).encode("utf-8"))

    def save(self):
        self.write(self.journal, dump_json(self.record).encode("utf-8"))

    def write(self, path, data):
        atomic_write(path, data, prefix=self.stage_prefix)

    def replace(self, path, data):
        path = Path(path)
        old = installed_bytes(path)
        if old == data:
            return
        index = len(self.record["files"])
        if old is not None:
            self.write(self.directory / f"old-{index}", old)
        self.record["files"].append({"path": str(path.resolve()), "old": digest(old),
                                     "new": digest(data), "index": index})
        self.save()
        if data is None:
            path.unlink()
        else:
            self.write(path, data)

    def complete(self):
        self.record["committed"] = True
        self.save()
        self.clean()

    def is_stage(self, path):
        return (not path.is_symlink() and path.is_file()
                and re.fullmatch(re.escape(self.stage_prefix) + r"[a-z0-9_]{8}", path.name))

    def is_legacy_initial_journal(self, path):
        if self.journal.exists() or not re.fullmatch(r"tmp[a-z0-9_]{8}", path.name):
            return False
        try:
            data = json.loads(read(path))
            return (data == {"committed": False, "files": [], "root": str(self.root)}
                    and not path.is_symlink() and path.is_file())
        except (OSError, ValueError):
            return False

    def pending_files(self):
        files = []
        for path in self.directory.iterdir():
            if path.is_symlink() or not path.is_file():
                raise SystemExit("В папке отката есть посторонний объект: " + fwd(path))
            if path == self.journal:
                continue
            if self.is_stage(path) or re.fullmatch(r"old-[0-9]+", path.name) or self.is_legacy_initial_journal(path):
                files.append(path)
            else:
                raise SystemExit("В папке отката есть посторонний файл: " + fwd(path))
        return files

    def clean(self):
        # Also remove staged files from an interrupted atomic write beside a target.
        parents = {self.root, *(Path(entry["path"]).parent for entry in self.record["files"])}
        for path in self.pending_files():
            path.unlink()
        for parent in parents - {self.directory}:
            for path in parent.glob(self.stage_prefix + "*"):
                if self.is_stage(path):
                    path.unlink()
        if self.reservation_owner() == self.profile:
            self.reservation.unlink()
        self.journal.unlink(missing_ok=True)
        self.directory.rmdir()

    def recover(self, allowed_roots):
        if not self.directory.exists():
            return False
        # Check for unexpected files before restoring or deleting anything.
        pending = self.pending_files()
        if self.journal.is_file():
            self.record = json.loads(self.journal.read_text(encoding="utf-8"))
        recorded_root = self.record.get("root")
        if recorded_root is not None and Path(recorded_root).resolve() != self.root:
            raise SystemExit("Для восстановления укажи исходный корень проектов: " + fwd(recorded_root))
        roots = [Path(root).resolve() for root in allowed_roots]
        for entry in self.record["files"]:
            path = Path(entry["path"]).resolve()
            if not any(root in path.parents for root in roots):
                raise ValueError("Путь восстановления вне установки: " + str(path))
        if not self.record["committed"]:
            restore = []
            for entry in reversed(self.record["files"]):
                path = Path(entry["path"]).resolve()
                current = digest(installed_bytes(path))
                if current == entry["old"]:
                    continue
                if current != entry["new"]:
                    raise ValueError("Файл изменён после прерывания: " + str(path))
                original = None
                if entry["old"] is not None:
                    original = (self.directory / f"old-{entry['index']}").read_bytes()
                    if digest(original) != entry["old"]:
                        raise ValueError("Резервная копия повреждена: " + str(path))
                restore.append((path, original))
            for path, original in restore:
                if original is None:
                    path.unlink(missing_ok=True)
                else:
                    self.write(path, original)
        if not self.journal.exists():
            for path in pending:
                if self.is_legacy_initial_journal(path):
                    path.unlink()
        # A crash during cleanup must never allow a later recovery to restore files again.
        self.complete()
        return True


class Doer:
    """Все записи идут через него: в режиме --dry-run только печатает."""

    def __init__(self, dry, transaction=None):
        self.dry = dry
        self.transaction = transaction
        self.changed = 0

    def mkdir(self, path):
        if not os.path.isdir(path):
            say("  + папка   " + fwd(path))
            self.changed += 1
            if not self.dry:
                os.makedirs(path, exist_ok=True)

    def write(self, path, text, backup=True, *, native_newlines=False):
        data = installed_bytes(Path(path))
        old = decode_text(path, data) if data is not None else None
        if old is not None and not native_newlines:
            text = text.replace("\r\n", "\n").replace("\n", line_ending(old))
        bom = codecs.BOM_UTF8 if data and data.startswith(codecs.BOM_UTF8) else b""
        encoded = bom + text.encode("utf-8")
        if data == encoded:
            return False
        say("  %s файл    %s" % ("~" if old is not None else "+", fwd(path)))
        self.changed += 1
        if self.dry:
            return True
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if old is not None and backup:
            shutil.copy2(path, path + ".bak-" + STAMP)
            say("    прежний сохранён: " + fwd(path) + ".bak-" + STAMP)
        self.replace(path, encoded)
        return True

    def copy(self, src, dst):
        with open(src, "rb") as fh:
            data = fh.read()
        if os.path.exists(dst):
            with open(dst, "rb") as fh:
                if fh.read() == data:
                    return
        say("  %s файл    %s" % ("~" if os.path.exists(dst) else "+", fwd(dst)))
        self.changed += 1
        if self.dry:
            return
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        if os.path.exists(dst):
            shutil.copy2(dst, dst + ".bak-" + STAMP)
        self.replace(dst, data)

    def replace(self, path, data):
        if self.transaction is None:
            atomic_write(path, data)
        else:
            self.transaction.replace(path, data)

    def remove(self, path):
        if os.path.exists(path):
            say("  - файл    " + fwd(path))
            self.changed += 1
            if not self.dry:
                if self.transaction is None:
                    os.remove(path)
                else:
                    self.transaction.replace(path, None)


# ---------- хуки в настройках агента ----------

def quote(path, tool):
    p = fwd(path)
    if re.fullmatch(r"[\w./:-]+", p):
        return p
    if os.name == "nt":
        # Double quotes work in PowerShell and cmd for ordinary paths, including apostrophes.
        return '"' + p.replace("`", "``").replace("$", "`$") + '"'
    return "'" + p.replace("'", "'\"'\"'") + "'"


def python_cmd():
    exe = sys.executable or ""
    if exe and " " not in exe:
        return fwd(exe)
    return "python" if os.name == "nt" else "python3"


def wanted_hooks(tool, tool_dir):
    hooks = os.path.join(tool_dir, "hooks")
    node = lambda name: "node " + quote(os.path.join(hooks, name), tool)
    py = lambda name, arg: "%s %s %s" % (python_cmd(), quote(os.path.join(hooks, name), tool), arg)
    out = [
        ("SessionStart", "", {"type": "command", "command": node("session-start-context.js")}),
        ("PreCompact", "", {"type": "command", "command": node("session-start-context.js") + " precompact"}),
        ("Stop", "", {"type": "command", "command": node("session-summary-check.js")}),
        ("Stop", "", {"type": "command", "command": py("memory-index-hook.py", "stop"), "timeout": 60}),
    ]
    # память в нужный момент: правила перед коммитом и сервером, по словам просьбы, короткий контекст помощнику.
    # Codex зовёт команды оболочки именем Bash и принимает на этих событиях и отказ, и добавку в контекст
    # (его документация по хукам, сверено 13.10.2026)
    out.append(("PreToolUse", "Bash",
                {"type": "command", "command": py("memory-recall-hook.py", "pre"), "timeout": 10}))
    out.append(("UserPromptSubmit", "",
                {"type": "command", "command": py("memory-recall-hook.py", "prompt"), "timeout": 10}))
    out.append(("SubagentStart", "",
                {"type": "command", "command": py("memory-recall-hook.py", "subagent"), "timeout": 10}))
    # Keep the standalone command spelling to preserve an unchanged registration on upgrade.
    advisor_path = fwd(os.path.join(hooks, ADVISOR))
    advisor_arg = quote(advisor_path, tool)
    if advisor_arg == advisor_path:
        advisor_arg = '"' + advisor_path + '"'
    out.extend((event, "", {"type": "command", "command": "node " + advisor_arg, "timeout": 5})
               for event in ADVISOR_EVENTS)
    return out


def hook_key(command, tool_dir):
    """Recognize only an explicit path to an installed memory-kit handler."""
    if not isinstance(command, str):
        return None
    normalized = fwd(command)
    if os.name == "nt":
        normalized = normalized.casefold()
    for name in HOOK_FILES:
        path = fwd(os.path.join(tool_dir, "hooks", name))
        variants = (path, quote(path, "codex"), "'" + path.replace("'", "''") + "'")
        if os.name == "nt":
            variants = tuple(variant.casefold() for variant in variants)
        if any(re.search(r"""(?:^|[\s"'])""" + re.escape(variant) + r"""(?=$|[\s"'])""", normalized)
               for variant in variants):
            mode = next((m for m in ("stop", "post", "pre", "prompt", "subagent", "precompact")
                         if normalized.rstrip().endswith(" " + m)), "")
            return name + ":" + mode
    return None


def merge_hooks(settings, tool, tool_dir):
    hooks = settings.setdefault("hooks", {})
    for event, matcher, entry in wanted_hooks(tool, tool_dir):
        key = hook_key(entry["command"], tool_dir)
        found = False
        for registered_event, groups in list(hooks.items()):
            for group in groups:
                handlers = []
                for handler in group.get("hooks", []):
                    if (handler.get("type") != "command"
                            or hook_key(handler.get("command", ""), tool_dir) != key
                            or (key == ADVISOR + ":" and registered_event != event
                                and registered_event in ADVISOR_EVENTS)):
                        handlers.append(handler)
                    elif not found and registered_event == event and group.get("matcher", "") == matcher:
                        handlers.append({**handler, **entry})
                        found = True
                group["hooks"] = handlers
            hooks[registered_event] = [group for group in groups if group.get("hooks")]
        if found:
            continue
        groups = hooks.setdefault(event, [])
        target = next((group for group in groups if group.get("matcher", "") == matcher), None)
        if target is None:
            target = {"matcher": matcher, "hooks": []}
            groups.append(target)
        target.setdefault("hooks", []).append(entry)
    return settings


WRITABLE_END = "# workflow-kit:writable-roots end"
WRITABLE_START = re.compile(r"(?m)^# workflow-kit:writable-roots ([0-9a-f]{64}) ([012]) (new|existing)\r?\n")
WRITABLE_TABLE = "[sandbox_workspace_write]"


def writable_block(text):
    """Locate the package-owned section and validate its unchanged content."""
    starts = list(WRITABLE_START.finditer(text))
    if len(starts) != 1:
        return None
    start = starts[0]
    end = re.search(r"(?m)^" + re.escape(WRITABLE_END) + r"(?:\r?\n|$)", text[start.end():])
    if not end:
        return None
    body = text[start.end():start.end() + end.start()].replace("\r\n", "\n")
    if digest(body.encode("utf-8")) != start[1] or not body.startswith(WRITABLE_TABLE + "\n"):
        return None
    return start, start.end() + end.end()


def codex_writable_note(doer, tool_dir, roots):
    """Grant rights only when Codex doesn't already have a sandbox section."""
    path = os.path.join(tool_dir, "config.toml")
    existed = os.path.exists(path)
    text = read(path) if existed else ""
    if writable_block(text):
        return
    tomllib = CHECK_HELPERS.get("tomllib")
    if tomllib is not None:
        try:
            has_section = "sandbox_workspace_write" in tomllib.loads(text)
        except ValueError:
            say("  ! Не удалось разобрать config.toml. Права записи в этом файле не изменены.")
            return
    else:
        has_section = re.search(r"(?m)^[ \t]*(?:\[\[?[ \t]*)?[\"']?sandbox_workspace_write\b", text)
    if has_section:
        say("  ! в config.toml уже есть [sandbox_workspace_write]. При необходимости дополни writable_roots:")
        for root in roots:
            say("    " + fwd(root))
        return
    body = WRITABLE_TABLE + "\nwritable_roots = " + json.dumps([fwd(root) for root in roots], ensure_ascii=False) + "\n"
    separator = "" if not text else "\n" * (1 if text.endswith("\n") else 2)
    start = "# workflow-kit:writable-roots %s %d %s\n" % (
        digest(body.encode("utf-8")), len(separator), "existing" if existed else "new")
    addition = (separator + start + body + WRITABLE_END + "\n").replace("\n", line_ending(text))
    doer.write(path, text + addition, native_newlines=True)


def cut_codex_writable_block(doer, tool_dir):
    path = os.path.join(tool_dir, "config.toml")
    if not os.path.exists(path):
        return
    text = read(path)
    block = writable_block(text)
    if not block:
        if "# workflow-kit:writable-roots " in text:
            say("  Блок writable_roots изменён вручную. Его содержимое сохранено.")
        return
    start, end = block
    prefix, suffix = text[:start.start()], text[end:]
    if not suffix and start[2] != "0":
        trailing = re.search(r"(?:\r?\n){%s}$" % start[2], prefix)
        if trailing:
            prefix = prefix[:trailing.start()]
    # Keys appended before the next table still belong to this table.
    follows = re.split(r"(?m)^[ \t]*\[", suffix, maxsplit=1)[0]
    if any(line.strip() and not line.lstrip().startswith("#") for line in follows.splitlines()):
        prefix += WRITABLE_TABLE + line_ending(text)
    if not prefix and not suffix and start[3] == "new":
        doer.remove(path)
    else:
        doer.write(path, prefix + suffix, native_newlines=True)


def strip_hooks(settings, tool, tool_dir):
    hooks = settings.get("hooks", {})
    owned = {(event, hook_key(entry["command"], tool_dir))
             for event, _, entry in wanted_hooks(tool, tool_dir)}
    for event in list(hooks):
        for g in hooks[event]:
            g["hooks"] = [h for h in g.get("hooks", [])
                          if h.get("type") != "command"
                          or (event, hook_key(h.get("command", ""), tool_dir)) not in owned]
        hooks[event] = [g for g in hooks[event] if g.get("hooks")]
        if not hooks[event]:
            del hooks[event]
    return settings


def load_json(path):
    if not os.path.exists(path):
        return {}
    try:
        return json.loads(read(path) or "{}")
    except ValueError as e:
        raise SystemExit("Не могу разобрать %s (%s). Ничего не тронул — поправь файл и запусти снова." % (fwd(path), e))


def dump_json(data):
    return json.dumps(data, ensure_ascii=False, indent=2) + "\n"


# ---------- раздел правил между метками ----------

def put_block(doer, path, block, title):
    block = START + "\n" + block.strip("\n") + "\n" + END
    if os.path.exists(path):
        text = read(path)
        newline = line_ending(text)
        block = block.replace("\n", newline)
        if START in text and END in text:
            new = text[:text.index(START)] + block + text[text.index(END) + len(END):]
        else:
            separator = newline if text and not text.endswith("\n") else ""
            new = text + separator + block + newline
    else:
        new = "# " + title + "\n\n" + block + "\n"
    doer.write(path, new, native_newlines=True)


def cut_block(doer, path):
    if not os.path.exists(path):
        return
    text = read(path)
    if START in text and END in text:
        prefix, suffix = text[:text.index(START)], text[text.index(END) + len(END):]
        if not prefix or prefix.endswith("\n"):
            suffix = re.sub(r"^\r?\n", "", suffix, count=1)
        doer.write(path, prefix + suffix, native_newlines=True)


def path_key(path):
    return hashlib.sha256(os.fsencode(os.path.normcase(str(Path(path).resolve())))).hexdigest()


@contextmanager
def installation_lock(key):
    """Serialize updates on Windows without adding files to the project."""
    if os.name != "nt":
        yield
        return
    import ctypes
    from ctypes import wintypes

    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateMutexW.argtypes = (wintypes.LPVOID, wintypes.BOOL, wintypes.LPCWSTR)
    kernel.CreateMutexW.restype = wintypes.HANDLE
    kernel.WaitForSingleObject.argtypes = (wintypes.HANDLE, wintypes.DWORD)
    kernel.WaitForSingleObject.restype = wintypes.DWORD
    kernel.ReleaseMutex.argtypes = kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
    handle = kernel.CreateMutexW(None, False, "Local\\CodexWorkflowKit-" + key)
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        result = kernel.WaitForSingleObject(handle, 10000)
        if result not in (0, 0x80):  # acquired normally or after an interrupted process
            if result == 0x102:
                raise SystemExit("Другая операция Workflow Kit ещё выполняется. Повтори после её завершения.")
            raise ctypes.WinError(ctypes.get_last_error())
        try:
            yield
        finally:
            kernel.ReleaseMutex(handle)
    finally:
        kernel.CloseHandle(handle)


def read_root_block(path):
    """Return the shared block and its owners. A legacy block has unknown owners."""
    text = read(path) if os.path.exists(path) else ""
    if START not in text and END not in text:
        return "", set()
    if text.count(START) != 1 or text.count(END) != 1 or text.index(START) > text.index(END):
        raise SystemExit("Не удалось однозначно найти границы общего блока правил: " + fwd(path))
    body = text.split(START, 1)[1].split(END, 1)[0].replace("\r\n", "\n").strip("\n")
    markers = [line for line in body.splitlines() if line.startswith(ROOT_OWNERS)]
    if not markers:
        return body, None
    if len(markers) != 1 or not re.fullmatch(re.escape(ROOT_OWNERS) + r"[0-9a-f]{64}(,[0-9a-f]{64})* -->", markers[0]):
        raise SystemExit("Не удалось подтвердить владельцев общего блока правил: " + fwd(path))
    marker = markers[0]
    return "\n".join(line for line in body.splitlines() if line != marker), set(marker[len(ROOT_OWNERS):-4].split(","))


def put_root_block(doer, path, title, body, owners):
    marker = ROOT_OWNERS + ",".join(sorted(owners)) + " -->"
    put_block(doer, path, marker + "\n" + body, title)


def render(name, values):
    text = read(os.path.join(KIT, "templates", name)).replace("\r\n", "\n")
    for k, v in values.items():
        text = text.replace("{{" + k + "}}", v)
    return text


def zombies_text(tool_dir):
    if os.name == "nt":
        scanner = fwd(os.path.join(tool_dir, "scripts", "find-zombies.ps1")).replace("'", "''")
        return ("Запусти `powershell -NoProfile -File '%s'`.\n"
                "   Он показывает возможные осиротевшие серверы и инструменты. Найденное покажи списком.\n"
                "   После решения владельца скопируй из показанного списка только выбранные значения Selection.\n"
                "   Для остановки владелец передаёт их через `-Kill -Selection <значение>`.\n"
                "   Сам ничего не убивай." % scanner)
    return ("Проверь через `ps`, не остались ли запущенные в этой сессии серверы разработки\n"
            "   и фоновые команды. Найденное покажи списком и спроси, что остановить. Сам ничего не убивай.")


# ---------- действия ----------

def layout(args):
    home = os.path.abspath(os.path.expanduser(args.home or "~"))
    root = os.path.abspath(os.path.expanduser(args.root))
    tools = ["codex"]
    if not args.memory:
        cfg = load_json(os.path.join(profile_dir(args, home, "codex"), "memory-kit.json"))
        if cfg.get("central"):
            central = os.path.abspath(os.path.expanduser(cfg["central"]))
            memory_home = os.path.dirname(central) if os.path.basename(central) == "central" else central
            projects_dir = cfg.get("projects_dir") or os.path.join(memory_home, "projects")
            return home, root, tools, os.path.abspath(os.path.expanduser(projects_dir)), central, memory_home
    memory_home = os.path.abspath(os.path.expanduser(args.memory)) if args.memory else os.path.join(home, ".agent-memory")
    central = os.path.join(memory_home, "central")
    projects_dir = os.path.join(memory_home, "projects")
    return home, root, tools, projects_dir, central, memory_home


def review_existing_install(args, home, tools):
    for tool in tools:
        spec = TOOLS[tool]
        tool_dir = profile_dir(args, home, tool)
        cfg = load_json(os.path.join(tool_dir, "memory-kit.json"))
        registrations = load_json(os.path.join(tool_dir, spec["hooks_file"])).get("hooks", {})
        if any("/workflow-kit/wk_runtime.py" in fwd(handler.get("command", "")).casefold()
               for groups in registrations.values() for group in groups for handler in group.get("hooks", [])):
            raise SystemExit("Обнаружены хуки Workflow Kit 1.0.0. Перед установкой отключи их штатным способом или выбери отдельный профиль. Файлы не изменены.")
        previous = cfg.get("kit_dir")
        installed_kit = Path(tool_dir) / "workflow-kit-package"
        tracked = load_json(installed_kit / "installed-files.json")
        for name in package_files():
            dest = installed_kit / name
            if not dest.exists():
                continue
            known = (tracked.get(fwd(name)), digest((Path(KIT) / name).read_bytes()))
            if not dest.is_file() or digest(dest.read_bytes()) not in known:
                raise SystemExit("Локальная правка в установленном комплекте: " + str(dest) +
                                 ". Сначала сохрани её отдельно и проверь обновление.")
        for folder, names in (("hooks", HOOK_FILES), ("scripts", SCRIPT_FILES)):
            for name in names:
                installed = os.path.join(tool_dir, folder, name)
                if not os.path.lexists(installed):
                    continue
                if (name == ADVISOR and os.path.isfile(installed)
                        and digest(Path(installed).read_bytes()) in LEGACY_ADVISOR_HASHES):
                    continue
                sources = [os.path.join(KIT, folder, name)]
                if isinstance(previous, str) and os.path.isabs(previous):
                    sources.append(os.path.join(previous, folder, name))
                if (not os.path.isfile(installed) or
                        not any(os.path.isfile(source) and read(source).replace("\r\n", "\n") ==
                                read(installed).replace("\r\n", "\n") for source in sources)):
                    raise SystemExit("Не подтверждено происхождение файла: " + fwd(installed) +
                                     ". Проверь локальные правки или прежний исходный набор. Файлы не изменены.")


def transaction_paths(args, locations):
    home, root, tools, projects_dir, central, _ = locations
    profiles = [profile_dir(args, home, tool) for tool in tools]
    return InstallTransaction(Path(profiles[0]) / "workflow-kit.pending", root), [*profiles, root, central, projects_dir]


def validate_profile_text(profile, spec):
    for name in (spec["rules"], spec["hooks_file"], "config.toml", "memory-kit.json"):
        path = Path(profile) / name
        if path.exists():
            read(path)


def install(args):
    locations = layout(args)
    home, root, tools, projects_dir, central, _ = locations
    if not os.path.isdir(root):
        raise SystemExit("Корневой папки проектов нет: " + fwd(root))
    resolved_root = Path(root).resolve()
    for project in args.project or []:
        path = Path(project).expanduser().absolute()
        resolved = path.resolve()
        handoff = (path / "HANDOFF.md").resolve()
        if (resolved != resolved_root and resolved_root not in resolved.parents) or resolved_root not in handoff.parents:
            raise SystemExit("Папка --project находится вне корня проектов: " + fwd(str(path)))
    transaction, allowed = transaction_paths(args, locations)
    if transaction.directory.exists():
        raise SystemExit("Найдено незавершённое обновление. Запусти установщик с теми же параметрами и --rollback.")
    transaction.require_available_root()
    for tool in tools:
        tool_dir = profile_dir(args, home, tool)
        validate_profile_text(tool_dir, TOOLS[tool])
        cfg = load_json(os.path.join(tool_dir, "memory-kit.json"))
        installed_root = cfg.get("root")
        if installed_root and Path(installed_root).resolve() != Path(root).resolve():
            raise SystemExit("Профиль уже настроен на другую папку проектов: " + fwd(installed_root) +
                             ". Сначала отключи комплект с прежним корнем и тем же профилем, затем установи с новым корнем.")
        read_root_block(os.path.join(root, TOOLS[tool]["rules"]))
    verify_package_manifest()
    review_existing_install(args, home, tools)
    if args.dry_run:
        return apply_install(args, locations, Doer(True))
    transaction.begin()
    try:
        result = apply_install(args, locations, Doer(False, transaction))
    except BaseException:
        transaction.recover(allowed)
        raise
    transaction.complete()
    return result


def verify_package_manifest():
    root = Path(KIT).resolve()
    manifest = root / "SHA256SUMS.json"
    if not manifest.is_file():
        return
    checksums = load_json(manifest)
    for name in checksums:
        path = (root / name).resolve()
        if root not in path.parents or not path.is_file() or digest(path.read_bytes()) != checksums[name]:
            raise SystemExit("Контрольная сумма комплекта не совпала: " + name)
    missing = set(map(fwd, package_files())) - checksums.keys()
    if missing:
        raise SystemExit("Контрольная сумма отсутствует для файлов: " + ", ".join(sorted(missing)))


def package_files():
    names = ["install.py", "НАЧАТЬ.md", "INSTALL.md", "LICENSE", "LICENSE-WORKFLOW", "release.json"]
    for folder in ("docs", "templates", "hooks", "scripts", "transfer", "tutorial"):
        location = Path(KIT) / folder
        names.extend(str(path.relative_to(KIT)) for path in sorted(location.rglob("*"))
                     if path.is_file() and "__pycache__" not in path.parts)
    return names


def apply_install(args, locations, doer):
    home, root, tools, projects_dir, central, memory_home = locations
    say("memory-kit: %s" % ("пробный прогон, ничего не пишу" if args.dry_run else "установка"))
    say("  агенты:        " + ", ".join(tools))
    say("  корень:        " + fwd(root))
    say("  общая память:  " + fwd(central))
    say("  память проектов: " + fwd(projects_dir) + "/<имя>/memory")
    say()
    for need in ("node", "git"):
        if not shutil.which(need):
            say("  ! не найден %s — хук начала сессии без него работать не будет" % need)

    say("Память:")
    for d in MEMORY_DIRS:
        doer.mkdir(os.path.join(central, d))
    head = os.path.join(central, "MEMORY.head.md")
    fresh = not os.path.exists(head)
    notes = glob.glob(os.path.join(central, "**", "*.md"), recursive=True)
    if fresh and notes:
        # Первая сборка переписывает оглавление и дописывает служебные строки в начало файлов памяти
        backup = central.rstrip("\\/") + ".bak-" + STAMP
        say("  ! первая сборка оглавления: перепишет MEMORY.md и INDEX.md, а в файлы памяти (%d) допишет служебные строки" % len(notes))
        say("    копия всей папки памяти: " + fwd(backup))
        if not args.dry_run:
            shutil.copytree(central, backup)
    if fresh:
        doer.write(head, render("MEMORY.head.md", {}), backup=False)
        feedback = os.path.join(central, "feedback")
        if not os.path.isdir(feedback) or not os.listdir(feedback):
            doer.copy(os.path.join(KIT, "templates", "feedback_example.md"),
                      os.path.join(feedback, "feedback_example.md"))

    for tool in tools:
        spec = TOOLS[tool]
        tool_dir = profile_dir(args, home, tool)
        installed_kit = os.path.join(tool_dir, "workflow-kit-package")
        installed_files = {}
        for name in package_files():
            source = Path(KIT) / name
            doer.copy(source, os.path.join(installed_kit, name))
            installed_files[fwd(name)] = digest(source.read_bytes())
        doer.write(os.path.join(installed_kit, "installed-files.json"), dump_json(installed_files))
        say()
        say("%s (%s):" % (tool, fwd(tool_dir)))
        for name in HOOK_FILES:
            doer.copy(os.path.join(KIT, "hooks", name), os.path.join(tool_dir, "hooks", name))
        for name in SCRIPT_FILES:
            doer.copy(os.path.join(KIT, "scripts", name), os.path.join(tool_dir, "scripts", name))
        cfg = {"tool": tool, "root": root, "projects_dir": projects_dir, "central": central,
               "inject_index": True, "inject_project_index": spec["inject_project_index"],
               "sync_on_start": True, "journal_entries": 3,
               "kit_dir": fwd(installed_kit)}           # по нему хук начала сессии и kit_check сверяют установку с набором
        if spec.get("start_max_chars"):
            cfg["start_max_chars"] = spec["start_max_chars"]
        cfg_path = os.path.join(tool_dir, "memory-kit.json")
        if os.path.exists(cfg_path):                 # ручные правки настроек переживают переустановку
            try:
                kept = json.loads(read(cfg_path))
                for k, v in kept.items():            # всё, кроме адресов: их задаёт этот запуск
                    if k not in ("tool", "root", "projects_dir", "central", "kit_dir"):
                        cfg[k] = v
            except ValueError:
                pass
        doer.write(cfg_path, dump_json(cfg))
        hooks_path = os.path.join(tool_dir, spec["hooks_file"])
        settings = merge_hooks(load_json(hooks_path), tool, tool_dir)
        doer.write(hooks_path, dump_json(settings))
        if tool == "codex":
            inside = os.path.normcase(projects_dir).startswith(os.path.normcase(memory_home) + os.sep)
            codex_writable_note(doer, tool_dir, [memory_home] + ([] if inside else [projects_dir]))
        root_rules = os.path.join(root, spec["rules"])
        values = {"CENTRAL": fwd(central), "PROJECTS_DIR": fwd(projects_dir), "ROOT": fwd(root),
                  "ROOT_RULES": fwd(root_rules), "AUTOLOAD": AUTOLOAD[tool], "HOOKCHECK": HOOKCHECK[tool], "ZOMBIES": zombies_text(tool_dir),
                  "PROJECT_LOCATIONS": fwd(os.path.join(tool_dir, "hooks", "kit.js")),
                  "SEARCH": "%s %s" % (python_cmd(), fwd(os.path.join(tool_dir, "scripts", "memory_search.py")))}
        values["STOP"] = render("STOP.md", values).strip()
        values["HANDOFF_TEMPLATE"] = render("HANDOFF.md", {"PROJECT": "<проект>",
                                                            "NOW": "ГГГГ-ММ-ДД ЧЧ:ММ"}).strip()
        values["WORKFLOW_DOCS"] = fwd(os.path.join(installed_kit, "docs"))
        values["TRANSFER_PATH"] = fwd(os.path.join(installed_kit, "transfer", "transfer-blocks.js"))
        put_block(doer, os.path.join(tool_dir, spec["rules"]), render("instructions.md", values), "Общие правила")
        _, owners = read_root_block(root_rules)
        if owners is None:
            say("  Общий блок правил прежней установки сохранён: список профилей неизвестен.")
        else:
            owners.add(path_key(tool_dir))
            put_root_block(doer, root_rules, os.path.basename(root) + " — правила",
                           render("root-rules.md", values), owners)
        if tool == "codex" and not args.dry_run:
            size, limit = codex_project_rules_budget(tool_dir, root)
            if size > limit:
                say("  ! Для %s проектные правила Codex превышают лимит: %d из %d байт."
                    % (fwd(root), size, limit))
            elif size > limit * 0.9:
                say("  ! Проектные правила для %s: %d из %d байт, до потолка Codex осталось %d."
                    % (fwd(root), size, limit, limit - size))

    for project in args.project or []:
        project = os.path.abspath(os.path.expanduser(project))
        handoff = os.path.join(project, "HANDOFF.md")
        say()
        say("Проект %s:" % fwd(project))
        if not os.path.isdir(project):
            say("  ! папки нет, пропуск")
        elif os.path.exists(handoff):
            say("  HANDOFF.md уже есть, не трогаю")
        else:
            doer.write(handoff, render("HANDOFF.md", {"PROJECT": os.path.basename(project),
                                                     "NOW": time.strftime("%Y-%m-%d %H:%M")}))

    say()
    if args.dry_run:
        say("Изменений было бы: %d. Запусти без --dry-run, чтобы установить." % doer.changed)
        return 0
    for tool in tools:
        profile = Path(profile_dir(args, home, tool))
        stable = profile / "workflow-kit-package"
        for folder, names in (("hooks", HOOK_FILES), ("scripts", SCRIPT_FILES)):
            for name in names:
                if (profile / folder / name).read_bytes() != (stable / folder / name).read_bytes():
                    raise OSError("Установленный файл не совпал с версией комплекта: " + name)

    # Existing indexes are rebuilt by the normal hooks. Preserve user memory while updating.
    if fresh and not notes:
        first = os.path.join(profile_dir(args, home, tools[0]), "scripts")
        for script, extra in (("memory_index.py", [central]), ("project_index.py", [])):
            result = subprocess.run([sys.executable, os.path.join(first, script)] + extra,
                                    capture_output=True, text=True, encoding="utf-8", errors="replace",
                                    env=dict(os.environ, PYTHONIOENCODING="utf-8"))
            say("  " + (result.stdout + result.stderr).strip().replace("\n", "\n  "))
            if result.returncode != 0:
                raise OSError("Не удалось собрать начальное оглавление: " + script)
    say()
    say("Готово, изменений: %d. Дальше:" % doer.changed)
    def powershell_arg(path):
        return "'" + fwd(path).replace("'", "''") + "'"

    check_command = "python install.py --root " + powershell_arg(root)
    check_command += " --codex-home " + powershell_arg(profile_dir(args, home, "codex"))
    say("  1. Проверь установку: " + check_command + " --check")
    say("  2. Открой НОВУЮ сессию агента в папке проекта, где есть HANDOFF.md, и спроси «что у нас с проектом?»")
    if "codex" in tools:
        say("  3. В Codex набери /hooks и подтверди новые хуки: пока им не доверили, Codex их пропускает.")
        say("     Забудешь — агент сам напомнит об этом в начале сессии")
    return 0


def uninstall(args):
    locations = layout(args)
    transaction, allowed = transaction_paths(args, locations)
    if transaction.directory.exists():
        raise SystemExit("До отключения восстанови незавершённую установку через --rollback.")
    transaction.require_available_root()
    home, root, tools, _, _, _ = locations
    for tool in tools:
        profile = Path(profile_dir(args, home, tool))
        validate_profile_text(profile, TOOLS[tool])
        config = load_json(profile / "memory-kit.json")
        package = profile / "workflow-kit-package"
        manifest = load_json(package / "installed-files.json")
        release = package / "release.json"
        kit_dir = config.get("kit_dir")
        if (config.get("tool") != tool or not isinstance(kit_dir, str) or
                not Path(kit_dir).is_absolute() or Path(kit_dir).resolve() != package.resolve() or
                not release.is_file() or not isinstance(manifest, dict) or not manifest.get("release.json") or
                digest(release.read_bytes()) != manifest["release.json"]):
            raise SystemExit("Не удалось подтвердить принадлежность профиля Workflow Kit. Файлы не изменены.")
        installed_root = config.get("root")
        if not isinstance(installed_root, str) or Path(installed_root).resolve() != Path(root).resolve():
            raise SystemExit("Указанный корень отличается от корня установленного Workflow Kit. Файлы не изменены.")
        read_root_block(os.path.join(root, TOOLS[tool]["rules"]))
    if args.dry_run:
        return apply_uninstall(args, locations, Doer(True))
    transaction.begin()
    try:
        result = apply_uninstall(args, locations, Doer(False, transaction))
    except BaseException:
        transaction.recover(allowed)
        raise
    transaction.complete()
    return result


def apply_uninstall(args, locations, doer):
    home, root, tools, _, central, _ = locations
    say("memory-kit: снимаю хуки и раздел правил. Память не трогаю: " + fwd(central))
    for tool in tools:
        spec = TOOLS[tool]
        tool_dir = profile_dir(args, home, tool)
        hooks_path = os.path.join(tool_dir, spec["hooks_file"])
        if os.path.exists(hooks_path):
            doer.write(hooks_path, dump_json(strip_hooks(load_json(hooks_path), tool, tool_dir)))
        cut_codex_writable_block(doer, tool_dir)
        cut_block(doer, os.path.join(tool_dir, spec["rules"]))
        root_rules = os.path.join(root, spec["rules"])
        body, owners = read_root_block(root_rules)
        owner = path_key(tool_dir)
        if owners is None:
            say("  Общий блок правил оставлен: для прежней установки список профилей неизвестен.")
        elif owner in owners:
            owners.remove(owner)
            if owners:
                put_root_block(doer, root_rules, os.path.basename(root) + " — правила", body, owners)
            else:
                cut_block(doer, root_rules)
        doer.remove(os.path.join(tool_dir, "memory-kit.json"))
    say("Изменений: %d. Файлы хуков и скриптов оставлены на месте — без настроек они ничего не делают." % doer.changed)
    return 0


def check(args):
    home, root, tools, projects_dir, central, memory_home = layout(args)
    bad = 0

    def line(ok, text):
        nonlocal bad
        bad += 0 if ok else 1
        say("  [%s] %s" % ("ок" if ok else "НЕТ", text))

    def matches_package(tool_dir, names):
        try:
            return all((Path(tool_dir) / name).read_bytes() == (Path(KIT) / name).read_bytes()
                       for name in names)
        except OSError:
            return False

    line(os.path.exists(os.path.join(central, "MEMORY.head.md")), "шапка оглавления общей памяти")
    transaction, _ = transaction_paths(args, (home, root, tools, projects_dir, central, memory_home))
    line(not transaction.directory.exists() and not os.path.lexists(transaction.reservation),
         "у профиля и корня нет незавершённой операции")
    for tool in tools:
        spec = TOOLS[tool]
        tool_dir = profile_dir(args, home, tool)
        say("%s:" % tool)
        config = load_json(os.path.join(tool_dir, "memory-kit.json"))
        tool_matches = config.get("tool") == tool
        line(tool_matches, "тип агента в настройках выбранного профиля: " + str(config.get("tool")))
        configured_root = config.get("root")
        root_matches = isinstance(configured_root, str) and Path(configured_root).resolve() == Path(root).resolve()
        line(root_matches, "указанный корень совпадает с настройками выбранного профиля")
        root_rules = os.path.join(root, spec["rules"])
        try:
            body, owners = read_root_block(root_rules)
        except SystemExit as error:
            line(False, str(error))
        else:
            line(bool(body.strip()) and (owners is None or path_key(tool_dir) in owners),
                 "общий блок правил для выбранного профиля в " + fwd(root_rules))
        for folder, names in (("hooks", HOOK_FILES), ("scripts", SCRIPT_FILES)):
            for name in names:
                relative = f"{folder}/{name}"
                line(matches_package(tool_dir, (relative,)), "файл совпадает с комплектом: " + relative)
        stable = Path(tool_dir) / "workflow-kit-package"
        installed_kit = config.get("kit_dir")
        line(isinstance(installed_kit, str) and Path(installed_kit).resolve() == stable.resolve(),
             "папка установленного комплекта в выбранном профиле")
        stable_files = package_files()
        different = [fwd(name) for name in stable_files if not matches_package(stable, (name,))]
        line(not different, "файлы установленного комплекта" + (": " + ", ".join(different) if different else " совпадают"))
        expected_files = {fwd(name): digest((Path(KIT) / name).read_bytes()) for name in stable_files}
        try:
            installed_files = load_json(str(stable / "installed-files.json"))
        except SystemExit as error:
            line(False, str(error))
        else:
            line(installed_files == expected_files, "опись установленного комплекта installed-files.json")
        hook_settings = load_json(os.path.join(tool_dir, spec["hooks_file"]))
        registered = hook_settings.get("hooks", {})
        managed = [hook_key(handler.get("command"), tool_dir)
                   for groups in registered.values() for group in groups for handler in group.get("hooks", [])
                   if handler.get("type") == "command"]
        for event, matcher, entry in wanted_hooks(tool, tool_dir):
            key = hook_key(entry["command"], tool_dir)
            count = CHECK_HELPERS["hook_registration_count"](hook_settings, event, matcher, entry["command"])
            expected = len(ADVISOR_EVENTS) if key == ADVISOR + ":" else 1
            duplicates = managed.count(key) > expected
            line(count == 1 and not duplicates, "хук прописан: " + event + " → " + key +
                 (" (найдены дубликаты)" if duplicates else ""))
        rules = os.path.join(tool_dir, spec["rules"])
        line(os.path.exists(rules) and START in read(rules), "раздел правил в " + spec["rules"])
        if shutil.which("node"):
            # Older hooks ignore the check argument. Run only the matching implementation.
            if not matches_package(tool_dir, ("hooks/session-start-context.js", "hooks/kit.js")):
                line(False, "установленный хук отличается от комплекта, проверка запуска пропущена")
            elif tool_matches and root_matches and os.path.isdir(root):
                r = subprocess.run(["node", os.path.join(tool_dir, "hooks", "session-start-context.js"), "check"],
                                   cwd=root, capture_output=True, text=True, encoding="utf-8", errors="replace")
                try:
                    ctx = json.loads(r.stdout)["hookSpecificOutput"]["additionalContext"]
                except (ValueError, KeyError, TypeError):
                    ctx = ""
                line(r.returncode == 0 and HOOKS_ALIVE in ctx, "хук начала сессии отдаёт метку «%s»" % HOOKS_ALIVE)
                index = os.path.join(central, "MEMORY.md")
                if os.path.exists(index) and read(index).strip():
                    line(read(index).replace("\r\n", "\n").strip()[:200] in ctx.replace("\r\n", "\n")
                         or fwd(index) in ctx,
                         "общее оглавление или его адрес доходит до агента (контекст %d знаков)" % len(ctx))
        else:
            line(False, "node установлен и доступен для проверки стартового хука")
        if tool == "codex":
            size, limit = codex_project_rules_budget(tool_dir, root)
            line(size <= limit, "проектные правила для %s влезают в потолок Codex: %d из %d байт"
                 % (fwd(root), size, limit))
        if matches_package(tool_dir, ("scripts/memory_index.py",)):
            r = subprocess.run([sys.executable, "-B", os.path.join(tool_dir, "scripts", "memory_index.py"), central, "--dry"],
                               capture_output=True, text=True, encoding="utf-8", errors="replace",
                               env=dict(os.environ, PYTHONIOENCODING="utf-8"))
            line(r.returncode == 0, "сборщик оглавления: " + (r.stdout + r.stderr).strip()[:200])
        else:
            line(False, "установленный сборщик оглавления отличается от комплекта, проверка запуска пропущена")
    say()
    say("Всё на месте." if not bad else "Не хватает пунктов: %d. Запусти установку ещё раз." % bad)
    return 1 if bad else 0


def main():
    for stream in (sys.stdout, sys.stderr):          # чужая консоль может быть не в UTF-8
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    ap = argparse.ArgumentParser(description="Установщик Workflow Kit для Codex Desktop на Windows")
    ap.add_argument("--root", required=True, help="корневая папка, в которой лежат проекты")
    ap.add_argument("--tool", choices=["codex"], help="профиль Codex (по умолчанию)")
    ap.add_argument("--project", action="append", help="папка проекта, где завести HANDOFF.md (можно несколько раз)")
    ap.add_argument("--memory", help="где держать память (по умолчанию ~/.agent-memory)")
    ap.add_argument("--codex-home", help="полный путь к выбранному профилю Codex")
    ap.add_argument("--home", help="другая домашняя папка (для проверки в песочнице)")
    ap.add_argument("--dry-run", action="store_true", help="только показать, что изменится")
    ap.add_argument("--check", action="store_true", help="проверить установку")
    ap.add_argument("--uninstall", action="store_true", help="снять хуки и раздел правил (память остаётся)")
    ap.add_argument("--rollback", action="store_true", help="восстановить файлы после прерванной установки")
    args = ap.parse_args()
    if args.check:
        return check(args)
    locations = layout(args)
    home, root, tools, _, _, _ = locations
    keys = {path_key(root), *(path_key(profile_dir(args, home, tool)) for tool in tools)}
    with ExitStack() as locks:
        for key in sorted(keys):
            locks.enter_context(installation_lock(key))
        if args.rollback:
            transaction, allowed = transaction_paths(args, layout(args))
            transaction.require_available_root(recovering=True)
            if args.dry_run:
                say("Есть незавершённая установка." if transaction.directory.exists() else "Восстанавливать нечего.")
            else:
                say("Прежнее состояние восстановлено." if transaction.recover(allowed) else "Восстанавливать нечего.")
            return 0
        if args.uninstall:
            return uninstall(args)
        return install(args)


if __name__ == "__main__":
    sys.exit(main())
