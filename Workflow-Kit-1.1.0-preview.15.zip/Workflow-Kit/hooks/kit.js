/**
 * Общие функции хуков memory-kit: чтение настроек и адреса папок памяти.
 * Настройки лежат рядом с папкой hooks: <папка агента>/memory-kit.json
 * (их пишет install.py). Нет файла настроек — хуки молча ничего не делают.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createHash } = require('crypto');

function loadConfig() {
  try {
    const p = path.join(__dirname, '..', 'memory-kit.json');
    return JSON.parse(fs.readFileSync(p, 'utf-8'));
  } catch (e) {
    return null;
  }
}

function fullPath(file) {
  try { return fs.realpathSync.native(file); } catch (_) { return path.resolve(file); }
}

function pathIdentity(file) {
  const resolved = path.resolve(file);
  return process.platform === 'win32' ? resolved.replace(/^[a-z]:/, letter => letter.toUpperCase()) : resolved;
}

function projectKey(project) {
  return 'project-' + createHash('sha256').update(pathIdentity(project)).digest('hex').slice(0, 32);
}

function matchingPathEntries(entries, project) {
  if (!entries || typeof entries !== 'object' || Array.isArray(entries)) return [];
  return Object.entries(entries).filter(([key]) => path.isAbsolute(key) && samePath(key, project));
}

function configuredPath(value) {
  return typeof value === 'string' && value.trim() && !value.includes('\0') ? value : '';
}

function expandHome(value) {
  return value.replace(/^~(?=[\\/]|$)/, () => os.homedir());
}

function expandJournal(project, value) {
  return expandHome(value.split('{project}').join(path.basename(project)));
}

// A basename rule is safe only when every project resolves it beneath its own directory.
// Symlinks can redirect even an apparently local rule to the journal of a nested project.
function localJournal(project, value) {
  const expanded = expandJournal(project, value);
  if (path.parse(expanded).root) return false;
  const relative = path.relative(project, path.resolve(project, expanded));
  const parts = relative.split(path.sep);
  if (!relative || parts[0] === '..' || path.isAbsolute(relative)) return false;
  let current = project;
  for (const part of parts) {
    current = path.join(current, part);
    try {
      if (fs.lstatSync(current).isSymbolicLink()) return false;
    } catch (e) {
      return e.code === 'ENOENT';
    }
  }
  return true;
}

function configuredJournal(cfg, project) {
  const entries = cfg.journal_path;
  if (typeof entries === 'string') return configuredPath(entries);
  if (!entries || typeof entries !== 'object' || Array.isArray(entries)) return '';
  const matches = matchingPathEntries(entries, project);
  if (matches.length) return matches.length === 1 ? configuredPath(matches[0][1]) : '';
  const name = path.basename(project);
  const local = Object.prototype.hasOwnProperty.call(entries, name) && configuredPath(entries[name]);
  return local && localJournal(project, local) ? local : '';
}

/** Полный путь проекта, адрес его памяти и журнала, в том числе для ещё пустых проектов. */
function projectLocations(cfg, cwd) {
  const project = canonicalProject(cfg, projectDir(cfg, cwd));
  const key = projectKey(project);
  const memory = matchingPathEntries(cfg.project_memory_paths, project);
  const customMemory = memory.length === 1 ? configuredPath(memory[0][1]) : '';
  const journalOverride = configuredJournal(cfg, project);
  return {
    project,
    memoryDir: customMemory ? path.resolve(project, expandHome(customMemory)) : path.join(cfg.projects_dir, key, 'memory'),
    journalFile: journalOverride ? path.resolve(project, expandJournal(project, journalOverride))
      : path.join(cfg.central, 'projects', 'by-path', key + '.md'),
    journalOverride,
  };
}

const projectMemoryDir = (cfg, cwd) => projectLocations(cfg, cwd).memoryDir;
const journalFile = (cfg, cwd) => projectLocations(cfg, cwd).journalFile;
const journalOverride = (cfg, cwd) => projectLocations(cfg, cwd).journalOverride;

/** Explicit aliases only; one hop, absolute paths, no ambiguous duplicate keys or chains.
 * Worktree identity reads Git metadata only. No Git process, network or file mutation. */
function canonicalProject(cfg, project) {
  let result = fullPath(project);
  try {
    const gitfile = path.join(result, '.git');
    if (fs.statSync(gitfile).isFile()) {
      const match = /^gitdir:\s*(.+)\s*$/i.exec(fs.readFileSync(gitfile, 'utf8').trim());
      if (match) {
        const admin = path.resolve(result, match[1]);
        const common = path.resolve(admin, fs.readFileSync(path.join(admin, 'commondir'), 'utf8').trim());
        if (path.basename(common).toLowerCase() === '.git' && fs.statSync(common).isDirectory())
          result = fullPath(path.dirname(common));
      }
    }
  } catch (_) { /* missing/malformed metadata: retain this project */ }
  const aliases = cfg && cfg.project_aliases;
  const matches = matchingPathEntries(aliases, result);
  if (matches.length !== 1) return result;
  const target = matches[0][1];
  if (typeof target !== 'string' || !path.isAbsolute(target)) return result;
  const absolute = fullPath(target);
  if (matchingPathEntries(aliases, absolute).length) return result;
  return absolute;
}

function samePath(a, b) {
  return pathIdentity(fullPath(a)) === pathIdentity(fullPath(b));
}

/** Путь b лежит внутри a (или совпадает). */
function inside(a, b) {
  const rel = path.relative(fullPath(a), fullPath(b));
  return rel === '' || (rel !== '..' && !rel.startsWith('..' + path.sep) && !path.isAbsolute(rel));
}

/**
 * Папка проекта для рабочей папки cwd. Агента часто запускают из подпапки (src, docs):
 * поднимаемся до ближайшей папки с HANDOFF.md. Выше корня проектов не идём, а сам корень
 * проектом считаем, только если запущены прямо в нём: иначе его записка подменила бы записку проекта.
 * Ничего не нашли — проектом остаётся сама cwd.
 */
function projectDir(cfg, cwd) {
  const start = fullPath(cwd);
  const root = cfg && cfg.root ? fullPath(cfg.root) : null;
  let dir = start;
  while (true) {
    if (dir === root && dir !== start) break;
    if (fs.existsSync(path.join(dir, 'HANDOFF.md'))) return dir;
    const up = path.dirname(dir);
    if (up === dir) break;
    dir = up;
  }
  return start;
}

/** Папка похожа на проект: в ней есть записка либо она лежит под корнем проектов. */
function isProject(cfg, dir) {
  if (fs.existsSync(path.join(dir, 'HANDOFF.md'))) return true;
  return !!(cfg && cfg.root) && inside(cfg.root, dir) && !samePath(cfg.root, dir);
}

// Метка «хук старта сработал». Ту же строку ищет агент по разделу правил (install.py, HOOKCHECK).
const HOOKS_ALIVE = 'memory-kit: хуки работают';

// Файлы набора в папке агента. Тот же список — в install.py и scripts/kit_check.py.
const KIT_FILES = {
  hooks: ['kit.js', 'session-start-context.js', 'session-summary-check.js', 'memory-index-hook.py',
    'memory-recall-hook.py'],
  scripts: ['memory_index.py', 'memory_search.py', 'session_archive.py', 'project_index.py', 'kit_check.py',
    'memory_report.py', 'memory_upkeep.py',
    'find-zombies.ps1'],
};

/**
 * Чем установленные файлы отличаются от папки набора (ключ kit_dir в настройках).
 * Возвращает { behind: [...], edited: [...] }: набор ушёл вперёд либо файл поправили на месте.
 * Различаем по времени правки; перевод строк не в счёт. Нет kit_dir или папки — пусто.
 */
function driftFromKit(cfg) {
  const out = { behind: [], edited: [] };
  if (!cfg || !cfg.kit_dir) return out;
  const text = p => fs.readFileSync(p, 'utf-8').split('\r\n').join('\n');
  for (const sub of Object.keys(KIT_FILES)) {
    for (const name of KIT_FILES[sub]) {
      const mine = path.join(__dirname, '..', sub, name);
      const theirs = path.join(cfg.kit_dir, sub, name);
      try {
        if (!fs.existsSync(theirs)) continue;
        if (!fs.existsSync(mine)) { out.behind.push(sub + '/' + name); continue; }
        if (text(mine) === text(theirs)) continue;
        (fs.statSync(theirs).mtimeMs >= fs.statSync(mine).mtimeMs ? out.behind : out.edited).push(sub + '/' + name);
      } catch (e) { /* не смогли прочитать — молчим */ }
    }
  }
  return out;
}

module.exports = { canonicalProject, journalFile, journalOverride, loadConfig, projectMemoryDir, projectLocations, samePath, inside, projectDir, isProject, driftFromKit,
  KIT_FILES, HOOKS_ALIVE };

if (require.main === module && process.argv[2] === '--project-locations') {
  const cfg = loadConfig();
  if (!cfg || !cfg.central || !cfg.projects_dir) {
    console.error('memory-kit.json: требуются central и projects_dir');
    process.exitCode = 1;
  } else {
    const locations = projectLocations(cfg, process.argv[3] || process.cwd());
    for (const field of ['project', 'memoryDir', 'journalFile']) {
      locations[field] = locations[field].split(path.sep).join('/');
    }
    console.log(JSON.stringify(locations));
  }
}
