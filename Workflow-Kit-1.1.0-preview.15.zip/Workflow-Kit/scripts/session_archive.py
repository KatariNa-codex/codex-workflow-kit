# -*- coding: utf-8 -*-
"""Архив разговоров из записей сессий Codex.

Сохраняет объяснения и решения из разговоров в локальных текстовых файлах.

Что берётся: то, что набрал человек, и то, что ответил агент словами. Что НЕ берётся: вызовы
инструментов и их вывод, размышления модели, служебные вставки, помощники (субагенты).
Секреты вырезаются по маскам (ключи, токены, «пароль: …») — но маска не гарантия:
архив лежит только на этой машине, в git его класть не надо.

Сессия попадает в архив, когда её запись не менялась полчаса (то есть сессия закончена или стоит),
и переписывается, если запись с тех пор выросла. Удалённую запись архив переживает.

Запуск:
  python session_archive.py                 # забрать всё новое
  python session_archive.py --max 5         # не больше пяти сессий за раз (так зовёт хук конца хода)
  python session_archive.py --quiet         # молчать, если всё в порядке
  python session_archive.py --dry           # только посчитать
Искать: python memory_search.py "<слова>" --sessions
"""
import datetime
import glob
import hashlib
import json
import os
import re
import sys
import time
from pathlib import Path

IDLE_SECONDS = 30 * 60
MAX_MESSAGE_CHARS = 6000
UNKNOWN_TIME = "дата неизвестна"
INDEX_NAME = ".codex.json"
SESSION_ID = r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}"
ARCHIVE_NAME = re.compile(rf"(?:\d{{4}}-\d{{2}}-\d{{2}}|undated)_({SESSION_ID}|[0-9a-f]{{8}})\.md", re.I)
STAGING_NAME = re.compile(r"(.+)\.[1-9]\d*(?:\.[0-9a-f]{8})?\.tmp")

MASKS = [
    (r"sk-[A-Za-z0-9_\-]{20,}", "sk-…"),
    (r"\b(?:ghp|gho|ghu|ghs|github_pat)_[A-Za-z0-9_]{20,}", "gh…"),
    (r"\bxox[abprs]-[A-Za-z0-9\-]{10,}", "xox…"),
    (r"\bAKIA[0-9A-Z]{16}\b", "AKIA…"),
    (r"\b\d{8,10}:[A-Za-z0-9_\-]{35}\b", "<токен бота>"),
    (r"\beyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}", "<jwt>"),
    (r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----", "<закрытый ключ>"),
    (r"(?i)\b(password|passwd|пароль|token|токен|secret|секрет|api[_\-]?key|apikey|bearer)(\s*[:=]\s*)([^\s\"'`,;]{6,})",
     lambda m: m.group(1) + m.group(2) + "<скрыто>"),
    # через пробел — только то, что похоже на ключ (буквы вперемешку с цифрами), иначе вырежется обычная фраза
    (r"(?i)\b(password|passwd|пароль|token|токен|secret|секрет|bearer)(\s+)((?=\S*\d)(?=\S*[A-Za-z])[A-Za-z0-9_\-+/=.]{8,})",
     lambda m: m.group(1) + m.group(2) + "<скрыто>"),
    (r"\b[0-9a-fA-F]{40,}\b", "<длинный ключ>"),
]
NOISE = re.compile(r"(?s)<system-reminder>.*?</system-reminder>|<local-command-[a-z]+>.*?</local-command-[a-z]+>"
                   r"|<command-(?:name|message|args)>.*?</command-(?:name|message|args)>|<task-notification>.*?</task-notification>")


def _places():
    """Resolve archive inputs from the profile that owns this installed script."""
    home = os.path.expanduser("~")
    profile = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    cfg = os.path.join(profile, "memory-kit.json")
    archive = os.path.join(home, ".agent-memory", "sessions")
    try:
        with open(cfg, encoding="utf-8") as fh:
            data = json.load(fh)
    except FileNotFoundError:
        profile = os.environ.get("CODEX_HOME") or os.path.join(home, ".codex")
    else:
        if not isinstance(data, dict):
            raise ValueError("memory-kit.json: нужен объект настроек")
        setting = data.get("sessions_dir")
        if setting in (None, ""):
            central = data.get("central")
            setting = os.path.join(os.path.dirname(central), "sessions") if central else archive
        if (not isinstance(setting, str) or "\0" in setting
                or (os.path.splitdrive(setting)[0] and not os.path.isabs(setting))):
            raise ValueError("memory-kit.json: неверный путь sessions_dir")
        archive = os.path.normpath(os.path.join(profile, setting))
    return os.path.join(profile, "sessions"), archive


try:
    CODEX_SOURCE, ARCHIVE = _places()
    CONFIG_ERROR = None
except (OSError, TypeError, ValueError) as exc:
    CODEX_SOURCE = ARCHIVE = ""
    CONFIG_ERROR = exc
CODEX_SKIP = ("# AGENTS.md instructions", "<environment_context", "<recommended_plugins", "<external_codex_apps",
              "<realtime_delegation", "<image name=", "</image>", "<bash-stdout", "<in-app-browser-context",
              "<user_instructions", "<turn_aborted")


def mask(text):
    for pattern, repl in MASKS:
        text = re.sub(pattern, repl, text, flags=re.S)
    return text


def clean(text):
    text = NOISE.sub("", text).strip()
    if not text or text.startswith(("Caveat: The messages below", "[Request interrupted")):
        return ""
    text = mask(text)
    if len(text) > MAX_MESSAGE_CHARS:
        text = text[:MAX_MESSAGE_CHARS] + "\n[…обрезано]"
    return text


def stamp(iso):
    try:
        return datetime.datetime.fromisoformat(iso.replace("Z", "+00:00")).astimezone().strftime("%Y-%m-%d %H:%M")
    except (AttributeError, OSError, OverflowError, TypeError, ValueError):
        return ""


def codex_words(payload):
    """Текст сообщения из записи Codex без служебных вставок и приложенных картинок."""
    parts = []
    for b in payload.get("content") or []:
        text = (b.get("text") or "") if isinstance(b, dict) else ""
        if not text.strip() or text.lstrip().startswith(CODEX_SKIP):
            continue
        if "## My request for Codex:" in text:          # перед просьбой идёт список приложенных файлов
            text = text.split("## My request for Codex:", 1)[1]
        parts.append(text)
    return clean("\n\n".join(parts))


def convert_codex(path):
    """Запись сессии Codex -> (текст архива, дата начала, папка проекта). Не разговор с человеком -> ('', '', '')."""
    blocks, cwd, first, sid, metadata_stamp = [], "", "", "", ""
    with open(path, encoding="utf-8", errors="replace") as fh:
        for ln in fh:
            try:
                e = json.loads(ln)
            except ValueError:
                continue
            p = e.get("payload") or {}
            if e.get("type") == "session_meta":
                if p.get("source") == "exec" or not isinstance(p.get("source"), str):
                    return "", "", ""
                cwd, sid = p.get("cwd") or "", p.get("id") or ""
                metadata_stamp = stamp(e.get("timestamp") or p.get("timestamp") or "")
                continue
            if e.get("type") != "response_item" or p.get("type") != "message" or p.get("role") not in ("user", "assistant"):
                continue
            text = codex_words(p)
            if not text:
                continue
            when = stamp(e.get("timestamp") or "")
            first = first or when
            who = "человек" if p["role"] == "user" else "агент"
            if blocks and blocks[-1][0] == who == "агент":
                blocks[-1][2].append(text)
            else:
                blocks.append([who, when or UNKNOWN_TIME, [text]])
    if not sid or not any(b[0] == "человек" for b in blocks):
        return "", "", ""
    first = first or metadata_stamp
    out = ["# Сессия %s" % sid, "", "Проект: %s" % (cwd or "?"), "Начало: %s" % (first or UNKNOWN_TIME),
           "Агент: Codex", ""]
    for who, when, texts in blocks:
        out += ["## [%s] %s" % (when, who), "", "\n\n".join(texts), ""]
    return "\n".join(out), first, cwd


def archive_directory(cwd, date, sid):
    slug = re.sub(r"[^A-Za-z0-9]", "-", cwd) or "codex"
    full_name = f"{date}_{sid}.md"
    # Leave room for the temporary suffix and the Windows path limit.
    if len(slug) > 160 or len(os.path.abspath(os.path.join(ARCHIVE, slug, full_name))) > 230:
        slug = "project-" + hashlib.sha256(cwd.encode("utf-8")).hexdigest()[:20]
    return os.path.join(ARCHIVE, slug)


def archive_has_session(path, sid):
    try:
        with open(path, encoding="utf-8") as fh:
            return fh.readline().rstrip("\r\n") == "# Сессия " + sid
    except (OSError, UnicodeError):
        return False


def write_archive_file(path, text):
    binary = isinstance(text, bytes)
    temporary = Path(f"{path}.{os.getpid()}.{os.urandom(4).hex()}.tmp")
    stream = temporary.open("xb" if binary else "x", encoding=None if binary else "utf-8",
                            newline=None if binary else "\n")
    try:
        with stream:
            stream.write(text)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def read_index(path):
    """Return the usable entries and the original bytes if recovery is needed."""
    try:
        raw = path.read_bytes()
    except FileNotFoundError:
        return {}, None
    try:
        data = json.loads(raw.decode("utf-8"))
    except (UnicodeError, ValueError, RecursionError):
        return {}, raw
    if not isinstance(data, dict):
        return {}, raw
    index = {}
    for sid, row in data.items():
        if not isinstance(row, dict):
            continue
        mtime, filename = row.get("mtime"), row.get("file")
        if (type(mtime) in (float, int) and 0 <= mtime < float("inf")
                and (filename is None or (isinstance(filename, str) and "\0" not in filename))):
            index[sid] = row
    return index, raw if len(index) != len(data) else None


def preserve_invalid_index(path, raw):
    digest = hashlib.sha256(raw).hexdigest()
    backup = path.with_name(f"{path.name}.invalid.{digest}")
    if not backup.exists():
        write_archive_file(backup, raw)
    elif backup.read_bytes() != raw:
        raise OSError(f"Не совпадает резервная копия индекса: {backup}")
    print(f"Повреждён индекс {path}. Прежнее содержимое сохранено в {backup.name}.", file=sys.stderr)


def clean_staging(archive_root, index):
    """Remove only completed staging files already covered by the committed archive."""
    for path in archive_root.glob("*.tmp"):
        match = STAGING_NAME.fullmatch(path.name)
        if not match or path.is_symlink() or not path.is_file():
            continue
        try:
            target = match.group(1)
            if target == INDEX_NAME:
                pending, invalid = read_index(path)
                if invalid is None and all(
                    sid in index and index[sid]["mtime"] >= row["mtime"] for sid, row in pending.items()
                ):
                    path.unlink(missing_ok=True)
            elif re.fullmatch(r"\.codex\.json\.invalid\.[0-9a-f]{64}", target):
                saved = archive_root / target
                if saved.is_file() and path.read_bytes() == saved.read_bytes():
                    path.unlink(missing_ok=True)
        except OSError:
            continue
    for path in archive_root.glob("*/*.md.*.tmp"):
        match = STAGING_NAME.fullmatch(path.name)
        if not match or path.is_symlink() or not path.is_file():
            continue
        try:
            if path.parent.resolve() != archive_root / path.parent.name:
                continue
            target = path.with_name(match.group(1))
            name = ARCHIVE_NAME.fullmatch(target.name)
            if not name or not target.is_file() or target.is_symlink():
                continue
            with path.open(encoding="utf-8") as staged:
                header = re.fullmatch(rf"# Сессия ({SESSION_ID})", staged.readline().rstrip("\r\n"), re.I)
            if (header and header.group(1).lower().endswith(name.group(1).lower())
                    and path.read_bytes() == target.read_bytes()):
                path.unlink(missing_ok=True)
        except (OSError, UnicodeError):
            continue


def sweep_codex(limit=None, dry=False):
    pattern = os.path.join(CODEX_SOURCE, "*", "*", "*", "rollout-*.jsonl")
    if dry:
        return sweep_unlocked(pattern, limit, dry)
    candidates = glob.glob(pattern)
    if not candidates:
        return 0, 0
    if not os.path.isdir(ARCHIVE) and not any(time.time() - os.path.getmtime(file) >= IDLE_SECONDS for file in candidates):
        return 0, 0
    os.makedirs(ARCHIVE, exist_ok=True)
    # Keep one lock path for every writer sharing this archive, regardless of Codex profile.
    with open(os.path.join(ARCHIVE, ".archive.lock"), "a+b") as lock:
        if os.name == "nt":
            import msvcrt
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        return sweep_unlocked(pattern, limit, dry)


def sweep_unlocked(pattern, limit, dry):
    """То же для Codex. Что уже разобрано, помнит файл .codex.json в архиве: папка проекта у Codex
    написана внутри записи, и без этого файла каждую пришлось бы открывать заново. -> (взято, пропущено)."""
    done = empty = 0
    now = time.time()
    index_path = Path(ARCHIVE) / INDEX_NAME
    index, invalid_index = read_index(index_path)
    obsolete = []
    archive_root = Path(ARCHIVE).resolve()
    changed = False
    files = sorted(glob.glob(pattern), key=os.path.getmtime)
    for path in files:
        mtime = os.path.getmtime(path)
        sid = os.path.splitext(os.path.basename(path))[0][-36:]
        if now - mtime < IDLE_SECONDS or (index.get(sid) or {}).get("mtime", 0) >= mtime:
            continue
        if limit is not None and done >= limit:
            break
        if dry:
            done += 1
            continue
        text, first, cwd = convert_codex(path)
        old = (index.get(sid) or {}).get("file")
        index[sid] = {"mtime": mtime}
        changed = True
        if not text:
            if old:
                index[sid]["file"] = old
            empty += 1
            continue
        date = first[:10] if first else "undated"
        directory = archive_directory(cwd, date, sid)
        short = os.path.join(directory, f"{date}_{sid[-8:]}.md")
        full = os.path.join(directory, f"{date}_{sid}.md")
        old_path = Path(old) if old and Path(old).is_absolute() else None
        old_resolved = old_path.resolve() if old_path else None
        short_in_use = os.path.exists(short) and not archive_has_session(short, sid)
        dst = full if old_resolved == Path(full).resolve() or short_in_use else short
        if os.path.exists(dst) and not archive_has_session(dst, sid):
            raise OSError(f"В архиве уже есть другой файл: {dst}")
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        write_archive_file(dst, text)
        if old_path and old_resolved != Path(dst).resolve():
            obsolete.append((old_path, sid))
        index[sid]["file"] = dst
        done += 1
    if changed:
        os.makedirs(ARCHIVE, exist_ok=True)
        if invalid_index is not None:
            preserve_invalid_index(index_path, invalid_index)
        write_archive_file(index_path, json.dumps(index))
        for old, sid in obsolete:
            if archive_root in old.resolve().parents and archive_has_session(old, sid):
                old.unlink(missing_ok=True)
    elif invalid_index is not None:
        print(f"Повреждён индекс {index_path}. Файл сохранён, перестройка ждёт новых записей.", file=sys.stderr)
    if not dry:
        clean_staging(archive_root, index)
    return done, empty


def main(argv):
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    quiet, dry = "--quiet" in argv, "--dry" in argv
    limit = int(argv[argv.index("--max") + 1]) if "--max" in argv else None
    if CONFIG_ERROR is not None:
        print(f"Архив сессий: {CONFIG_ERROR}", file=sys.stderr)
        return 1
    done = empty = 0
    try:
        if os.path.isdir(CODEX_SOURCE):
            done, empty = sweep_codex(limit, dry)
    except (OSError, ValueError) as exc:
        print(f"Архив сессий: {exc}", file=sys.stderr)
        return 1
    if not quiet or dry:
        print("архив сессий %s: %s %d, пустых %d" % (ARCHIVE.replace(os.sep, "/"),
                                                     "взял бы" if dry else "взято", done, empty))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
