﻿<#
.SYNOPSIS
  Ищет осиротевшие инструменты и серверы в Windows.

.DESCRIPTION
  Показывает процессы с известной сигнатурой, если их исходный родитель больше не жив.
  Принадлежность найденного процесса конкретной сессии требует проверки владельцем.

.PARAMETER Kill
  Остановить только процессы, явно указанные через Selection.

.PARAMETER Selection
  Значения Selection из предыдущего списка, через запятую. Каждое
  значение содержит PID и время запуска конкретного процесса.

.PARAMETER MinAgeHours
  Показывать кандидатов старше N часов. По умолчанию 0 (все).

.EXAMPLE
  # посмотреть всё
  powershell -NoProfile -File find-zombies.ps1
  # После согласования скопировать целиком значение из списка
  powershell -NoProfile -File find-zombies.ps1 -Kill -Selection '1234:639311332792311290'
#>
[CmdletBinding()]
param(
    [switch]$Kill,
    [double]$MinAgeHours = 0,
    [string]$Selection
)

$ErrorActionPreference = 'Stop'
if ($Kill -and $Selection -cnotmatch '^[1-9][0-9]*:[0-9]+(,[1-9][0-9]*:[0-9]+)*\z') {
    throw 'Для остановки передай через -Selection полные значения из предыдущего списка, разделяя их запятой.'
}
if (-not $Kill -and $PSBoundParameters.ContainsKey('Selection')) {
    throw 'Параметр -Selection используется вместе с -Kill.'
}

# --- 1. Снимок всех процессов -------------------------------------------------
$all = Get-CimInstance Win32_Process |
    Select-Object ProcessId, ParentProcessId, Name, CommandLine, CreationDate
$byPid = @{}
foreach ($p in $all) { $byPid[[int]$p.ProcessId] = $p }

# PID переиспользуются, поэтому более новый процесс с тем же PID не родитель.
function Test-HasLiveParent {
    param($proc)
    $parent = $byPid[[int]$proc.ParentProcessId]
    return $null -ne $parent -and $parent.CreationDate -le $proc.CreationDate
}

# --- 3. Сигнатуры того, что вообще может быть мусором -------------------------
$shellTools = 'bash.exe', 'tail.exe', 'grep.exe', 'sed.exe', 'awk.exe', 'head.exe'

$serverPatterns = @(
    'http\.server', 'http-server', '\bserve\b',
    '\bnpm\b.*\b(run\s+)?(dev|start|serve)\b',
    '\bnext\s+dev\b', '\bvite\b', '\b(yarn|pnpm|bun)\s+dev\b',
    '\buvicorn\b', '\bgunicorn\b', '\bflask\s+run\b', '\bstreamlit\s+run\b',
    '\bngrok\b', '\bwebpack(-dev-server)?\b'
)
$serverRegex = ($serverPatterns -join '|')

# --- 4. Отбор -----------------------------------------------------------------
$suspects = foreach ($p in $all) {
    $cmd = if ($p.CommandLine) { $p.CommandLine -replace '\s+', ' ' } else { '' }
    $why = $null
    if ($shellTools -contains $p.Name) { $why = 'shell-tool' }
    elseif ($cmd -match $serverRegex)  { $why = 'dev-server' }
    if (-not $why -or $null -eq $p.CreationDate) { continue }
    if (Test-HasLiveParent $p) { continue }
    $ageH = (New-TimeSpan -Start $p.CreationDate).TotalHours
    if ($ageH -lt $MinAgeHours) { continue }
    [PSCustomObject]@{
        PID     = [int]$p.ProcessId
        Name    = $p.Name
        Why     = $why
        Age     = '{0:0.0} ч' -f $ageH
        Started = $p.CreationDate
        Selection = '{0}:{1}' -f $p.ProcessId, $p.CreationDate.ToUniversalTime().Ticks
        Cmd     = if ($cmd.Length -gt 90) { $cmd.Substring(0, 90) + '…' } else { $cmd }
    }
}
$suspects = @($suspects | Sort-Object Started)

if ($Kill) {
    $tokens = @($Selection.Split(',') | Sort-Object -Unique)
    $approved = @($suspects | Where-Object { $_.Selection -cin $tokens })
    if ($approved.Count -ne $tokens.Count) {
        throw 'Хотя бы один выбранный процесс исчез, сменил PID или вышел из списка кандидатов. Посмотри список заново.'
    }
    $suspects = $approved
}

# --- 5. Вывод -----------------------------------------------------------------
if ($suspects.Count -eq 0) {
    Write-Output 'Зомби-процессов не найдено.'
    return
}

# какие порты они держат
$listen = @{}
try {
    foreach ($c in (Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue)) {
        $listen[[int]$c.OwningProcess] = $c.LocalPort
    }
} catch { }

$suspects |
    Select-Object PID, Name, Why, Age,
                  @{n = 'Port'; e = { if ($listen.ContainsKey($_.PID)) { $listen[$_.PID] } else { '-' } } },
                  Cmd |
    Format-Table -AutoSize -Wrap

Write-Output ''
if ($Kill) {
    Write-Output ("Выбрано для остановки: {0}." -f $suspects.Count)
    Write-Output ''
    $failures = 0
    foreach ($s in $suspects) {
        $process = $null
        try {
            $process = Get-Process -Id $s.PID -ErrorAction Stop
            # Keep the OS handle open from verification through termination.
            $handle = $process.SafeHandle
            if ($null -eq $handle -or $handle.IsInvalid) { throw 'Не удалось открыть процесс.' }
            $startTicks = $process.StartTime.ToUniversalTime().Ticks
            # Win32_Process.CreationDate has microsecond precision.
            $startTicks -= $startTicks % 10
            if ($startTicks -ne $s.Started.ToUniversalTime().Ticks -or $process.HasExited) {
                throw 'Процесс завершился или его PID переиспользован.'
            }
            $process.Kill()
            Write-Output ("  остановлен {0} ({1})" -f $s.PID, $s.Name)
        } catch {
            $failures++
            Write-Warning ("Не удалось остановить {0} ({1}): {2}" -f $s.PID, $s.Name, $_.Exception.Message)
        } finally {
            if ($null -ne $process) { $process.Dispose() }
        }
    }
    if ($failures) { throw ("Не удалось остановить процессов: {0} из {1}." -f $failures, $suspects.Count) }
} else {
    Write-Output ("Кандидатов: {0}. После согласования передай выбранные значения с -Kill -Selection." -f $suspects.Count)
    foreach ($s in $suspects) {
        Write-Output ("  PID {0}, {1}: Selection = {2}" -f $s.PID, $s.Name, $s.Selection)
    }
}
