(() => {
const transferBlocks = (function transferBlocks(api) {
  const normal = value => String(value ?? "").trim().replace(/\s+/g, " ").toLowerCase();
  const pathKey = value => String(value ?? "").trim().toLowerCase().replace(/\\/g, "/").replace(/\/+$/, "");
  const call = (name, args) => api.call(name, args);
  const remember = state => api.remember(state);
  const clockFromHost = seconds => Number.isFinite(seconds) ? seconds * 1000 : null;
  const oneLine = value => typeof value === "string" && value.trim().length > 0 && !/[\r\n]/.test(value);

  async function findDuplicate(hostId, projectId, title, archived) {
    const cursors = new Set();
    let cursor;
    do {
      if (cursors.has(cursor)) throw Error("Thread history cursor repeated");
      cursors.add(cursor);
      const page = await call("list_threads", {mode:"history", source:"codex", hostId, archived, cursor, limit:50});
      if (!Array.isArray(page.threads)) throw Error("Thread history unavailable");
      const duplicate = page.threads.find(thread =>
        normal(thread.title) === normal(title) && (!thread.projectId || thread.projectId === projectId));
      if (duplicate) return {id:duplicate.id, archived};
      cursor = page.nextCursor || undefined;
    } while (cursor);
    return null;
  }

  async function prepare(input) {
    const {oldId, hostId, cwd} = input;
    const projectRoot = input.projectRoot ?? cwd;
    const [snapshot, history, projects, sidebar] = await Promise.all([
      api.local(input),
      call("read_thread", {threadId:oldId, hostId, turnLimit:1, maxOutputCharsPerItem:240}),
      call("list_projects", {}),
      call("list_threads", {limit:12})
    ]);
    const {evidence, evidenceKind, evidenceName, ...local} = snapshot;
    const old = history.thread;
    const listed = [...(sidebar.pinnedThreads ?? []), ...(sidebar.threads ?? [])].find(item => item.id === oldId);
    const unverified = {status:"project_unverified", oldId, requestedPath:cwd, local};
    if (!old || old.id !== oldId || old.kind !== "codex" ||
        (old.hostId && old.hostId !== hostId) || pathKey(old.cwd) !== pathKey(cwd)) return unverified;

    let project = projects.projects?.find(item =>
      ["local", "remote"].includes(item.projectKind) && item.hostId === hostId && pathKey(item.path) === pathKey(projectRoot));
    let projectSource = "list_projects";
    if (!project && hostId === "local" && listed?.projectId && listed.kind === "codex" &&
        listed.hostId === hostId && pathKey(listed.cwd) === pathKey(cwd)) {
      // The desktop connector can omit a registered project while still returning its thread membership.
      const registered = await api.registry?.(listed.projectId);
      if (registered?.projectId === listed.projectId && registered.hostId === hostId &&
          registered.projectKind === "local" && pathKey(registered.path) === pathKey(projectRoot)) {
        project = registered;
        projectSource = "local_registration";
      }
    }
    if (!project || (listed?.projectId && listed.projectId !== project.projectId)) return unverified;
    const suffix = /^(.*_)(\d+)$/.exec(old.title ?? "");
    const title = suffix ? suffix[1] + String(BigInt(suffix[2]) + 1n) : input.approvedTitle;
    if (!oneLine(title)) return {status:"name_required", oldTitle:old.title, local};
    const [active, archived] = await Promise.all([
      findDuplicate(hostId, project.projectId, title, false),
      findDuplicate(hostId, project.projectId, title, true)
    ]);
    if (active || archived) return {status:"duplicate", title, matches:[active,archived].filter(Boolean), local};
    const turn = history.turns?.[0];
    const userText = turn?.items?.find(item => item.type === "userMessage")?.content
      ?.filter(item => item.type === "text").map(item => item.text).join(" ");
    const directCommand = input.commandTurnId
      ? input.commandTurnId === turn?.id && Boolean(userText)
      : input.commandConfirmed === true && Boolean(userText);
    return {status:"checked", evidence, evidenceKind, evidenceName, oldId, hostId, cwd, title, projectId:project.projectId, projectRoot, projectSource, local,
      oldPinned:sidebar.pinnedThreads?.some(item => item.id === oldId) ?? false,
      handoffPath:input.handoffPath, model:input.model, modelMatchesDefault:input.modelMatchesDefault === true,
      turnStartedAt:directCommand && Number.isFinite(turn?.startedAt) ? turn.startedAt : null};
  }

  async function finish(state) {
    if (state.status === "complete") return state;
    state.timings ??= {
      commandStartedAt:clockFromHost(state.turnStartedAt), chatCreatedAt:null,
      confirmationReadyAt:null, confirmationReceivedAt:null, pinsVerifiedAt:null
    };
    try {
      if (state.timings.chatCreatedAt === null) {
        const createdDetails = await call("read_thread", {threadId:state.threadId, hostId:state.hostId, includeTurns:false})
          .catch(() => null);
        const createdAt = createdDetails?.thread?.createdAt;
        if (createdDetails?.thread?.id === state.threadId && Number.isFinite(createdAt)) {
          state.timings.chatCreatedAt = clockFromHost(createdAt);
          if (Number.isFinite(state.turnStartedAt) && createdAt >= state.turnStartedAt) {
            state.secondsToCreate = createdAt - state.turnStartedAt;
          }
        }
        remember(state);
      }
      const wait = await call("wait_threads", {targets:[{threadId:state.threadId, hostId:state.hostId}], timeoutMs:45000});
      const poll = wait.polls?.find(item => item.thread?.id === state.threadId);
      const turn = poll?.latestTurn;
      if (!turn?.id || turn.status !== "completed") {
        return {...state, status:"confirmation_pending", wake:wait.wake?.reason, errors:wait.errors};
      }

      // wait_threads flattens whitespace. Use the full response from the same completed turn.
      const history = await call("read_thread", {threadId:state.threadId, hostId:state.hostId,
        turnLimit:3, maxOutputCharsPerItem:4096});
      const receivedAt = api.now();
      const originalTurn = history.thread?.id === state.threadId
        ? history.turns?.find(item => item.id === turn.id && item.status === "completed") : null;
      const finals = originalTurn?.items?.filter(item => item.type === "agentMessage" && item.phase === "final_answer") ?? [];
      const message = finals.length === 1 ? finals[0] : null;
      if (typeof message?.text !== "string") {
        return {...state, status:"confirmation_unverified", confirmationTurnId:turn.id};
      }
      const field = label => {
        const rows = message.text.split(/\r?\n/).filter(line => line.startsWith(label + ": "));
        return rows.length === 1 ? rows[0].slice(label.length + 2).trim() : "";
      };
      const fact = field("Факт");
      if (normal(field("Задача")) !== normal(state.task) || normal(field("Точка")) !== normal(state.point) ||
          fact.length < 16 || fact.length > 350 || normal(state.prompt).includes(normal(fact)) ||
          !normal(state.evidence).includes(normal(fact))) {
        return {...state, status:"confirmation_unverified", reply:message.text.slice(0,800)};
      }
      state.timings.confirmationReadyAt ??= clockFromHost(originalTurn.completedAt ?? turn.completedAt);
      state.timings.confirmationReceivedAt ??= receivedAt;
      const acceptedAt = api.now();
      remember(state);
      const isPinned = (snapshot, id) => snapshot.pinnedThreads?.some(item => item.id === id && item.hostId === state.hostId);
      let afterPin = await call("list_threads", {limit:12});
      if (!Array.isArray(afterPin.pinnedThreads)) return {...state, status:"sidebar_unverified"};
      if (!isPinned(afterPin,state.threadId)) {
        const pinned = {...(isPinned(afterPin,state.oldId) ? {beforeThreadId:state.oldId} : {}), threadId:state.threadId,
          hostId:state.hostId, sectionId:"pinned"};
        await call("move_thread_to_sidebar_section", pinned);
        afterPin = await call("list_threads", {limit:12});
        if (!isPinned(afterPin,state.threadId)) return {...state, status:"pin_unconfirmed"};
      }
      const oldStillPinned = isPinned(afterPin,state.oldId);
      if (oldStillPinned) await call("move_thread_to_sidebar_section", {threadId:state.oldId, hostId:state.hostId, sectionId:"chats"});
      const final = oldStillPinned ? await call("list_threads", {limit:12}) : afterPin;
      if (!isPinned(final,state.threadId) || isPinned(final,state.oldId) || !Array.isArray(final.pinnedThreads)) {
        return {...state, status:"sidebar_unverified"};
      }
      const verifiedAt = api.now();
      state.timings.pinsVerifiedAt = verifiedAt;
      const result = {...state, status:"complete", fact, acceptedAt, verifiedAt,
        continuationStatus:state.continueAuthorized ? "unconfirmed" : "not_requested"};
      // Persist the verified transfer and the attempt before dispatch. An uncertain send must not be retried blindly.
      remember(result);
      if (state.continueAuthorized) {
        try {
          await call("send_message_to_thread", {threadId:state.threadId, hostId:state.hostId,
            prompt:state.continuationTask ?? ("Перенос подтверждён. Продолжай задачу по HANDOFF: " + state.task +
              "\nСледующий шаг: " + state.point + "\nСоблюдай ограничения, сохранённые в HANDOFF и связанных файлах.")});
          result.continuationStatus = "submitted";
        } catch(e) {
          result.continuationError = String(e.message ?? e);
        }
        remember(result);
      }
      return result;
    } catch(e) {
      return {...state, status:"step_unconfirmed", error:String(e.message ?? e)};
    }
  }

  async function transfer(pre, plan) {
    if (pre.status !== "checked") return {status:"preflight_required"};
    if (api.previous?.(pre)) return {status:"check_existing_creation", title:pre.title};
    if (plan.ownerAuthorized !== true) return {status:"owner_command_required"};
    if (plan.stopVerified !== true) return {status:"stop_required"};
    if (pre.local?.matches?.length !== 1 || (pre.local.matchCount ?? 1) !== 1) {
      return {status:"active_branch_unverified"};
    }
    if (!pre.model && !pre.modelMatchesDefault) return {status:"model_unverified"};
    if (!oneLine(plan.task) || !oneLine(plan.point)) return {status:"invalid_plan"};
    if (plan.continuationTask !== undefined && (plan.continueAuthorized !== true ||
        typeof plan.continuationTask !== "string" || !plan.continuationTask.trim())) return {status:"invalid_plan"};
    const {evidence, evidenceKind, evidenceName} = pre;
    if (typeof evidence !== "string" || evidence.trim().length < 16) return {status:"evidence_unavailable"};
    const hint = evidenceKind === "handoff_line" ? "факт из строки активной ветки"
      : "факт из файла «" + evidenceName.replace(/[[\]\\]/g, "\\$&") + "»";
    const prompt = "Задача: " + plan.task.trim() + "\n\nHANDOFF: [HANDOFF.md — " + hint + "](<" + pre.handoffPath +
      ">)\n\nТочка: " + plan.point.trim();
    const requestAt = api.now();
    const attempt = {oldId:pre.oldId, title:pre.title, requestAt};
    remember(attempt);
    let created;
    try {
      created = await call("create_thread", {title:pre.title, prompt, ...(pre.model ? {model:pre.model} : {}),
        target:{type:"project", projectId:pre.projectId, environment:{type:"local"}}});
    } catch(e) {
      return {status:"creation_unconfirmed", oldId:pre.oldId, title:pre.title, requestAt, error:String(e.message ?? e)};
    }
    const returnedAt = api.now();
    if (!created.threadId || created.hostId !== pre.hostId) {
      return {status:"creation_unconfirmed", oldId:pre.oldId, title:pre.title, requestAt,
        clientThreadId:created.clientThreadId};
    }
    const secondsToCreate = Number.isFinite(pre.turnStartedAt) && Number.isFinite(created.createdAt) && created.createdAt >= pre.turnStartedAt
      ? created.createdAt - pre.turnStartedAt : null;
    const secondsToConfirmation = Number.isFinite(pre.turnStartedAt) ? returnedAt / 1000 - pre.turnStartedAt : null;
    const state = {...pre, threadId:created.threadId, prompt, task:plan.task, point:plan.point, evidence,
      requestAt, returnedAt, secondsToCreate, secondsToConfirmation,
      continueAuthorized:plan.continueAuthorized === true, continuationTask:plan.continuationTask,
      timings:{commandStartedAt:clockFromHost(pre.turnStartedAt), chatCreatedAt:clockFromHost(created.createdAt),
        confirmationReadyAt:null, confirmationReceivedAt:null, pinsVerifiedAt:null}};
    remember(state);
    return finish(state);
  }

  return {prepare, transfer, finish};
});

/* The V8 tool adapter stays here so preparation and dispatch use the same data contract. */
function liveTransfer(runtime) {
  const {tools, store, load} = runtime;
  const stateKey = oldId => "transfer-state:" + oldId;
  const quoted = value => "'" + String(value).replace(/'/g, "''") + "'";
  async function local(input) {
    const command = "$handoffPath=" + quoted(input.handoffPath) + "\n" +
      "$handoff=Get-Content -LiteralPath $handoffPath -Encoding UTF8\n" +
      "$projectRoot=" + quoted(input.projectRoot ?? input.cwd) + "\n" +
        "$prefix=" + quoted(input.activePrefix) + "\n" +
        "$step=[array]::IndexOf($handoff,'## Следующий шаг'); $prompt=[array]::IndexOf($handoff,'## Промпт')\n" +
        "if($step -lt 0 -or $prompt -le $step+1){throw 'Cannot identify HANDOFF next step'}\n" +
        "$matches=@($handoff[($step+1)..($prompt-1)] | Where-Object {$_ -and $_.Trim().StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)})\n" +
        "$journalEntry=@(); $heading=" + quoted(input.journalHeading ?? "") + "\n" +
        "$journal=" + quoted(input.journalPath ?? "") + "\n" +
        "if($journal -and (Test-Path -LiteralPath $journal -PathType Leaf)){\n" +
        "  $entry=Get-Content -LiteralPath $journal -Encoding UTF8\n" +
        "  $found=if($heading){[array]::IndexOf($entry,$heading)}else{ for($i=0;$i -lt $entry.Count;$i++){if($entry[$i].StartsWith('## ')){$i;break}} }\n" +
        "  if($null -ne $found -and $found -ge 0){ for($i=$found;$i -lt $entry.Count -and ($i -eq $found -or -not $entry[$i].StartsWith('## '));$i++){$journalEntry+=($entry[$i].Substring(0,[Math]::Min(450,$entry[$i].Length)))} }\n" +
        "}\n" +
        "$root=(Get-Location).Path.Replace('\\','/'); $git=@(git -c ('safe.directory='+$root) status --porcelain=v1 --untracked-files=normal 2>$null); $statusOk=$LASTEXITCODE -eq 0\n" +
        "$head=if($statusOk){git -c ('safe.directory='+$root) rev-parse --short HEAD 2>$null}\n" +
        "$paths=@($matches | ForEach-Object {$_.Substring(0,[Math]::Min(600,$_.Length))} | Select-Object -First 6)\n" +
      "$evidence=''; $evidenceName=$null; $evidenceKind='none'\n" +
      "if($matches.Count -eq 1){\n" +
      "  $line=$matches[0]\n" +
      "  $parent=[IO.Path]::GetDirectoryName($handoffPath)\n" +
      "  $base=[IO.Path]::GetFullPath($projectRoot).TrimEnd('\\','/')+[IO.Path]::DirectorySeparatorChar\n" +
      "  foreach($link in [regex]::Matches($line,'\\]\\((?:<([^>]+)>|([^\\s)]+))\\)')){\n" +
      "    $raw=if($link.Groups[1].Success){$link.Groups[1].Value}else{$link.Groups[2].Value}\n" +
      "    if($raw -match '^[a-z][a-z0-9+.-]+://|^[/\\\\]{2}') {continue}\n" +
      "    try{$full=[IO.Path]::GetFullPath($raw,$parent)}catch{continue}\n" +
      "    if(-not $full.StartsWith($base,[StringComparison]::OrdinalIgnoreCase) -or\n" +
      "        [IO.Path]::GetExtension($full) -notin @('.md','.txt') -or $full -eq $handoffPath){continue}\n" +
      "    $file=Get-Item -LiteralPath $full -ErrorAction SilentlyContinue\n" +
      "    if(-not $file -or $file.PSIsContainer -or $file.Length -gt 5000 -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint)){continue}\n" +
      "    $body=Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 -ErrorAction SilentlyContinue\n" +
      "    if($body -and $body.Trim().Length -ge 16){\n" +
      "      $evidence=$body; $evidenceName=$file.Name; $evidenceKind='linked_file'; break\n" +
      "    }\n" +
      "  }\n" +
      "  if(-not $evidence){\n" +
      "    $first=$line.Substring(0,[Math]::Min(1200,$line.Length))\n" +
      "    $plain=[regex]::Replace($first,'\\[[^]]+\\]\\([^)]*\\)','').Trim()\n" +
      "    if($plain.Length -ge 16){$evidence=$first; $evidenceKind='handoff_line'}\n" +
      "  }\n" +
      "}\n" +
        "[pscustomobject]@{handoffUpdated=($handoff | Where-Object { $_ -like 'Обновлено:*' } | Select-Object -First 1);matches=$paths;matchCount=$matches.Count;journal=$journalEntry;gitAvailable=$statusOk;head=$head;changeCount=$git.Count;gitStatus=@($git | Select-Object -First 12);evidence=$evidence;evidenceKind=$evidenceKind;evidenceName=$evidenceName} | ConvertTo-Json -Compress -Depth 4";
    const result = await tools.exec_command({cmd:"$ErrorActionPreference='Stop'\n" + command, workdir:input.cwd, max_output_tokens:8500});
    if (result.exit_code !== 0 || result.original_token_count > 8500) {
      throw Error("Cannot read the transfer preparation snapshot without truncation");
    }
    return JSON.parse(result.output.trim());
  }
  async function registry(projectId) {
    const command = "$id=" + quoted(projectId) + "\n" +
      "$registryPath=Join-Path ([Environment]::GetFolderPath('UserProfile')) '.codex/.codex-global-state.json'\n" +
      "if(-not (Test-Path -LiteralPath $registryPath -PathType Leaf)){return}\n" +
      "$state=Get-Content -LiteralPath $registryPath -Raw -Encoding UTF8 | ConvertFrom-Json -AsHashtable\n" +
      "$record=$state['local-projects'][$id]\n" +
      "if($record.id -ne $id -or -not $record.rootPaths -or -not (Test-Path -LiteralPath $record.rootPaths[0] -PathType Container)){return}\n" +
      "[pscustomobject]@{projectId=$record.id;projectKind='local';hostId='local';path=$record.rootPaths[0]} | ConvertTo-Json -Compress";
    const result = await tools.exec_command({cmd:"$ErrorActionPreference='Stop'\n" + command, max_output_tokens:500});
    if (result.exit_code !== 0) throw Error("Cannot read the local Codex project registration");
    return result.output.trim() ? JSON.parse(result.output.trim()) : null;
  }
  const workflow = transferBlocks({
    local,
    registry,
    now: () => Date.now(),
    previous: pre => load(stateKey(pre.oldId)),
    remember: state => store(stateKey(state.oldId),state),
    call: async (name,args) => {
      const fn = tools["mcp__codex_app__" + name];
      if (typeof fn !== "function") throw Error("Codex tool unavailable: " + name);
      const result = await fn(args);
      if (result.isError) throw Error("Codex tool returned an error: " + name);
      const content = result.structuredContent ??
        JSON.parse(result.content?.find(item => item.type === "text")?.text ?? "null");
      if (!content || typeof content !== "object") throw Error("Codex returned no usable result: " + name);
      return content;
    }
  });
  const compact = result => {
    const {evidence, prompt, local:localSnapshot, task, point, continuationTask, ...summary} = result;
    return summary;
  };
  return {
    prepare: async input => {
      if (!input.oldId || !input.hostId || !input.cwd || !input.handoffPath || !input.activePrefix) {
        throw Error("Current chat, project and HANDOFF branch must be identified");
      }
      const pre = await workflow.prepare(input);
      store("transfer-preflight:" + input.oldId,pre);
      const {evidence, ...summary} = pre;
      return summary;
    },
    transfer: async (oldId,plan) => compact(await workflow.transfer(load("transfer-preflight:" + oldId) ?? {},plan)),
    resume: async oldId => {
      const state = load(stateKey(oldId));
      if (!state?.threadId) return {status:"check_existing_creation",title:state?.title};
      return compact(await workflow.finish(state));
    }
  };
}

return liveTransfer;
})()
