'use strict';
// Warn about the context reserve. This process never opens chats or blocks tools.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const EVENTS = new Set(['UserPromptSubmit', 'PreToolUse', 'PostToolUse', 'PreCompact', 'Stop']);
const EARLY = 0.75;
const PREPARE = 0.80;
const TRANSFER_REMINDER = 'В связи с большой контекстной нагрузкой, рекомендую перенос диалога в новый чат. Автоматический перенос выполняется по команде "переноси"';
const FINAL_REMINDER_INSTRUCTION = 'Начни итоговый ответ с короткого предупреждения о высокой нагрузке и рекомендации переноса, даже если оно уже появилось по ходу работы. Можно своими словами. Сохрани основной ответ.\n\n' + TRANSFER_REMINDER;
const COMPACTION_NOTICE = 'Контекст этого чата был сжат.';
const QUOTED_TEXT = /«[^»]*»|“[^”]*”|"[^"]*"|`+[^`]*`+/gu;
const FENCED_TEXT = /^[ \t]*(`{3,}|~{3,})[^\n]*\n[\s\S]*?(?:^[ \t]*\1[ \t]*\r?$|(?![\s\S]))/gmu;
const CONTINUATION = /(?<![\p{L}\p{N}])(?:продолжай(?:те)?|продолжать)(?:\s*,\s*пожалуйста\s*,)?\s+до\s+переноса(?![\p{L}\p{N}])/giu;
const COMMAND_MENTION_PREFIX = /(?:^|[^\p{L}])(?:фраз[аеуы]|команд[аеуы]|пример(?:\s+команды)?|сообщение|названи[ея]\s+команды|остав(?:ить|ь|ьте)(?:\s+только)?|замен(?:ить|и|ите)\s+на|что\s+значит|означает|объясни|проверь|напис(?:ать|ал[аи]?|ал[аи]сь|ано)|напиш(?:у|ешь|ет|ем|ете|ут)|сказ(?:ать|ал[аи]?|ано)|скажу|ввести|ввёл[аи]?)\s*:?\s*$/iu;
const COMMAND_CANCELLED = /(?:^|[,.!?;\n])\s*(?:отмена|отмени\s+(?:эту\s+)?команду|хватит|стоп|(?:вс[её],\s*)?отлож(?:и|им|ите)|больше\s+ничего\s+не\s+проверяй)(?!\p{L})/iu;
const TRANSFER_SCOPE = '«Продолжай до переноса» означает: продолжай активную работу в этом чате, даже если отдельного ТЗ нет. Если закончен этап, переходи к следующему доступному этапу той же работы в этом же ходе. Используй исходное поручение, согласованные границы и точку продолжения в HANDOFF, когда она есть. Учитывай ограничения по периоду и источникам, если владелец явно их задал. После каждой партии по исходному поручению и актуальному списку работ найди ближайшую доступную позицию и сразу возьми её в этом же ходе. Сверка одной партии задачи не завершает весь согласованный объём. Остановись, когда пора сохранять контекст для нового чата, вся работа завершена или дальнейшие действия требуют решения владельца. При необходимости решения сначала выполни всё независимое. На границе переноса выполни полный СТОП и дождись отдельной команды владельца.';
const END_REPORT = 'В финальном ответе укажи отдельной строкой одно проверяемое основание остановки: «Продолжение — завершено: <что выполнено и проверено по всей задаче>», «Продолжение — нужно решение: <что именно требуется и почему доступные шаги исчерпаны>» или «Продолжение — граница переноса: СТОП выполнен, <что сохранено>». Используй строку только при фактическом выполнении её условия.';
const REVIEW_STOP = 'Сверь всю задачу. Если остался доступный шаг, продолжи.';
const REVIEW_AT_BOUNDARY = 'У границы начни подготовку к СТОП.';
const REVIEW_CONTEXT = 'Если советник вернёт финал на сверку, восстанови весь согласованный объём по поручению и проектным данным. ' +
  'Проверь ближайшую непроверенную позицию по актуальной описи, списку работ или исходному поручению. Не закрывай весь объём по итогам одной партии. Уточнение об одной позиции сохраняет остальной объём, если владелец явно его не сузил. ' +
  'Выполни ближайший доступный шаг в этом ходе. Для блокера назови необходимое решение и исчерпанные независимые шаги. ' +
  'Для границы проверь полный СТОП по проектному протоколу. Укажи время обновления HANDOFF и точный заголовок записи журнала. ' +
  'В итоговом ответе добавь строку «Сверка объёма: …» с охватом, способом проверки и состоянием оставшихся шагов. ' +
  'Для «завершено» добавь строку «Проверка продолжения: …». Назови источник или список, по которому проверены оставшиеся позиции, и объясни, почему в согласованном объёме не осталось доступного шага. ' +
  END_REPORT;
const REVIEW_NEXT_POSITION = 'Сверь ближайшую оставшуюся позицию по исходному поручению и актуальному списку работ. Если она доступна в согласованном объёме, выполни её в этом же ходе. При завершении укажи «Проверка продолжения: …» с источником и результатом проверки оставшихся позиций.';
const REVIEW_UNCONFIRMED = 'Советник не подтвердил основание завершения после перепроверки. Сверь оставшуюся работу по исходному поручению.';
const STATE_WARNING = 'Советник не смог прочитать или записать состояние проверки. Основание завершения требует ручной сверки.';
const END_REPORT_LINE = /^[ \t]*(?:(?:#{1,6}|[-+]|\d+[.)])[ \t]+)?Продолжение[ \t]*[—–-][ \t]*(завершено|нужно решение|граница переноса):[ \t]*(?:\r?\n[ \t]*)?([^\s>#][^\r\n]*)$/gmu;
const VAGUE_OUTCOME = /^(?:готово|вс[её] (?:готово|сделано|проверено|выполнено)|задача завершена|нужн[оы] уточнени[ея]|нужно решение|нужен ответ|нет данных)[.!\s]*$/iu;
const AVAILABLE_STEP = /(?:^|\n)\s*(?:следующий доступный шаг)[ \t:—-]|(?:проверен\p{L}*|сверен\p{L}*|выполнен\p{L}*)\s+(?:только|одна партия|одну партию)(?!\p{L})/iu;
const NEXT_STAGE = /(?<!\p{L})(?:следующ(?:ий\s+(?:этап|шаг)|ая\s+(?:задача|проверка))\s*[:—–-]|дальше\s+(?:можно|перейду|продолжу|проверю|сверю|сделаю)\s+)[^\r\n.]*/giu;
const OUTSIDE_SCOPE = /(?:за пределами|вне)\s+(?:текущего\s+|текущей\s+)?(?:поручения|задачи|согласованных границ)/iu;
const INCOMPLETE_STOP = /(?<!\p{L})не\s+(?:сохран\p{L}*|обновл\p{L}*|зафиксирован\p{L}*|выполнен\p{L}*|отправлен\p{L}*|записан\p{L}*|коммит\p{L}*|провер\p{L}*)/iu;
const PENDING_RESULT = /пока\s+не\s+(?:найден\p{L}*|установлен\p{L}*|получен\p{L}*)/iu;
const SCAN_BATCH = 6;
const TRANSFER = /^(?:(?:да|хорошо|спасибо)[,!.\s]+)?(?:(?:переноси|выполни\s+перенос)(?:\s+(?:в новый чат|и закоммить)|[ ,\t]+(?:и(?:\s+(?:потом|затем))?|потом|затем)\s+продолжай)*|продолжай перенос)(?=\s*(?:$|[.!;,\n]))/iu;
const CLOSE = /^(?:стоп|всё|все|пока|завершай(?:\s+(?:работу|сессию))?)(?:[.!…\s]*|[,.;\s]+сохрани\s+(?:контекст|итоги|результаты)[.!…\s]*)$/iu;
const MAX_TAIL = 8 * 1024 * 1024;
const SCAN_RANGE = /(?:кадр\p{L}*|скан\p{L}*|разворот\p{L}*|страниц\p{L}*)\s*(?:с\s+)?(\d+)\s*(?:[-–—]|\sпо\s)\s*(\d+)/giu;

function* transcriptEntries(file, since = 0) {
  if (!file) return;
  let descriptor;
  try {
    descriptor = fs.openSync(file, 'r');
    let end = fs.fstatSync(descriptor).size;
    const floor = Math.max(since, end - MAX_TAIL);
    let remainder = Buffer.alloc(0);
    while (end > floor) {
      const start = Math.max(floor, end - 128 * 1024);
      const chunk = Buffer.alloc(end - start);
      const n = fs.readSync(descriptor, chunk, 0, chunk.length, start);
      const lines = Buffer.concat([chunk.subarray(0, n), remainder]);
      let limit = lines.length;
      for (let i = limit - 1; i >= 0; i--) {
        if (lines[i] !== 10) continue;
        const entry = parseEntry(lines.toString('utf8', i + 1, limit));
        if (entry) yield entry;
        limit = i;
      }
      remainder = lines.subarray(0, limit);
      end = start;
    }
    if (floor === 0 || floor === since) {
      const entry = parseEntry(remainder.toString('utf8'));
      if (entry) yield entry;
    }
  } catch { /* A transcript may be unavailable or in the middle of a write. */ }
  finally { if (descriptor !== undefined) fs.closeSync(descriptor); }
}

function parseEntry(line) {
  if (!line.startsWith('{')) return null;
  try { return JSON.parse(line); } catch { return null; }
}

function isCompaction(entry) {
  return entry?.type === 'compacted' || entry?.payload?.type === 'context_compacted';
}

function hasCompaction(file, since) {
  for (const entry of transcriptEntries(file, since)) if (isCompaction(entry)) return true;
  return false;
}

function restoreCompactionHistory(file, state) {
  if (!file || state.compactionHistoryChecked || state.compactionNoticeActive) return;
  for (const entry of transcriptEntries(file)) {
    state.compactionHistoryChecked = true;
    if (isCompaction(entry)) {
      state.compactionNoticeActive = true;
      break;
    }
  }
}

function contextObservation(file) {
  let measurement;
  for (const entry of transcriptEntries(file)) {
    if (isCompaction(entry)) return measurement ?? null;
    if (entry.type !== 'event_msg') continue;
    const payload = entry.payload;
    if (payload?.type === 'task_started' && measurement) {
      return { ...measurement, turnId: measurement.turnId ?? payload.turn_id };
    }
    if (payload?.type !== 'token_count' || !payload.info || measurement) continue;
    const { last_token_usage, model_context_window: window } = payload.info;
    const used = last_token_usage?.input_tokens;
    if (Number.isFinite(used) && Number.isFinite(window) && used >= 0 && window > 0 && used <= window) {
      measurement = { used, window, turnId: payload.turn_id };
    } else return null;
  }
  return measurement ?? null;
}

function metrics(file) {
  const observed = contextObservation(file);
  return observed && { used: observed.used, window: observed.window };
}

function interruptedPredecessor(file, turnId) {
  let resumeDetected = false;
  for (const entry of transcriptEntries(file)) {
    if (entry.type !== 'event_msg') continue;
    const payload = entry.payload;
    if (payload?.type === 'task_started') {
      if (resumeDetected) return null;
      if (payload.turn_id !== turnId || payload.turn_attribution?.turn_trigger !== 'resume_interrupted_task') return null;
      resumeDetected = true;
    }
    if (resumeDetected && payload?.type === 'turn_aborted') {
      return payload.reason === 'interrupted' ? payload.turn_id : null;
    }
    if (resumeDetected && payload?.type === 'task_complete') return null;
  }
  return null;
}

function scanBatch(input) {
  if (input.hook_event_name === 'UserPromptSubmit') {
    return Array.from(String(input.prompt ?? '').matchAll(SCAN_RANGE))
      .some(([, first, last]) => Number(last) - Number(first) + 1 >= SCAN_BATCH);
  }
  const args = input.tool_input;
  if (!args || typeof args !== 'object') return false;
  if (['images', 'image_paths', 'imagePaths', 'scans'].some(key =>
    Array.isArray(args[key]) && args[key].length >= SCAN_BATCH)) return true;
  const code = typeof args.code === 'string' ? args.code.slice(0, 24000) : '';
  return (code.match(/\b(?:view_image|emitImage|screenshot)\s*\(/gu) ?? []).length >= SCAN_BATCH;
}

function warn(event, message) {
  return {
    systemMessage: message,
    hookSpecificOutput: { hookEventName: event, additionalContext: message }
  };
}

function commandMode(prompt) {
  const plain = prompt.normalize('NFKC')
    .replace(FENCED_TEXT, ' ')
    .replace(/^[ \t]*>[^\r\n]*/gmu, ' ')
    .replace(/(?:&#x20;|&#32;|&nbsp;)/giu, ' ')
    .replace(/[\u200B-\u200F\u2060\uFEFF*_]/gu, '').trim();
  const clauses = plain.replace(QUOTED_TEXT, (quoted, offset) => {
    const inner = quoted.slice(1, -1).trim();
    const matches = [...inner.matchAll(CONTINUATION)];
    const standalone = offset === 0 && quoted.length === plain.length && matches[0]?.[0] === inner;
    const inline = quoted.startsWith('`') && (matches[0]?.[0] === inner || /^(?:продолжай|до|переноса)$/iu.test(inner));
    return standalone || inline ? ' ' + inner + ' ' : ' ';
  }).trim();
  if (CLOSE.test(clauses)) return 'stop';
  if (TRANSFER.test(clauses) && !COMMAND_CANCELLED.test(clauses)) return 'transfer';
  let mode = null;
  let last = 0;
  for (const match of clauses.matchAll(CONTINUATION)) {
    const before = clauses.slice(0, match.index).split(/[.!?;\n]/u).at(-1);
    const after = clauses.slice(match.index + match[0].length);
    if (COMMAND_MENTION_PREFIX.test(before) || /(?:^|\s)(?:если|как\s+работает|объясни|что\s+означает)(?:\s|$)/iu.test(before)) continue;
    if (/^[\s,]*\?/u.test(after)) continue;
    if (/^продолжать/iu.test(match[0]) && !/(?:не|нужно|надо)\s*$/iu.test(before)) continue;
    const negated = /(?:^|\s)не(?:\s+(?:надо|нужно|стоит|следует))?\s*$/iu.test(before);
    mode = negated ? 'cancel' : 'boundary';
    last = match.index + match[0].length;
  }
  return COMMAND_CANCELLED.test(clauses.slice(last)) ? 'cancel' : mode;
}

function reminderPrefixLength(text) {
  if (text.startsWith(TRANSFER_REMINDER)) return TRANSFER_REMINDER.length;
  const paragraph = text.split(/\r?\n[ \t]*\r?\n/u, 1)[0];
  if (paragraph.length > 420 || /^(?:>|\x60|«|["“]|[-*]\s)/u.test(paragraph)) return 0;
  const prose = paragraph.replace(/[*_]/gu, '').replace(/\s+/gu, ' ').trim();
  const highLoad = /(?:из[-‑–]за |в связи с |при )?(?:больш\p{L}*|высок\p{L}*) (?:контекстн\p{L}* нагрузк\p{L}*|нагрузк\p{L}* на контекст)|контекст(?:ное окно)? (?:почти заполнен\p{L}*|приблизил\p{L}* к границе|близ\p{L}* к (?:пределу|границе)|заполнен\p{L}* почти полностью)/iu.exec(prose);
  const measured = /контекст(?:ное окно)? заполнен\p{L}* на (\d{1,3}(?:[,.]\d+)?)\s*%/iu.exec(prose);
  const percent = Number(measured?.[1].replace(',', '.'));
  const pressure = highLoad ?? (percent >= 80 && percent <= 100 ? measured : null);
  const suggestion = /(?<!не )(?<!\p{L})(?:рекомендую|предлагаю|лучше|стоит|пора) (?:(?:начать|готовить|подготовить) )?(?:перенос\p{L}*|перенести|(?:перейти|переходить) в новый чат)/iu.exec(prose);
  if (!pressure || !suggestion || (pressure.index !== 0 && suggestion.index !== 0)) return 0;
  return paragraph.length;
}

function stopOutcome(message) {
  const text = message.replace(FENCED_TEXT, ' ')
    .replace(/^[ \t]*\*[ \t]+/gmu, '- ')
    .replace(/\*{1,3}|_{1,3}/gu, '');
  const prose = text.replace(/^[ \t]*>[^\r\n]*/gmu, ' ');
  const reports = Array.from(prose.matchAll(END_REPORT_LINE));
  const scope = [...prose.matchAll(/^[ \t]*(?:[-+] )?Сверка объёма\s*[:—–-][ \t]*([^<\s][^\r\n]*)$/gimu)];
  if (reports.length !== 1 || scope.length !== 1 || scope[0][1].trim().length < 16) return null;
  const [, kind, detail] = reports[0];
  if (detail.startsWith('<') || VAGUE_OUTCOME.test(detail) ||
      /^(?:готовенько|реши,?\s+продолжаем\s+ли|продолжить\s+ли)[.?!\s]*$/iu.test(detail)) return null;
  if (kind === 'граница переноса') {
    const saved = /^СТОП выполнен[,.:]\s+.+/iu.test(detail) && !INCOMPLETE_STOP.test(prose);
    const prompt = /^## Промпт[ \t]*\r?\n\s*>\s*\S/mu.test(text);
    const evidence = [/HANDOFF/iu, /(?:Git|репозиторий)/iu, /процесс/iu, /журнал/iu, /ретроспектив/iu]
      .every(pattern => pattern.test(prose));
    return saved && prompt && evidence ? kind : null;
  }
  const available = [...prose.matchAll(NEXT_STAGE)].some(([step]) => !OUTSIDE_SCOPE.test(step));
  if (AVAILABLE_STEP.test(prose) || available || /(?:^|\n)\s*осталось\s+(?:проверить|сверить|выполнить|обновить)/iu.test(prose)) return null;
  const continuationCheck = /^[ \t]*(?:[-+] )?Проверка продолжения[ \t]*[:—–-][ \t]*\S[^\r\n]{15,}$/imu;
  if (kind === 'завершено' && !continuationCheck.test(prose)) return null;
  if (kind === 'завершено' && PENDING_RESULT.test(prose) &&
      !/(?:все|весь|всю)\s+(?:доступн\p{L}*|согласованн\p{L}*)/iu.test(detail)) return null;
  return kind;
}

function currentBoundaryRecords(cwd, report) {
  if (typeof cwd !== 'string' || !path.isAbsolute(cwd)) return false;
  try {
    const kit = require('./kit.js');
    const config = kit.loadConfig();
    if (!config?.central || !config.projects_dir) return false;
    const root = kit.projectDir(config, cwd);
    const handoff = fs.readFileSync(path.join(root, 'HANDOFF.md'), 'utf8').trimEnd();
    const version = /^Обновлено: (\d{4}-\d{2}-\d{2} \d{2}:\d{2})$/mu.exec(handoff)?.[1];
    if (!version || !report.includes(version) || handoff.split('\n').length > 25 ||
        !/^## Следующий шаг\r?\n\s*\S/mu.test(handoff) ||
        !/^## Промпт\r?\n\s*>\s*\S/mu.test(handoff)) return false;
    const journal = fs.readFileSync(kit.journalFile(config, root), 'utf8');
    const entries = journal.split(/^## /mu).slice(1);
    return entries.some(entry => {
      const [heading, ...body] = entry.split(/\r?\n/u);
      const timestamp = /^\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}) — [^\]]+\]$/u.exec(heading)?.[1];
      if (!timestamp || timestamp < version || !report.includes(heading)) return false;
      const lines = body.map(line => line.replace(/\*/gu, '').trim());
      return ['Сделано', 'Дальше', 'Файлы', 'Статус'].every(label =>
        lines.some(line => new RegExp('^(?:[-#]+\\s+)?' + label + '(?:\\s*:|$)', 'u').test(line)));
    });
  } catch {
    return false;
  }
}

function assess(input, state) {
  const event = input.hook_event_name;
  const prompt = String(input.prompt ?? '').trim();
  const mode = event === 'UserPromptSubmit' ? commandMode(prompt) : null;
  const continueToTransfer = mode === 'boundary';
  if (state.continueTurn && state.continueTurn.mode !== 'boundary' && state.continueTurn.untilTransfer !== true) {
    delete state.continueTurn;
  }
  // Preserve the threshold signal across compaction. It is a prompt to evaluate readiness.
  if (state.prepareWarned) state.transferReminderActive = true;
  if (event === 'UserPromptSubmit' && !prompt.startsWith(REVIEW_STOP)) {
    if (input.turn_id && continueToTransfer) {
      if (state.continueTurn?.id === input.turn_id) state.continueTurn.mode = mode;
      else state.continueTurn = { id: input.turn_id, mode };
    } else if (mode || state.continueTurn?.id !== input.turn_id) {
      delete state.continueTurn;
    }
    state.transferCommand = mode === 'transfer';
    state.skipTransferNotice = state.transferCommand || mode === 'stop';
    state.batchWarned = false;
    delete state.finalReminderTurn;
    delete state.reminderRetryTurn;
    restoreCompactionHistory(input.transcript_path, state);
  } else if (state.continueTurn && input.turn_id && state.continueTurn.id !== input.turn_id &&
      interruptedPredecessor(input.transcript_path, input.turn_id) === state.continueTurn.id) {
    state.continueTurn = { id: input.turn_id, mode: 'boundary' };
  }

  const last = contextObservation(input.transcript_path);
  const fresh = last && (!last.turnId || !input.turn_id || last.turnId === input.turn_id);
  const pressure = fresh ? last.used / last.window : null;
  const prepareNow = pressure !== null && pressure >= PREPARE && !state.prepareWarned;
  const warnUserNow = prepareNow && !state.skipTransferNotice;
  if (pressure !== null && pressure >= PREPARE) state.transferReminderActive = true;

  if (event === 'PreCompact') {
    const inTransfer = state.transferCommand;
    const automatic = input.trigger === 'auto';
    const message = inTransfer && automatic
      ? 'Автосжатие при переносе: резерва не хватило. Сверь сохранённые решения и уже выполненные шаги СТОП перед продолжением.'
      : 'Зафиксировано сжатие контекста. Сверь сохранённые решения и ближайшую безопасную точку.';
    if (inTransfer && automatic) state.transferCompactions = (state.transferCompactions ?? 0) + 1;
    state.afterCompact = message;
    try {
      state.compactionOffset = fs.statSync(input.transcript_path).size;
    } catch { delete state.compactionOffset; }
    state.earlyWarned = state.prepareWarned = state.batchWarned = false;
    return { systemMessage: warnUserNow && automatic ? TRANSFER_REMINDER + '\n' + message : message };
  }

  if (Number.isSafeInteger(state.compactionOffset) &&
      hasCompaction(input.transcript_path, state.compactionOffset)) {
    state.compactionNoticeActive = state.compactionNoticePending = true;
    delete state.compactionOffset;
  }

  // Tool-free turns may produce their first high measurement only at Stop.
  if (event === 'Stop') {
    const signal = warnUserNow ? TRANSFER_REMINDER : '';
    if (signal) state.prepareWarned = state.earlyWarned = true;
    const reply = input.last_assistant_message ?? '';
    if (signal && input.turn_id) state.finalReminderTurn = input.turn_id;
    const reminderDue = Boolean(input.turn_id && state.finalReminderTurn === input.turn_id && !state.skipTransferNotice);
    const active = input.turn_id && state.continueTurn?.id === input.turn_id;
    const leadingReply = reply.trimStart();
    const reminderLength = reminderPrefixLength(leadingReply);
    const replyBody = leadingReply.slice(reminderLength);
    const fingerprint = active
      ? crypto.createHash('sha256').update(replyBody.normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '')).digest('hex')
      : null;
    if (active && !state.continueTurn.rechecked) {
      state.continueTurn.rechecked = true;
      state.continueTurn.firstReply = fingerprint;
      const reason = signal ? REVIEW_STOP + ' ' + REVIEW_AT_BOUNDARY : REVIEW_STOP;
      return { decision: 'block', reason: reminderDue ? reason + '\n\n' + FINAL_REMINDER_INSTRUCTION : reason };
    }
    const outcome = active ? stopOutcome(replyBody) : null;
    const unconfirmed = active && (!input.stop_hook_active || state.continueTurn.firstReply === fingerprint || !outcome ||
      (outcome === 'граница переноса' && !currentBoundaryRecords(input.cwd, reply)));
    if (unconfirmed && input.stop_hook_active && !state.continueTurn.nextPositionRechecked) {
      state.continueTurn.nextPositionRechecked = true;
      return {
        decision: 'block',
        reason: reminderDue ? REVIEW_NEXT_POSITION + '\n\n' + FINAL_REMINDER_INSTRUCTION : REVIEW_NEXT_POSITION,
        systemMessage: REVIEW_UNCONFIRMED
      };
    }
    const notices = [signal];
    const missingReminder = reminderDue && !reminderLength;
    const unwantedReminder = state.skipTransferNotice && (reminderLength || reply.includes(TRANSFER_REMINDER));
    const retryReminder = input.turn_id && reply.trim() && (missingReminder || unwantedReminder)
      && state.reminderRetryTurn !== input.turn_id;
    if (retryReminder) {
      state.reminderRetryTurn = input.turn_id;
    } else if (reminderDue && reply.trim()) {
      delete state.finalReminderTurn;
      if (missingReminder && !signal) notices.push(TRANSFER_REMINDER);
    }
    if (unconfirmed) notices.unshift(REVIEW_UNCONFIRMED);
    const systemMessage = notices.filter(Boolean).join('\n');
    if (retryReminder) {
      const reason = unwantedReminder
        ? 'Убери напоминание о переносе из итогового ответа на прямую команду владельца. Сохрани основной ответ.'
        : FINAL_REMINDER_INSTRUCTION;
      return { decision: 'block', reason, ...(systemMessage ? { systemMessage } : {}) };
    }
    return systemMessage ? { systemMessage } : {};
  }

  const messages = [];
  if (state.afterCompact) {
    messages.push(state.afterCompact + ' Обнови Оценка_контекста.md, если этого требуют правила проекта.');
    delete state.afterCompact;
  }
  if (prepareNow) {
    const next = state.transferCommand
      ? 'Проверь, что подготовка к СТОП уже началась, и продолжай с ближайшего незавершённого шага.'
      : 'На ближайшей безопасной границе начни подготовку к СТОП.';
    messages.push('Последний измеренный вход достиг порога 80%. ' + next + ' Новый чат открывай только по прямой команде владельца.');
    state.prepareWarned = state.earlyWarned = true;
  } else if (pressure !== null && pressure >= EARLY && !state.earlyWarned) {
    messages.push('Последний измеренный вход достиг порога 75%. До следующей партии оцени, хватит ли окна на неё и резерв 20% для полного СТОП. Это замер последнего входа.');
    state.earlyWarned = true;
  }
  if (!state.batchWarned && scanBatch(input)) {
    if (pressure === null) {
      messages.push('Намечена большая партия сканов, метрика недоступна. До начала задай ограниченную контрольную точку и оцени запас на полный СТОП.');
    } else {
      messages.push('Намечена большая партия сканов. До её начала проверь, сохранится ли резерв 20% на полный СТОП. Если есть риск израсходовать резерв, уменьши партию или начни подготовку раньше.');
    }
    state.batchWarned = true;
  }
  const result = messages.length ? warn(event, messages.join(' ')) : {};
  if (warnUserNow) result.systemMessage += '\n' + TRANSFER_REMINDER;
  if (state.compactionNoticePending) state.compactionNoticeActive = true;
  const showCompaction = state.compactionNoticeActive && !state.skipTransferNotice
    && (event === 'UserPromptSubmit' || (event === 'PostToolUse' && state.compactionNoticePending));
  const showTransfer = state.transferReminderActive && !state.skipTransferNotice && (event === 'UserPromptSubmit' || showCompaction || warnUserNow);
  if (showCompaction || showTransfer) {
    const notices = [];
    if (showCompaction) {
      notices.push(COMPACTION_NOTICE);
      delete state.compactionNoticePending;
    }
    if (showTransfer) notices.unshift(TRANSFER_REMINDER);
    const exception = 'Определи по смыслу всего сообщения, есть ли прямая просьба перенести чат или выполнить СТОП. Если есть, в этом ответе пропусти все строки ниже, включая напоминание о переносе и строку о сжатии. Упоминание команды, обсуждение или отказ от переноса сами по себе не считаются поручением.\n';
    const finalOnly = event === 'UserPromptSubmit' && !warnUserNow;
    if (showTransfer && input.turn_id) {
      state.finalReminderTurn = input.turn_id;
    }
    const placement = finalOnly || showTransfer ? 'итоговый ответ' : 'ответ';
    const subject = showTransfer && !showCompaction ? 'напоминания' : 'сообщения';
    const wording = showTransfer
      ? ' ровно один раз. Напоминание о нагрузке можно переформулировать, сохранив рекомендацию переноса. '
      : ' дословно и ровно один раз. ';
    const instruction = exception + (finalOnly ? 'Не показывай эти строки в промежуточных сообщениях. ' : '')
      + 'Начни ' + placement + ' со следующего ' + subject + wording
      + 'Затем оставь пустую строку и дай основной ответ:\n' + notices.join('\n');
    result.hookSpecificOutput = {
      hookEventName: event,
      additionalContext: [
        ...messages,
        instruction,
        ...(warnUserNow ? ['Если правило выше разрешает показать напоминание и работа в этом ходе продолжается, сразу покажи пользователю напоминание отдельным сообщением до следующего действия. Добавь напоминание и в начало итогового ответа этого же хода, даже если оно уже было показано по ходу работы.'] : []),
      ].join('\n\n'),
    };
  }
  if (continueToTransfer) {
    const context = result.hookSpecificOutput?.additionalContext;
    result.hookSpecificOutput = {
      hookEventName: event,
      additionalContext: [context, TRANSFER_SCOPE,
        state.continueTurn?.id === input.turn_id && input.turn_id ? REVIEW_CONTEXT : ''].filter(Boolean).join('\n\n'),
    };
  }
  return result;
}

function claimStateLock(lock) {
  const owner = path.join(lock, 'owner');
  const attempts = 7;
  for (let attempt = 0; attempt < attempts; attempt++) {
    try {
      fs.mkdirSync(lock);
      try { fs.writeFileSync(owner, String(process.pid), { flag: 'wx' }); }
      catch (error) { fs.rmdirSync(lock); throw error; }
      return () => {
        fs.unlinkSync(owner);
        fs.rmdirSync(lock);
      };
    } catch (error) {
      if (error.code !== 'EEXIST') throw error;
    }
    if (attempt === 0) {
      try {
        const observed = fs.statSync(lock);
        if (Date.now() - observed.mtimeMs > 30000) {
          let pid;
          try { pid = Number(fs.readFileSync(owner, 'utf8')); }
          catch (error) { if (error.code !== 'ENOENT') throw error; }
          let alive = Number.isSafeInteger(pid) && pid > 0;
          try { if (alive) process.kill(pid, 0); }
          catch (error) { if (error.code === 'ESRCH') alive = false; else throw error; }
          const current = fs.statSync(lock);
          if (!alive && observed.ino === current.ino && observed.mtimeMs === current.mtimeMs) {
            try { fs.unlinkSync(owner); }
            catch (error) { if (error.code !== 'ENOENT') throw error; }
            fs.rmdirSync(lock);
          }
        }
      } catch { /* A concurrent process may already have released the lock. */ }
    }
    if (attempt + 1 < attempts) Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 60);
  }
  return null;
}

function recoveredTurn(input) {
  const prior = interruptedPredecessor(input.transcript_path, input.turn_id);
  let mode;
  for (const entry of transcriptEntries(input.transcript_path)) {
    const payload = entry.payload;
    if (entry.type === 'response_item' && payload?.type === 'message' && payload.role === 'user' && !mode) {
      const body = payload.content?.find(item => item.type === 'input_text')?.text;
      if (body && !/^\s*<(?:environment_context|INSTRUCTIONS)>/u.test(body) &&
          !/^\s*# AGENTS\.md instructions/u.test(body)) mode = commandMode(body);
    }
    if (entry.type !== 'event_msg' || payload?.type !== 'task_started') continue;
    if (prior && payload.turn_id === input.turn_id && !mode) continue;
    if (payload.turn_id !== (prior ?? input.turn_id)) return null;
    return mode === 'boundary' ? { id: input.turn_id, mode } : null;
  }
  return null;
}

function run(input, { stateDir = path.join(process.env.CODEX_HOME || path.join(os.homedir(), '.codex'), 'session-advisor-reserve') } = {}) {
  if (!EVENTS.has(input?.hook_event_name) || !input.session_id) return {};
  let release;
  try {
    fs.mkdirSync(stateDir, { recursive: true });
    const key = crypto.createHash('sha256').update(String(input.session_id)).digest('hex');
    const stateFile = path.join(stateDir, key + '.json');
    release = claimStateLock(stateFile + '.lock');
    if (!release) return { systemMessage: STATE_WARNING };
    let state = {};
    let damaged = false;
    try {
      state = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
      if (!state || typeof state !== 'object' || Array.isArray(state)) throw new TypeError('Invalid advisor state');
    } catch (error) {
      damaged = error.code !== 'ENOENT';
      state = {};
      if (input.hook_event_name !== 'UserPromptSubmit' && input.turn_id && !input.stop_hook_active) {
        const restored = recoveredTurn(input);
        if (restored) state.continueTurn = restored;
      }
    }
    const original = JSON.stringify(state);
    const result = assess(input, state);
    const updated = JSON.stringify(state);
    if (damaged || updated !== original) {
      const temp = stateFile + '.' + process.pid + '.tmp';
      try {
        fs.writeFileSync(temp, updated);
        fs.renameSync(temp, stateFile);
      } finally {
        if (fs.existsSync(temp)) fs.unlinkSync(temp);
      }
    }
    if (damaged) result.systemMessage = [STATE_WARNING, result.systemMessage].filter(Boolean).join('\n');
    return result;
  } catch {
    return { systemMessage: STATE_WARNING };
  } finally {
    try { release?.(); } catch { /* A failed cleanup is diagnosed on the next invocation. */ }
  }
}

module.exports = { run, metrics };
if (require.main === module) {
  try {
    process.stdout.write(JSON.stringify(run(JSON.parse(fs.readFileSync(0, 'utf8')))));
  } catch {
    process.stdout.write(JSON.stringify({ systemMessage: STATE_WARNING }));
  }
}
