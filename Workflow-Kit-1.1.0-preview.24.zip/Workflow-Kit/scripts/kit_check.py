#!/usr/bin/env python3
"""Проверка установки memory-kit. Ничего не меняет, только смотрит и отвечает «да» или «нет».

Ставил ли набор install.py или агент по INSTALL.md — итог проверяется одинаково, этим скриптом.
Настройки берутся из memory-kit.json рядом с папкой scripts, то есть из папки агента.

  python kit_check.py                     # проверить установку, в которой лежит этот файл
  python kit_check.py --kit <папка набора>   # заодно сверить файлы с набором байт в байт
  python kit_check.py --agent-dir ~/.codex   # проверить другую папку агента

Папку набора можно один раз записать в настройки ключом "kit_dir": тогда сверка идёт всегда.
Код возврата 0 — всё на месте, 1 — есть пункты «НЕТ».
"""
import argparse
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile

try:
    import tomllib
except ImportError:  # Python 3.8–3.10: support a top-level numeric limit.
    tomllib = None

# Те же списки, что в install.py; совпадение сторожит tests/test_hooks.py
HOOK_FILES = ["kit.js", "session-start-context.js", "session-summary-check.js", "memory-index-hook.py",
              "memory-recall-hook.py", "session-advisor.cjs"]
ADVISOR = "session-advisor.cjs"
ADVISOR_EVENTS = ("UserPromptSubmit", "PreToolUse", "PostToolUse", "PreCompact", "Stop")
ADVISOR_TIMEOUT = 5
# SHA-256 from the distributed archives and the former standalone allowlist.
KNOWN_ADVISORS = {
    "382d2574be6e05d4fff42cda942ed32bbf61f719db0d11f5cd6b28450cbe9873": "отдельный выпуск 1.0.0",
    "95e6a80cc0cd9efe822c89fdaa5d27afd6a3b5f296c204ead65ece27a4d4bbcd": "отдельный выпуск 1.0.1",
    "77eee89095264a9eb5924876d5939493770eb991dbffbea30afc5b558a18d2ab": "отдельный выпуск 1.0.2",
    "d0a26a5b2cb840563e28f17013a0675b7855fa9e81a3882af7bd2800d67b1145": "отдельный выпуск 1.0.3",
    "01afa2c66d2dbde2db0573fd2041afef4b15d02aff6577be2cff009bd00e27d5": "отдельный выпуск 1.0.4",
    "9c83e091e6ff0524f7fbe547f7093f362ecb6222e3d54ce3864abcafa87a55f4": "отдельный выпуск 1.0.5",
    "b4444cb8bfda2c4a4cd16b65e61e93d22f540e3573612e62386203e6679b15e3": "1.1.0-preview.14",
    "6a8b6d3361020d9e565d3d898870ea0073a8a071b8be87272a71c76663a76007": "1.1.0-preview.15",
    "841e5f1df31be0aca2a67d5e588f288fca8e9985e8ffbc97f0640e80760a2ea6": "1.1.0-preview.16",
    "b8bbc6b17546de98aae3f25221f3cce00d38b6cfc26742f37ecab4b8989bd779": "1.1.0-preview.17",
    "29f6652159eb2880a5aad9d36674f64752b33149a5565dbe33e62e2ae6c08305": "1.1.0-preview.18",
    "c531126f62e4c0d93ff6d458b5dc19603e029327fdc19ddad2dbcba62a8cd7bf": "1.1.0-preview.19",
    "ea84fd9e0a84bf2a4a63c91b7ba6175516c1c4cd5378d0d5402d942dab5fd3b4": "1.1.0-preview.20",
    "954a06dc6e12b73399ce2f9439da5630b41b617b32dc5c828a88873745161bdc": "1.1.0-preview.21",
}
SCRIPT_FILES = ["memory_index.py", "memory_search.py", "session_archive.py", "project_index.py", "kit_check.py",
                "memory_report.py", "memory_upkeep.py",
                "find-zombies.ps1"]
HOOKS_ALIVE = "memory-kit: хуки работают"
CODEX_RULES_MAX = 32 * 1024
HANDOFF_MAX_CHARS = 5000                       # те же бюджеты, что в hooks/session-start-context.js
HANDOFF_TIGHT_SHARE = 0.38

TOOLS = {
    "codex": {"hooks_file": "hooks.json", "rules": "AGENTS.md"},
}
# событие, файл хука, режим (последнее слово команды)
WANTED = {
    "codex": [("SessionStart", "session-start-context.js", ""), ("PreCompact", "session-start-context.js", "precompact"),
              ("Stop", "session-summary-check.js", ""),
              ("Stop", "memory-index-hook.py", "stop"),
              ("PreToolUse", "memory-recall-hook.py", "pre"), ("SubagentStart", "memory-recall-hook.py", "subagent"),
              ("UserPromptSubmit", "memory-recall-hook.py", "prompt")]
             + [(event, ADVISOR, "") for event in ADVISOR_EVENTS],
}


def say(text=""):
    print(text)


def read(path):
    with open(path, encoding="utf-8", errors="replace") as fh:
        return fh.read()


def same_bytes(a, b):
    """Файлы совпадают; перевод строк не в счёт (git на Windows меняет его сам)."""
    with open(a, "rb") as fa, open(b, "rb") as fb:
        return fa.read().replace(b"\r\n", b"\n") == fb.read().replace(b"\r\n", b"\n")


def matches_hook_command(command, expected):
    if not isinstance(command, str):
        return False
    try:
        actual = shlex.split(command.replace("\\", "/"))
        wanted = shlex.split(expected.replace("\\", "/"))
    except ValueError:
        return False
    if len(wanted) < 2 or len(actual) != len(wanted) or norm(actual[1]) != norm(wanted[1]):
        return False
    if actual[2:] != wanted[2:]:
        return False
    if os.path.normcase(actual[0]) == os.path.normcase(wanted[0]):
        return True
    launcher = os.path.basename(actual[0]).casefold()
    if os.path.basename(wanted[1]) == ADVISOR:
        if (not re.fullmatch(r"node(?:\.exe)?", launcher)
                or (os.path.dirname(actual[0]) and not os.path.isabs(actual[0]))):
            return False
        canonical = shutil.which(wanted[0])
        registered = shutil.which(actual[0])
        return bool(canonical and registered
                    and norm(os.path.realpath(canonical)) == norm(os.path.realpath(registered)))
    pattern = r"node(?:\.exe)?" if wanted[1].endswith((".js", ".cjs")) else r"(?:python[0-9.]*|py)(?:\.exe)?"
    return re.fullmatch(pattern, launcher) is not None


def hook_registration_count(settings, event, matcher, expected_command, *, timeout=None):
    hooks = settings.get("hooks") or {} if isinstance(settings, dict) else {}
    groups = hooks.get(event) or [] if isinstance(hooks, dict) else []
    if not isinstance(groups, list):
        return 0
    return sum(
        1
        for group in groups
        if isinstance(group, dict) and group.get("matcher", "") == matcher and isinstance(group.get("hooks"), list)
        for handler in group["hooks"]
        if isinstance(handler, dict) and handler.get("type") == "command"
        and matches_hook_command(handler.get("command"), expected_command)
        and (timeout is None or (type(handler.get("timeout")) is int and handler["timeout"] == timeout))
    )


def norm(path):
    return os.path.normcase(os.path.abspath(path)).replace("\\", "/")


def codex_project_rules_budget(agent_dir, cwd):
    """Estimate the project instruction chain from user config and the given cwd."""
    config = {}
    try:
        source = read(os.path.join(agent_dir, "config.toml"))
        if tomllib is not None:
            config = tomllib.loads(source)
        else:
            top_level = re.split(r"(?m)^\s*\[", source, maxsplit=1)[0]
            match = re.search(r"(?m)^\s*project_doc_max_bytes\s*=\s*(\d[0-9_]*)\s*(?:#.*)?$", top_level)
            if match:
                config["project_doc_max_bytes"] = int(match[1].replace("_", ""))
    except (OSError, ValueError):
        pass
    limit = config.get("project_doc_max_bytes", CODEX_RULES_MAX)
    if type(limit) is not int or limit < 0:
        limit = CODEX_RULES_MAX
    markers = config.get("project_root_markers", [".git"])
    names = ["AGENTS.override.md", "AGENTS.md"] + config.get("project_doc_fallback_filenames", [])
    directory = os.path.abspath(cwd)
    chain = []
    while True:
        chain.append(directory)
        if any(os.path.exists(os.path.join(directory, marker)) for marker in markers):
            break
        parent = os.path.dirname(directory)
        if parent == directory:
            chain = chain[:1]  # Outside a project, Codex only checks cwd.
            break
        directory = parent
    total = 0
    for directory in reversed(chain):
        for name in names:
            if not isinstance(name, str) or os.path.basename(name) != name:
                continue
            path = os.path.join(directory, name)
            if os.path.isfile(path):
                total += os.path.getsize(path)
                break
    return total, limit


def run(cmd, cwd=None, stdin=None, *, env=None, timeout=30):
    try:
        return subprocess.run(cmd, cwd=cwd, input=stdin, capture_output=True, text=True, encoding="utf-8",
                              errors="replace", timeout=timeout,
                              env={**os.environ, "PYTHONIOENCODING": "utf-8", **(env or {})})
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(cmd, 1, "", f"тайм-аут ({timeout} с)")
    except OSError as error:
        return subprocess.CompletedProcess(cmd, 1, "", str(error))


def json_object(path):
    try:
        value = json.loads(read(path))
    except (OSError, ValueError):
        return {}
    return value if isinstance(value, dict) else {}


def file_sha256(path):
    try:
        with open(path, "rb") as source:
            return hashlib.sha256(source.read()).hexdigest()
    except OSError:
        return None


def report_hook_versions(agent_dir, reference=None):
    installed = os.path.join(agent_dir, "workflow-kit-package")
    tracked = json_object(os.path.join(installed, "installed-files.json"))
    release = os.path.join(installed, "release.json")
    version = json_object(release).get("version")
    recorded = file_sha256(release)
    trusted = isinstance(version, str) and recorded and tracked.get("release.json") == recorded
    say("Установленный комплект: " + (version if trusted else "версия не подтверждена"))
    reference_version = json_object(os.path.join(reference, "release.json")).get("version") if reference else None
    for name in HOOK_FILES:
        relative = f"hooks/{name}"
        actual = file_sha256(os.path.join(agent_dir, relative))
        if not actual:
            say(f"  {name}: файл недоступен")
            continue
        if trusted and actual == tracked.get(relative) == file_sha256(os.path.join(installed, relative)):
            component = "совпадает с комплектом " + version
        elif isinstance(reference_version, str) and actual == file_sha256(os.path.join(reference, relative)):
            component = "совпадает с проверяемым комплектом " + reference_version
        else:
            component = KNOWN_ADVISORS.get(actual, "версия не определена") if name == ADVISOR else "версия не определена"
        say(f"  {name}: {component}, SHA-256 {actual}")


def advisor_probe(agent_dir):
    """Run the installed advisor against synthetic events in a private profile."""
    node = shutil.which("node")
    if not node:
        return False, "node недоступен"
    cmd = [os.path.abspath(node), os.path.abspath(os.path.join(agent_dir, "hooks", ADVISOR))]
    with tempfile.TemporaryDirectory(prefix="workflow-kit-advisor-") as isolated:
        fixture = {"cwd": isolated, "session_id": "kit-check", "turn_id": "kit-check-turn"}
        env = {"CODEX_HOME": isolated}

        def event(kind, **fields):
            payload = json.dumps({**fixture, "hook_event_name": kind, **fields})
            result = run(cmd, cwd=isolated, stdin=payload, env=env, timeout=ADVISOR_TIMEOUT)
            if result.returncode != 0:
                return {}, f"{kind}: {result.stderr.strip()[:140] or result.returncode}"
            try:
                value = json.loads(result.stdout)
            except ValueError:
                return {}, f"{kind}: некорректный JSON"
            return (value, "") if isinstance(value, dict) else ({}, f"{kind}: ожидался объект JSON")

        prompt, error = event("UserPromptSubmit", prompt="Продолжай до переноса. Wavin оставь более свежий.")
        context = prompt.get("hookSpecificOutput")
        if error or not isinstance(context, dict) or not context.get("additionalContext"):
            return False, error or "UserPromptSubmit: нет контекста"
        message = ("Продолжение — завершено: выбор Wavin проверен по обложке, описи и поиску. "
                   "Все согласованные изменения партии выполнены.")
        stop, error = event("Stop", last_assistant_message=message)
        if error or stop.get("decision") != "block" or not stop.get("reason"):
            return False, error or "Stop: нет запроса на сверку"
        repeated, error = event("Stop", last_assistant_message=message, stop_hook_active=True)
        if error or repeated.get("decision") != "block" or not repeated.get("reason"):
            return False, error or "Stop: неподтверждённый итог не возвращён к оставшейся позиции"
        exhausted, error = event("Stop", last_assistant_message=message, stop_hook_active=True)
        if error or exhausted.get("decision") == "block" or not exhausted.get("systemMessage"):
            return False, error or "Stop: не соблюдён предел возвратов при неподтверждённом итоге"
        return True, "изолированный профиль, сверка и возврат к позиции сработали без зацикливания"


def report_desktop_status():
    say("Доверие Desktop: подтвердить в /hooks в выбранном профиле.")
    say("Живая приёмка Desktop: выполнить сценарий в Desktop и проверить новый ход.")


def main():
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    ap = argparse.ArgumentParser(description="Проверка установки memory-kit")
    ap.add_argument("--agent-dir", help="путь к профилю Codex, по умолчанию рядом с папкой scripts")
    ap.add_argument("--kit", help="папка набора: сверить установленные файлы с ней")
    args = ap.parse_args()

    agent_dir = os.path.abspath(os.path.expanduser(args.agent_dir)) if args.agent_dir else \
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    bad = 0
    warned = 0

    def line(ok, text):
        nonlocal bad
        bad += 0 if ok else 1
        say("  [%s] %s" % ("ок" if ok else "НЕТ", text))

    def warn(ok, text):
        """Установка цела, но агент получит не всё: в итог «НЕТ» не идёт."""
        nonlocal warned
        warned += 0 if ok else 1
        say("  [%s] %s" % ("ок" if ok else "!!", text))

    say("memory-kit: проверка %s" % agent_dir.replace("\\", "/"))
    cfg_path = os.path.join(agent_dir, "memory-kit.json")
    try:
        cfg = json.loads(read(cfg_path))
    except (OSError, ValueError) as e:
        line(False, "настройки memory-kit.json читаются (%s)" % type(e).__name__)
        say()
        say("Без настроек хуки молча ничего не делают. Дальше проверять нечего.")
        return 1
    line(True, "настройки memory-kit.json читаются")

    tool = cfg.get("tool")
    line(tool in TOOLS, "в настройках назван агент: %s" % tool)
    if tool not in TOOLS:
        return 1
    for key in ("root", "central"):
        value = cfg.get(key)
        line(bool(value) and os.path.isdir(os.path.expanduser(value)), "папка %s на месте: %s" % (key, value))
    line(bool(cfg.get("projects_dir")), "в настройках есть projects_dir: %s" % cfg.get("projects_dir"))   # самой папки до первой сессии может не быть
    central = os.path.expanduser(cfg.get("central") or "")
    root = os.path.expanduser(cfg.get("root") or "")
    line(os.path.exists(os.path.join(central, "MEMORY.head.md")), "шапка оглавления общей памяти MEMORY.head.md")

    kit = args.kit or cfg.get("kit_dir")
    kit = os.path.abspath(os.path.expanduser(kit)) if kit else None
    if kit and not os.path.isdir(os.path.join(kit, "hooks")):
        line(False, "папка набора на месте: %s" % kit)
        kit = None
    report_hook_versions(agent_dir)
    say("Целостность файлов%s:" % (" (сверка с набором %s)" % kit.replace("\\", "/") if kit else ""))
    for sub, names in (("hooks", HOOK_FILES), ("scripts", SCRIPT_FILES)):
        for name in names:
            mine = os.path.join(agent_dir, sub, name)
            if not os.path.exists(mine):
                line(False, "%s/%s есть" % (sub, name))
            elif kit and os.path.exists(os.path.join(kit, sub, name)):
                line(same_bytes(mine, os.path.join(kit, sub, name)), "%s/%s совпадает с набором" % (sub, name))
            else:
                line(True, "%s/%s есть" % (sub, name))

    say("Хуки прописаны (%s):" % TOOLS[tool]["hooks_file"])
    try:
        settings = json.loads(read(os.path.join(agent_dir, TOOLS[tool]["hooks_file"])))
    except (OSError, ValueError):
        settings = {}
    for event, name, mode in WANTED[tool]:
        here = os.path.join(agent_dir, "hooks", name).replace("\\", "/")
        python = (sys.executable or "python").replace("\\", "/")
        parts = ["node" if name.endswith((".js", ".cjs")) else python, here] + ([mode] if mode else [])
        matcher = "Bash" if event == "PreToolUse" and mode == "pre" else ""
        count = hook_registration_count(settings, event, matcher, shlex.join(parts))
        label = "%s → %s%s" % (event, name, " " + mode if mode else "")
        line(count == 1, label + (" (дублируется)" if count > 1 else ""))
        if name == ADVISOR and count == 1:
            line(hook_registration_count(settings, event, matcher, shlex.join(parts), timeout=ADVISOR_TIMEOUT) == 1,
                 f"{label}, timeout = {ADVISOR_TIMEOUT} с")

    def matches_kit(*paths):
        return kit and all(os.path.isfile(os.path.join(agent_dir, name))
                           and os.path.isfile(os.path.join(kit, name))
                           and same_bytes(os.path.join(agent_dir, name), os.path.join(kit, name))
                           for name in paths)

    try:
        supports_safe_check = bool(kit) and json.loads(read(os.path.join(kit, "release.json"))).get("readOnlyStartupCheck") is True
    except (OSError, ValueError, AttributeError):
        supports_safe_check = False
    say("Локальный запуск:")
    if shutil.which("node"):
        if supports_safe_check and matches_kit("hooks/session-start-context.js", "hooks/kit.js"):
            r = run(["node", os.path.join(agent_dir, "hooks", "session-start-context.js"), "check"], cwd=root or None, stdin="{}")
            try:
                ctx = json.loads(r.stdout)["hookSpecificOutput"]["additionalContext"]
            except (ValueError, KeyError, TypeError):
                ctx = ""
            line(r.returncode == 0 and HOOKS_ALIVE in ctx, "хук начала сессии отдаёт метку «%s»" % HOOKS_ALIVE)
        else:
            line(False, "хук отличается от набора с режимом проверки без записи, запуск пропущен")
        advisor = f"hooks/{ADVISOR}"
        digest = file_sha256(os.path.join(agent_dir, advisor))
        if digest and kit and digest == file_sha256(os.path.join(kit, advisor)):
            ok, detail = advisor_probe(agent_dir)
            line(ok, "советник: UserPromptSubmit → Stop — " + detail)
        else:
            line(False, "запуск советника пропущен: файл не совпадает с комплектом")
    else:
        line(False, "node установлен (без него хук начала сессии не работает)")
    if matches_kit("scripts/memory_index.py"):
        r = run([sys.executable, "-B", os.path.join(agent_dir, "scripts", "memory_index.py"), central, "--dry"])
        line(r.returncode == 0, "сборщик оглавления: " + (r.stdout + r.stderr).strip()[:160])
    if matches_kit("scripts/memory_search.py"):
        r = run([sys.executable, "-B", os.path.join(agent_dir, "scripts", "memory_search.py"), "--no-log", "проверка"])
        line(r.returncode == 0, "поиск по памяти запускается")
    if matches_kit("hooks/memory-recall-hook.py"):
        probe = json.dumps({"session_id": "kit-check", "cwd": root, "tool_name": "Bash", "tool_input": {"command": "echo 1"}})
        r = run([sys.executable, "-B", os.path.join(agent_dir, "hooks", "memory-recall-hook.py"), "pre"], stdin=probe)
        line(r.returncode == 0 and not r.stdout.strip(), "хук подсказки молчит на обычной команде")

    if tool == "codex":
        say("Правила Codex:")
        total, limit = codex_project_rules_budget(agent_dir, root)
        line(total <= limit, "проектные правила для %s влезают в потолок Codex: %d из %d байт"
             % (root, total, limit))

    say("Что агент получит на старте:")
    rules_text = ""
    for path in (os.path.join(agent_dir, TOOLS[tool]["rules"]), os.path.join(root, TOOLS[tool]["rules"])):
        if os.path.exists(path):
            rules_text += read(path)
    warn(HOOKS_ALIVE in rules_text, "в правилах агента есть проверка метки «%s»: без неё он не скажет, что хуки молчат"
         % HOOKS_ALIVE)
    warn("memory_search" in rules_text, "в правилах агента есть команда поиска по памяти")

    tight = int(cfg.get("start_max_chars") or 0)
    limit = round(tight * HANDOFF_TIGHT_SHARE) if tight else HANDOFF_MAX_CHARS
    projects = [root] + [os.path.join(root, n) for n in sorted(os.listdir(root))] if os.path.isdir(root) else []
    long_notes = []
    for p in projects:
        note = os.path.join(p, "HANDOFF.md")
        if os.path.isfile(note):
            size = len(read(note).strip())
            if size > limit:
                long_notes.append("%s: %d" % (os.path.basename(p), size))
    warn(not long_notes, "записки HANDOFF влезают в старт (до %d знаков)%s" % (
        limit, "; длиннее: " + ", ".join(long_notes[:5]) + (" и ещё %d" % (len(long_notes) - 5) if len(long_notes) > 5 else "")
        + ". Конец такой записки агент видит, только если откроет файл" if long_notes else ""))

    if cfg.get("journal_path") and shutil.which("node") and matches_kit("hooks/kit.js"):
        here = os.getcwd()
        result = run(["node", os.path.join(agent_dir, "hooks", "kit.js"), "--project-locations", here], cwd=here)
        try:
            paths = json.loads(result.stdout) if result.returncode == 0 else {}
        except ValueError:
            paths = {}
        if paths.get("journalOverride"):
            journal = paths["journalFile"]
            warn(os.path.isfile(journal), "свой журнал найден для папки %s: %s"
                 % (os.path.basename(paths["project"]), journal))

    say()
    report_desktop_status()
    if not bad and warned:
        say("Предупреждений: %d. Установка цела, но разберись с ними: агент получит не всё." % warned)
    say("Всё на месте." if not bad else "Пунктов «НЕТ»: %d. Исправь их и запусти проверку ещё раз." % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
