(() => {
const transferBlocks = (function transferBlocks(api) {
  const normal = value => String(value ?? "").trim().replace(/\s+/g, " ").toLowerCase();
  const pathKey = value => String(value ?? "").trim().toLowerCase().replace(/\\/g, "/").replace(/\/+$/, "");
  const call = (name, args) => api.call(name, args);
  const remember = state => api.remember(state);
  const clockFromHost = seconds => Number.isFinite(seconds) ? seconds * 1000 : null;
  const oneLine = value => typeof value === "string" && value.trim().length > 0 && !/[\r\n]/.test(value);
  const turnReadOptions = {turnLimit:1, itemLimit:16, maxOutputCharsPerItem:20000, includeOutputs:false};
  const directTransfer = /^(?:(?:да|окей|хорошо|спасибо|тогда|теперь|пожалуйста|после проверки|после сверки|после стоп)[, \t]+)*(?:(?:переноси(?:те)?|выполни(?:те)?\s+перенос|перенеси(?:те)?\s+(?:этот\s+)?чат)(?:\s+(?:в новый чат|и закоммить)|[ ,\t]+(?:и(?:\s+(?:потом|затем))?|потом|затем)\s+продолжай)*|продолжай перенос)(?:[ \t]*,[ \t]*пожалуйста)?[ \t]*[.!;]*$/iu;
  const cancelTransfer = /^(?:(?:нет|хотя нет|пока)[, \t]+)*(?:(?:отбой|отмена)(?:\s+(?:переноса|команды))?|отменяю\s+перенос|передумал(?:а)?|останемся здесь|(?:отмени|отложи)(?:те)?\s+перенос|не\s+(?:переноси(?:те)?|переносить|перенеси(?:те)?|выполняй(?:те)?\s+перенос)(?:\s+(?:этот\s+)?чат)?)(?=$|[!.,;?])/iu;

  function commandClauses(value) {
    return value.replace(/(?:```|~~~)[\s\S]*?(?:```|~~~|$)|`[^`\n]*(?:`|$)|«[^»]*(?:»|$)|“[^”]*(?:”|$)|"[^"\n]*(?:"|$)|'[^'\n]*(?:'|$)|^(?:[ \t]*>| {4}|\t).*$/gm," □ ")
      .split(/(?<=[.!;?])[ \t]+|\r?\n/).map(clause => clause.trim());
  }

  function matchThread(thread, oldId, hostId, cwd) {
    return thread?.id === oldId && thread.kind === "codex" &&
      (!thread.hostId || thread.hostId === hostId) && pathKey(thread.cwd) === pathKey(cwd);
  }

  async function authorizedCommand(history, oldId, hostId) {
    const turn = history.turns?.[0];
    if (!turn?.id || !Array.isArray(turn.items)) return null;
    let items = turn.items;
    let cursor = turn.nextItemCursor;
    const seen = new Set();
    while (cursor) {
      if (seen.has(cursor)) return null;
      seen.add(cursor);
      const page = await call("read_thread", {threadId:oldId, hostId, itemCursor:cursor, itemLimit:100,
        maxOutputCharsPerItem:turnReadOptions.maxOutputCharsPerItem, includeOutputs:false});
      if (!Array.isArray(page.items)) return null;
      items = [...page.items,...items];
      cursor = page.nextItemCursor;
    }
    const userTexts = items.filter(item => item.type === "userMessage").map(item =>
      item.content?.filter(part => part.type === "text").map(part => part.text).join("\n") ?? "");
    if (!userTexts.length || userTexts.some(value => !value || value.length >= turnReadOptions.maxOutputCharsPerItem)) return null;
    const clauses = userTexts.map(commandClauses);
    const first = clauses.findIndex(parts => parts.some(clause => directTransfer.test(clause)));
    if (first < 0 || clauses.flat().some(clause => cancelTransfer.test(clause))) return null;
    return {id:turn.id, userTexts, commandMessageIndex:first};
  }

  function authorizesContinuation(command, task) {
    if (task === undefined) return command.userTexts.flatMap(commandClauses).some(clause =>
      directTransfer.test(clause) && /[ ,\t](?:и(?:\s+(?:потом|затем))?|потом|затем)\s+продолжай(?=$|[ \t.,!;])/iu.test(clause));
    const firstClause = commandClauses(task)[0];
    if (!/^\p{L}/u.test(firstClause) || firstClause.endsWith("?")) return false;
    return command.userTexts.some((value,index) => {
      if (index > command.commandMessageIndex && value === task) return true;
      if (!value.endsWith(task)) return false;
      const before = value.slice(0,-task.length);
      return /(?:[.!;][ \t\r\n]+|\r?\n[ \t]*)$/.test(before) &&
        directTransfer.test(commandClauses(before).filter(Boolean).at(-1) ?? "");
    });
  }

  function taskPaths(input) {
    if (input === undefined) return [];
    if (!Array.isArray(input)) return null;
    const paths = [];
    for (const entry of input) {
      if (typeof entry !== "string" || /[\x00-\x1f<>:"|?*]/.test(entry)) return null;
      const relative = entry.replaceAll("\\","/").replace(/^\.\//, "");
      if (relative.split("/").some(part => !part || /[ .]$/.test(part) || /^\.git$/i.test(part))) return null;
      paths.push(relative);
    }
    return [...new Set(paths)];
  }

  async function findDuplicate(hostId, projectId, title, archived) {
    const cursors = new Set();
    let cursor;
    do {
      if (cursors.has(cursor)) throw Error("Thread history cursor repeated");
      cursors.add(cursor);
      const page = await call("list_threads", {mode:"history", source:"codex", hostId, archived, cursor, limit:50});
      if (!Array.isArray(page.threads)) throw Error("Thread history unavailable");
      const duplicate = page.threads.find(thread =>
        normal(thread.title) === normal(title) && (!thread.projectId || thread.projectId === projectId));
      if (duplicate) return {id:duplicate.id, archived};
      cursor = page.nextCursor || undefined;
    } while (cursor);
    return null;
  }

  async function duplicateMatches(hostId, projectId, title) {
    const matches = await Promise.all([findDuplicate(hostId, projectId, title, false),
      findDuplicate(hostId, projectId, title, true)]);
    return matches.filter(Boolean);
  }

  async function prepare(input) {
    const {oldId, hostId, cwd} = input;
    const projectRoot = input.projectRoot ?? cwd;
    const [snapshot, history, projects, sidebar] = await Promise.all([
      api.local(input),
      call("read_thread", {threadId:oldId, hostId, ...turnReadOptions}),
      call("list_projects", {}),
      call("list_threads", {limit:12})
    ]);
    const {evidence, evidenceKind, evidenceName, ...local} = snapshot;
    const old = history.thread;
    const listed = [...(sidebar.pinnedThreads ?? []), ...(sidebar.threads ?? [])].find(item => item.id === oldId);
    const unverified = {status:"project_unverified", oldId, requestedPath:cwd, local};
    if (!matchThread(old,oldId,hostId,cwd)) return unverified;

    let project = projects.projects?.find(item =>
      ["local", "remote"].includes(item.projectKind) && item.hostId === hostId && pathKey(item.path) === pathKey(projectRoot));
    let projectSource = "list_projects";
    if (!project && hostId === "local" && listed?.projectId && listed.kind === "codex" &&
        listed.hostId === hostId && pathKey(listed.cwd) === pathKey(cwd)) {
      // The desktop connector can omit a registered project while still returning its thread membership.
      const registered = await api.registry?.(listed.projectId);
      if (registered?.projectId === listed.projectId && registered.hostId === hostId &&
          registered.projectKind === "local" && pathKey(registered.path) === pathKey(projectRoot)) {
        project = registered;
        projectSource = "local_registration";
      }
    }
    if (!project || (listed?.projectId && listed.projectId !== project.projectId)) return unverified;
    const suffix = /^(.*_)(\d+)$/.exec(old.title ?? "");
    const title = suffix ? suffix[1] + String(BigInt(suffix[2]) + 1n) : input.approvedTitle;
    if (!oneLine(title)) return {status:"name_required", oldTitle:old.title, local};
    const duplicates = await duplicateMatches(hostId, project.projectId, title);
    if (duplicates.length) return {status:"duplicate", title, matches:duplicates, local};
    const turn = history.turns?.[0];
    const command = await authorizedCommand(history,oldId,hostId).catch(() => null);
    const ownerCommand = command && (!input.commandTurnId || input.commandTurnId === command.id) ? command : null;
    const timedCommand = ownerCommand?.commandMessageIndex === 0 && (input.commandTurnId || input.commandConfirmed === true);
    return {status:"checked", evidence, evidenceKind, evidenceName, oldId, hostId, cwd, title, projectId:project.projectId, projectRoot, projectSource, local,
      stopEvidenceMissing:missingStopEvidence(local), ownerCommand, ownerCommandVerified:Boolean(ownerCommand),
      oldPinned:sidebar.pinnedThreads?.some(item => item.id === oldId) ?? false,
      handoffPath:input.handoffPath, model:input.model, modelMatchesDefault:input.modelMatchesDefault === true,
      stopInput:{cwd, projectRoot, handoffPath:input.handoffPath, activePrefix:input.activePrefix,
        journalPath:input.journalPath, journalHeading:input.journalHeading},
      turnStartedAt:timedCommand && Number.isFinite(turn?.startedAt) ? turn.startedAt : null};
  }

  async function commandStillCurrent(pre) {
    const {oldId,hostId,cwd,ownerCommand} = pre;
    const history = await call("read_thread", {threadId:oldId, hostId, ...turnReadOptions});
    if (!matchThread(history.thread,oldId,hostId,cwd) || history.turns?.[0]?.id !== ownerCommand.id) return false;
    const current = await authorizedCommand(history,oldId,hostId);
    return current?.userTexts.length === ownerCommand.userTexts.length &&
      current.userTexts.every((value,index) => value === ownerCommand.userTexts[index]);
  }

  function missingStopEvidence(snapshot) {
    const missing = [];
    if (snapshot?.handoffComplete !== true || !snapshot.handoffHash) missing.push("handoff");
    if (snapshot?.journalComplete !== true || !snapshot.journalHash) missing.push("journal");
    if (snapshot?.gitState !== "not_applicable" && (snapshot?.gitState !== "repository" ||
        !snapshot.head || !snapshot.gitHash || snapshot.handoffCommitted !== true ||
        (snapshot.remotes?.length && snapshot.pushMatches !== true))) {
      missing.push("git");
    }
    return missing;
  }

  async function verifyStop(pre, gitTaskPaths) {
    const checked = pre.local;
    let fresh;
    try {
      fresh = await api.local({...pre.stopInput, gitTaskPaths});
    } catch {
      return {status:"stop_evidence_unavailable"};
    }
    if (!fresh || typeof fresh !== "object") return {status:"stop_evidence_unavailable"};
    if (gitTaskPaths.length && fresh.gitState === "repository") {
      if (!Array.isArray(fresh.gitTaskStatus)) return {status:"git_task_files_unverified"};
      if (fresh.gitTaskStatus.length) return {status:"git_task_files_dirty", gitStatus:fresh.gitTaskStatus};
    }
    const changed = [];
    if (fresh.handoffHash !== checked.handoffHash || fresh.matchCount !== 1) changed.push("handoff");
    if (fresh.journalHash !== checked.journalHash) changed.push("journal");
    if (fresh.gitState !== checked.gitState || fresh.head !== checked.head || fresh.gitHash !== checked.gitHash) changed.push("git");
    if (fresh.evidence !== pre.evidence || fresh.evidenceKind !== pre.evidenceKind || fresh.evidenceName !== pre.evidenceName) changed.push("source");
    if (changed.length) return {status:"stop_evidence_changed", checks:changed};
    const freshMissing = missingStopEvidence(fresh);
    if (freshMissing.length) return {status:"stop_evidence_missing", checks:freshMissing};
    return null;
  }

  const isPinned = (sidebar, id, hostId) => sidebar.pinnedThreads?.some(item =>
    item.id === id && item.hostId === hostId);

  async function ensureNewPin(state) {
    let placeBeforeOld = state.oldPinned;
    if (state.pinAttempted !== false) {
      const sidebar = await call("list_threads", {limit:12});
      if (!Array.isArray(sidebar.pinnedThreads)) return {status:"sidebar_unverified"};
      if (isPinned(sidebar,state.threadId,state.hostId)) return {sidebar};
      placeBeforeOld = isPinned(sidebar,state.oldId,state.hostId);
    }
    state.pinAttempted = true;
    remember(state);
    let pinError;
    try {
      await call("move_thread_to_sidebar_section", {
        ...(placeBeforeOld ? {beforeThreadId:state.oldId} : {}),
        threadId:state.threadId,hostId:state.hostId,sectionId:"pinned"
      });
    } catch (error) {
      pinError = String(error.message ?? error);
    }
    const sidebar = await call("list_threads", {limit:12});
    if (!Array.isArray(sidebar.pinnedThreads)) return {status:"sidebar_unverified",pinError};
    if (!isPinned(sidebar,state.threadId,state.hostId)) return {status:"pin_unconfirmed",pinError};
    return {sidebar};
  }

  async function finish(state) {
    if (state.status === "complete") return state;
    state.timings ??= {
      commandStartedAt:clockFromHost(state.turnStartedAt), chatCreatedAt:null,
      confirmationReadyAt:null, confirmationReceivedAt:null, pinsVerifiedAt:null
    };
    try {
      const initialPin = await ensureNewPin(state);
      if (initialPin.status) return {...state, status:initialPin.status, pinError:initialPin.pinError};
      if (state.timings.chatCreatedAt === null) {
        const createdDetails = await call("read_thread", {threadId:state.threadId, hostId:state.hostId, includeTurns:false})
          .catch(() => null);
        const createdAt = createdDetails?.thread?.createdAt;
        if (createdDetails?.thread?.id === state.threadId && Number.isFinite(createdAt)) {
          state.timings.chatCreatedAt = clockFromHost(createdAt);
          if (Number.isFinite(state.turnStartedAt) && createdAt >= state.turnStartedAt) {
            state.secondsToCreate = createdAt - state.turnStartedAt;
          }
        }
        remember(state);
      }
      const wait = await call("wait_threads", {targets:[{threadId:state.threadId, hostId:state.hostId}], timeoutMs:45000});
      const poll = wait.polls?.find(item => item.thread?.id === state.threadId);
      const turn = poll?.latestTurn;
      if (!turn?.id || turn.status !== "completed") {
        return {...state, status:"confirmation_pending", wake:wait.wake?.reason, errors:wait.errors};
      }

      // wait_threads flattens whitespace. Use the full response from the same completed turn.
      const history = await call("read_thread", {threadId:state.threadId, hostId:state.hostId,
        turnLimit:3, maxOutputCharsPerItem:4096});
      const receivedAt = api.now();
      const originalTurn = history.thread?.id === state.threadId
        ? history.turns?.find(item => item.id === turn.id && item.status === "completed") : null;
      const finals = originalTurn?.items?.filter(item => item.type === "agentMessage" && item.phase === "final_answer") ?? [];
      const message = finals.length === 1 ? finals[0] : null;
      if (typeof message?.text !== "string") {
        return {...state, status:"confirmation_unverified", confirmationTurnId:turn.id};
      }
      const field = label => {
        const rows = message.text.split(/\r?\n/).filter(line => line.startsWith(label + ": "));
        return rows.length === 1 ? rows[0].slice(label.length + 2).trim() : "";
      };
      const fact = field("Факт");
      if (normal(field("Задача")) !== normal(state.task) || normal(field("Точка")) !== normal(state.point) ||
          fact.length < 16 || fact.length > 350 || normal(state.prompt).includes(normal(fact)) ||
          !normal(state.evidence).includes(normal(fact))) {
        return {...state, status:"confirmation_unverified", reply:message.text.slice(0,800)};
      }
      state.timings.confirmationReadyAt ??= clockFromHost(originalTurn.completedAt ?? turn.completedAt);
      state.timings.confirmationReceivedAt ??= receivedAt;
      const acceptedAt = api.now();
      remember(state);
      const verifiedPin = await ensureNewPin(state);
      if (verifiedPin.status) return {...state, status:verifiedPin.status, pinError:verifiedPin.pinError};
      const afterPin = verifiedPin.sidebar;
      const oldStillPinned = isPinned(afterPin,state.oldId,state.hostId);
      if (oldStillPinned) await call("move_thread_to_sidebar_section", {threadId:state.oldId, hostId:state.hostId, sectionId:"chats"});
      const final = oldStillPinned ? await call("list_threads", {limit:12}) : afterPin;
      if (!isPinned(final,state.threadId,state.hostId) || isPinned(final,state.oldId,state.hostId) || !Array.isArray(final.pinnedThreads)) {
        return {...state, status:"sidebar_unverified"};
      }
      const verifiedAt = api.now();
      state.timings.pinsVerifiedAt = verifiedAt;
      const result = {...state, status:"complete", fact, acceptedAt, verifiedAt,
        continuationStatus:state.continueAuthorized ? "unconfirmed" : state.continuationStatus ?? "not_requested"};
      // Persist the verified transfer and the attempt before dispatch. An uncertain send must not be retried blindly.
      remember(result);
      if (state.continueAuthorized) {
        try {
          await call("send_message_to_thread", {threadId:state.threadId, hostId:state.hostId,
            prompt:state.continuationTask ?? ("Перенос подтверждён. Продолжай задачу по HANDOFF: " + state.task +
              "\nСледующий шаг: " + state.point + "\nСоблюдай ограничения, сохранённые в HANDOFF и связанных файлах.")});
          result.continuationStatus = "submitted";
        } catch(e) {
          result.continuationError = String(e.message ?? e);
        }
        remember(result);
      }
      return result;
    } catch(e) {
      return {...state, status:"step_unconfirmed", error:String(e.message ?? e)};
    }
  }

  async function transfer(pre, plan) {
    if (pre.status !== "checked") return {status:"preflight_required"};
    if (api.previous?.(pre)) return {status:"check_existing_creation", title:pre.title};
    if (plan.ownerAuthorized !== true || !pre.ownerCommand) return {status:"owner_command_required"};
    if (plan.stopVerified !== true) return {status:"stop_required"};
    if (pre.local?.matches?.length !== 1 || (pre.local.matchCount ?? 1) !== 1) {
      return {status:"active_branch_unverified"};
    }
    if (!pre.model && !pre.modelMatchesDefault) return {status:"model_unverified"};
    if (!oneLine(plan.task) || !oneLine(plan.point)) return {status:"invalid_plan"};
    if (plan.continuationTask !== undefined && (plan.continueAuthorized !== true ||
        typeof plan.continuationTask !== "string" || !plan.continuationTask.trim())) return {status:"invalid_plan"};
    const gitTaskPaths = taskPaths(plan.gitTaskPaths);
    if (!gitTaskPaths) return {status:"invalid_plan"};
    const continueAuthorized = plan.continueAuthorized === true && authorizesContinuation(pre.ownerCommand,plan.continuationTask);
    const {evidence, evidenceKind, evidenceName} = pre;
    if (typeof evidence !== "string" || evidence.trim().length < 16) return {status:"evidence_unavailable"};
    const missing = missingStopEvidence(pre.local);
    if (missing.length) return {status:"stop_evidence_missing", checks:missing};
    let duplicates;
    try {
      duplicates = await duplicateMatches(pre.hostId, pre.projectId, pre.title);
    } catch {
      return {status:"duplicate_check_unavailable", title:pre.title};
    }
    if (duplicates.length) return {status:"duplicate", title:pre.title, matches:duplicates};
    const hint = evidenceKind === "handoff_line" ? "факт из строки активной ветки"
      : "факт из файла «" + evidenceName.replace(/[[\]\\]/g, "\\$&") + "»";
    const prompt = "Задача: " + plan.task.trim() + "\n\nHANDOFF: [HANDOFF.md — " + hint + "](<" + pre.handoffPath +
      ">)\n\nТочка: " + plan.point.trim();
    const stopProblem = await verifyStop(pre,gitTaskPaths);
    if (stopProblem) return stopProblem;
    if (!await commandStillCurrent(pre).catch(() => false)) return {status:"owner_command_unverified"};
    if (api.previous?.(pre)) return {status:"check_existing_creation", title:pre.title};
    const requestAt = api.now();
    const attempt = {oldId:pre.oldId, title:pre.title, requestAt};
    remember(attempt);
    let created;
    try {
      created = await call("create_thread", {title:pre.title, prompt, ...(pre.model ? {model:pre.model} : {}),
        target:{type:"project", projectId:pre.projectId, environment:{type:"local"}}});
    } catch(e) {
      return {status:"creation_unconfirmed", oldId:pre.oldId, title:pre.title, requestAt, error:String(e.message ?? e)};
    }
    const returnedAt = api.now();
    if (!created.threadId || created.hostId !== pre.hostId) {
      return {status:"creation_unconfirmed", oldId:pre.oldId, title:pre.title, requestAt,
        clientThreadId:created.clientThreadId};
    }
    const secondsToCreate = Number.isFinite(pre.turnStartedAt) && Number.isFinite(created.createdAt) && created.createdAt >= pre.turnStartedAt
      ? created.createdAt - pre.turnStartedAt : null;
    const secondsToConfirmation = Number.isFinite(pre.turnStartedAt) ? returnedAt / 1000 - pre.turnStartedAt : null;
    const state = {...pre, threadId:created.threadId, prompt, task:plan.task, point:plan.point, evidence,
      requestAt, returnedAt, secondsToCreate, secondsToConfirmation, pinAttempted:false,
      continueAuthorized, continuationTask:continueAuthorized ? plan.continuationTask : undefined,
      continuationStatus:plan.continueAuthorized === true && !continueAuthorized ? "user_authorization_unverified" : undefined,
      timings:{commandStartedAt:clockFromHost(pre.turnStartedAt), chatCreatedAt:clockFromHost(created.createdAt),
        confirmationReadyAt:null, confirmationReceivedAt:null, pinsVerifiedAt:null}};
    remember(state);
    return finish(state);
  }

  return {prepare, transfer, finish};
});

/* The V8 tool adapter stays here so preparation and dispatch use the same data contract. */
function liveTransfer(runtime) {
  const {tools, store, load} = runtime;
  const stateKey = oldId => "transfer-state:" + oldId;
  const quoted = value => "'" + String(value).replace(/'/g, "''") + "'";
  async function local(input) {
    const command = String.raw`
$handoffPath = [IO.Path]::GetFullPath(${quoted(input.handoffPath)})
$projectRoot = [IO.Path]::GetFullPath(${quoted(input.projectRoot ?? input.cwd)})
$prefix = ${quoted(input.activePrefix)}
$journal = ${quoted(input.journalPath ?? "")}
$heading = ${quoted(input.journalHeading ?? "")}
$taskPaths = @(${(input.gitTaskPaths ?? []).map(quoted).join(",")})

function Get-TextHash([string] $value) {
  [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($value)))
}

if ($handoffPath -ne (Join-Path $projectRoot 'HANDOFF.md')) { throw 'HANDOFF is outside the project root' }
$handoffText = Get-Content -LiteralPath $handoffPath -Raw -Encoding UTF8
$handoff = @($handoffText -split '\r?\n')
if ($handoff[-1] -eq '') { $handoff = @($handoff | Select-Object -SkipLast 1) }
$step = [array]::IndexOf($handoff,'## Следующий шаг')
$prompt = [array]::IndexOf($handoff,'## Промпт')
$activeLines = @()
if ($step -ge 0 -and $prompt -gt $step+1) {
  $activeLines = @($handoff[($step+1)..($prompt-1)] | Where-Object { $_.Trim().StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase) })
}
$paths = @($activeLines | Select-Object -First 6 | ForEach-Object { $_.Substring(0,[Math]::Min(600,$_.Length)) })
$updated = @($handoff | Where-Object { $_ -match '^Обновлено: \d{4}-\d{2}-\d{2} \d{2}:\d{2}$' })
$statuses = @($handoff | Where-Object { $_ -match '^## Статус: \S' })
$required = @('## Текущее состояние','## Задачи','## Блокеры','## Что пробовали и не сработало','## Хрупкие места','## Следующий шаг','## Промпт')
$labels = @($handoff | Where-Object { $_ -cin $required })
$handoffComplete = $handoff.Count -le 25 -and $handoff[0] -match '^# HANDOFF — \S' -and
  $updated.Count -eq 1 -and $statuses.Count -eq 1 -and ($labels -join '|') -ceq ($required -join '|') -and
  $activeLines.Count -eq 1 -and $prompt+1 -lt $handoff.Count -and
  ($handoff[($prompt+1)..($handoff.Count-1)] -join ' ') -match '^\s*>\s*\S'

$journalEntry = @()
$journalHash = $null
$journalComplete = $false
if ($journal -and (Test-Path -LiteralPath $journal -PathType Leaf)) {
  $entry = @(Get-Content -LiteralPath $journal -Encoding UTF8)
  $indices = @(for ($i=0; $i -lt $entry.Count; $i++) {
    if ($heading -and $entry[$i] -ceq $heading) { $i }
    if (!$heading -and $entry[$i].StartsWith('## ')) { $i; break }
  })
  if ($indices.Count -eq 1) {
    for ($i=$indices[0]; $i -lt $entry.Count -and ($i -eq $indices[0] -or !$entry[$i].StartsWith('## ')); $i++) {
      $journalEntry += $entry[$i]
    }
    $journalBody = $journalEntry -join [char]10
    $journalHash = Get-TextHash $journalBody
    if ($journalEntry[0] -match '^## \[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}) — [^\]]+\]$' -and $updated.Count -eq 1) {
      $journalComplete = [string]::CompareOrdinal($Matches[1],$updated[0].Substring(11)) -ge 0
      foreach ($label in @('Сделано','Дальше','Файлы','Статус')) {
        $journalComplete = $journalComplete -and $journalBody -match ('(?m)^\s*(?:[-*] |### )?(?:\*\*)?' + $label + '(?:\*\*)?:?(?:\*\*)?(?:[ \t]+\S.*|[ \t]*\r?\n[ \t]*[-*] \S.*)$')
      }
    }
  }
}

$gitState = 'not_applicable'
$git = @()
$head = $gitHash = $handoffCommitted = $pushMatches = $null
$remotes = @()
$pushRef = $pushHead = $null
$gitTaskStatus = $null
$dir = Get-Item -LiteralPath $projectRoot
while ($dir -and !(Test-Path -LiteralPath (Join-Path $dir.FullName '.git'))) { $dir = $dir.Parent }
if ($dir) {
  $gitState = 'unavailable'
  if (Get-Command git -ErrorAction SilentlyContinue) {
    $repo = $dir.FullName.Replace('\','/')
    $gitArgs = @('--no-optional-locks', '--literal-pathspecs', '-C', $repo, '-c', ('safe.directory=' + $repo))
    $git = @(git @gitArgs status --porcelain=v1 --branch --untracked-files=normal 2>$null)
    if ($LASTEXITCODE -eq 0) {
      $head = git @gitArgs rev-parse --verify HEAD 2>$null
      if ($LASTEXITCODE -eq 0) {
        $gitState = 'repository'
        $relativeHandoff = [IO.Path]::GetRelativePath($dir.FullName,$handoffPath).Replace('\','/')
        $trackedHandoff = @(git @gitArgs ls-files --error-unmatch -- $relativeHandoff 2>$null)
        $tracked = $LASTEXITCODE -eq 0
        $handoffChanges = @(git @gitArgs status --porcelain=v1 -- $relativeHandoff 2>$null)
        $handoffCommitted = $LASTEXITCODE -eq 0 -and $tracked -and !$handoffChanges.Count
        if ($taskPaths.Count) {
          $repoTaskPaths = @($taskPaths | ForEach-Object {
            [IO.Path]::GetRelativePath($dir.FullName,(Join-Path $projectRoot $_)).Replace('\','/')
          })
          $taskChanges = @(git @gitArgs status --porcelain=v1 --untracked-files=all --ignored=matching -- @repoTaskPaths 2>$null)
          if ($LASTEXITCODE -eq 0) { $gitTaskStatus = @($taskChanges | Select-Object -First 12) }
        }
        $remotes = @(git @gitArgs remote 2>$null)
        if ($LASTEXITCODE -ne 0) { $gitState = 'unavailable' }
        if ($remotes.Count) {
          $pushRef = git @gitArgs rev-parse --symbolic-full-name '@{push}' 2>$null
          if (!$pushRef) {
            $branch = git @gitArgs symbolic-ref --quiet --short HEAD 2>$null
            if ($LASTEXITCODE -eq 0) {
              $target = git @gitArgs config --get "branch.$branch.pushRemote" 2>$null
              if (!$target) { $target = git @gitArgs config --get remote.pushDefault 2>$null }
              if (!$target) { $target = git @gitArgs config --get "branch.$branch.remote" 2>$null }
              if (!$target -and $remotes.Count -eq 1) { $target = $remotes[0] }
              if ($target -cin $remotes) { $pushRef = "refs/remotes/$target/$branch" }
            }
          }
          if ($pushRef) {
            $pushHead = git @gitArgs rev-parse --verify --quiet $pushRef 2>$null
            if ($LASTEXITCODE -eq 0) {
              git @gitArgs merge-base --is-ancestor HEAD $pushHead 2>$null
              $pushMatches = $LASTEXITCODE -eq 0
            }
          }
        }
        $gitHash = Get-TextHash (ConvertTo-Json -Compress -InputObject @($git,$remotes,$pushRef,$pushHead))
      }
    }
  }
}

$evidence = ''
$evidenceName = $null
$evidenceKind = 'none'
if ($activeLines.Count -eq 1) {
  $line = $activeLines[0]
  $parent = [IO.Path]::GetDirectoryName($handoffPath)
  $base = $projectRoot.TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar
  foreach ($link in [regex]::Matches($line,'\]\((?:<([^>]+)>|([^\s)]+))\)')) {
    $raw = if ($link.Groups[1].Success) { $link.Groups[1].Value } else { $link.Groups[2].Value }
    if ($raw -match '^[a-z][a-z0-9+.-]+://|^[/\\]{2}') { continue }
    try { $full = [IO.Path]::GetFullPath($raw,$parent) } catch { continue }
    if (!$full.StartsWith($base,[StringComparison]::OrdinalIgnoreCase) -or
        [IO.Path]::GetExtension($full) -notin @('.md','.txt') -or $full -eq $handoffPath) { continue }
    $file = Get-Item -LiteralPath $full -ErrorAction SilentlyContinue
    if (!$file -or $file.PSIsContainer -or $file.Length -gt 5000 -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint)) { continue }
    $body = Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
    if ($body -and $body.Trim().Length -ge 16) {
      $evidence = $body
      $evidenceName = $file.Name
      $evidenceKind = 'linked_file'
      break
    }
  }
  if (!$evidence) {
    $first = $line.Substring(0,[Math]::Min(1200,$line.Length))
    $plain = [regex]::Replace($first,'\[[^]]+\]\([^)]*\)','').Trim()
    if ($plain.Length -ge 16) { $evidence = $first; $evidenceKind = 'handoff_line' }
  }
}

[pscustomobject]@{
  handoffUpdated = $updated | Select-Object -First 1
  handoffHash = Get-TextHash $handoffText
  handoffComplete = $handoffComplete
  matches = $paths
  matchCount = $activeLines.Count
  journal = @($journalEntry | Select-Object -First 12 | ForEach-Object { $_.Substring(0,[Math]::Min(450,$_.Length)) })
  journalHash = $journalHash
  journalComplete = $journalComplete
  gitState = $gitState
  gitAvailable = $gitState -eq 'repository'
  head = $head
  gitHash = $gitHash
  gitTaskStatus = $gitTaskStatus
  handoffCommitted = $handoffCommitted
  remotes = $remotes
  pushRef = $pushRef
  pushMatches = $pushMatches
  changeCount = [Math]::Max(0,$git.Count-1)
  gitStatus = @($git | Select-Object -Skip 1 -First 12)
  evidence = $evidence
  evidenceKind = $evidenceKind
  evidenceName = $evidenceName
} | ConvertTo-Json -Compress -Depth 4
`;
    const result = await tools.exec_command({cmd:"$ErrorActionPreference='Stop'\n" + command, workdir:input.cwd, max_output_tokens:8500});
    if (result.exit_code !== 0 || result.original_token_count > 8500) {
      throw Error("Cannot read the transfer preparation snapshot without truncation");
    }
    return JSON.parse(result.output.trim());
  }
  async function registry(projectId) {
    const command = "$id=" + quoted(projectId) + "\n" +
      "$registryPath=Join-Path ([Environment]::GetFolderPath('UserProfile')) '.codex/.codex-global-state.json'\n" +
      "if(-not (Test-Path -LiteralPath $registryPath -PathType Leaf)){return}\n" +
      "$state=Get-Content -LiteralPath $registryPath -Raw -Encoding UTF8 | ConvertFrom-Json -AsHashtable\n" +
      "$record=$state['local-projects'][$id]\n" +
      "if($record.id -ne $id -or -not $record.rootPaths -or -not (Test-Path -LiteralPath $record.rootPaths[0] -PathType Container)){return}\n" +
      "[pscustomobject]@{projectId=$record.id;projectKind='local';hostId='local';path=$record.rootPaths[0]} | ConvertTo-Json -Compress";
    const result = await tools.exec_command({cmd:"$ErrorActionPreference='Stop'\n" + command, max_output_tokens:500});
    if (result.exit_code !== 0) throw Error("Cannot read the local Codex project registration");
    return result.output.trim() ? JSON.parse(result.output.trim()) : null;
  }
  const workflow = transferBlocks({
    local,
    registry,
    now: () => Date.now(),
    previous: pre => load(stateKey(pre.oldId)),
    remember: state => store(stateKey(state.oldId),state),
    call: async (name,args) => {
      const fn = tools["mcp__codex_app__" + name];
      if (typeof fn !== "function") throw Error("Codex tool unavailable: " + name);
      const result = await fn(args);
      if (result.isError) throw Error("Codex tool returned an error: " + name);
      const content = result.structuredContent ??
        JSON.parse(result.content?.find(item => item.type === "text")?.text ?? "null");
      if (!content || typeof content !== "object") throw Error("Codex returned no usable result: " + name);
      return content;
    }
  });
  const compact = result => {
    const {evidence, prompt, local:localSnapshot, task, point, continuationTask, stopInput, ownerCommand, ...summary} = result;
    return summary;
  };
  return {
    prepare: async input => {
      if (!input.oldId || !input.hostId || !input.cwd || !input.handoffPath || !input.activePrefix) {
        throw Error("Current chat, project and HANDOFF branch must be identified");
      }
      const pre = await workflow.prepare(input);
      store("transfer-preflight:" + input.oldId,pre);
      const {evidence, stopInput, ownerCommand, ...summary} = pre;
      return summary;
    },
    transfer: async (oldId,plan) => compact(await workflow.transfer(load("transfer-preflight:" + oldId) ?? {},plan)),
    resume: async oldId => {
      const state = load(stateKey(oldId));
      if (!state?.threadId) return {status:"check_existing_creation",title:state?.title};
      return compact(await workflow.finish(state));
    }
  };
}

return liveTransfer;
})()
