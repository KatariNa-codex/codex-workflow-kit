# -*- coding: utf-8 -*-
"""Архив разговоров из записей сессий Codex.

Сохраняет объяснения и решения из разговоров в локальных текстовых файлах.

Что берётся: то, что набрал человек, и то, что ответил агент словами. Что НЕ берётся: вызовы
инструментов и их вывод, размышления модели, служебные вставки, помощники (субагенты).
Секреты вырезаются по маскам (ключи, токены, «пароль: …») — но маска не гарантия:
архив лежит только на этой машине, в git его класть не надо.

Сессия попадает в архив, когда её запись не менялась полчаса (то есть сессия закончена или стоит),
и переписывается, если запись с тех пор выросла. Удалённую запись архив переживает.

Запуск:
  python session_archive.py                 # забрать всё новое
  python session_archive.py --max 5         # не больше пяти сессий за раз (так зовёт хук конца хода)
  python session_archive.py --quiet         # молчать, если всё в порядке
  python session_archive.py --dry           # только посчитать
Искать: python memory_search.py "<слова>" --sessions
"""
import datetime
import glob
import json
import os
import re
import sys
import time

IDLE_SECONDS = 30 * 60
MAX_MESSAGE_CHARS = 6000

MASKS = [
    (r"sk-[A-Za-z0-9_\-]{20,}", "sk-…"),
    (r"\b(?:ghp|gho|ghu|ghs|github_pat)_[A-Za-z0-9_]{20,}", "gh…"),
    (r"\bxox[abprs]-[A-Za-z0-9\-]{10,}", "xox…"),
    (r"\bAKIA[0-9A-Z]{16}\b", "AKIA…"),
    (r"\b\d{8,10}:[A-Za-z0-9_\-]{35}\b", "<токен бота>"),
    (r"\beyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}", "<jwt>"),
    (r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----", "<закрытый ключ>"),
    (r"(?i)\b(password|passwd|пароль|token|токен|secret|секрет|api[_\-]?key|apikey|bearer)(\s*[:=]\s*)([^\s\"'`,;]{6,})",
     lambda m: m.group(1) + m.group(2) + "<скрыто>"),
    # через пробел — только то, что похоже на ключ (буквы вперемешку с цифрами), иначе вырежется обычная фраза
    (r"(?i)\b(password|passwd|пароль|token|токен|secret|секрет|bearer)(\s+)((?=\S*\d)(?=\S*[A-Za-z])[A-Za-z0-9_\-+/=.]{8,})",
     lambda m: m.group(1) + m.group(2) + "<скрыто>"),
    (r"\b[0-9a-fA-F]{40,}\b", "<длинный ключ>"),
]
NOISE = re.compile(r"(?s)<system-reminder>.*?</system-reminder>|<local-command-[a-z]+>.*?</local-command-[a-z]+>"
                   r"|<command-(?:name|message|args)>.*?</command-(?:name|message|args)>|<task-notification>.*?</task-notification>")


def _places():
    """Resolve archive inputs from the profile that owns this installed script."""
    home = os.path.expanduser("~")
    profile = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    cfg = os.path.join(profile, "memory-kit.json")
    if os.path.isfile(cfg):
        with open(cfg, encoding="utf-8") as fh:
            data = json.load(fh)
        archive = data.get("sessions_dir") or os.path.join(os.path.dirname(data["central"]), "sessions")
    else:
        profile = os.environ.get("CODEX_HOME") or os.path.join(home, ".codex")
        archive = os.path.join(home, ".agent-memory", "sessions")
    return os.path.join(profile, "sessions"), archive


CODEX_SOURCE, ARCHIVE = _places()
CODEX_SKIP = ("# AGENTS.md instructions", "<environment_context", "<recommended_plugins", "<external_codex_apps",
              "<realtime_delegation", "<image name=", "</image>", "<bash-stdout", "<in-app-browser-context",
              "<user_instructions", "<turn_aborted")


def mask(text):
    for pattern, repl in MASKS:
        text = re.sub(pattern, repl, text, flags=re.S)
    return text


def clean(text):
    text = NOISE.sub("", text).strip()
    if not text or text.startswith(("Caveat: The messages below", "[Request interrupted")):
        return ""
    if len(text) > MAX_MESSAGE_CHARS:
        text = text[:MAX_MESSAGE_CHARS] + "\n[…обрезано]"
    return mask(text)


def stamp(iso):
    try:
        return datetime.datetime.fromisoformat(iso.replace("Z", "+00:00")).astimezone().strftime("%Y-%m-%d %H:%M")
    except Exception:
        return "????-??-?? ??:??"


def codex_words(payload):
    """Текст сообщения из записи Codex без служебных вставок и приложенных картинок."""
    parts = []
    for b in payload.get("content") or []:
        text = (b.get("text") or "") if isinstance(b, dict) else ""
        if not text.strip() or text.lstrip().startswith(CODEX_SKIP):
            continue
        if "## My request for Codex:" in text:          # перед просьбой идёт список приложенных файлов
            text = text.split("## My request for Codex:", 1)[1]
        parts.append(text)
    return clean("\n\n".join(parts))


def convert_codex(path):
    """Запись сессии Codex -> (текст архива, дата начала, папка проекта). Не разговор с человеком -> ('', '', '')."""
    blocks, cwd, first, sid = [], "", "", ""
    with open(path, encoding="utf-8", errors="replace") as fh:
        for ln in fh:
            try:
                e = json.loads(ln)
            except ValueError:
                continue
            p = e.get("payload") or {}
            if e.get("type") == "session_meta":
                if p.get("source") == "exec" or not isinstance(p.get("source"), str):
                    return "", "", ""
                cwd, sid = p.get("cwd") or "", p.get("id") or ""
                continue
            if e.get("type") != "response_item" or p.get("type") != "message" or p.get("role") not in ("user", "assistant"):
                continue
            text = codex_words(p)
            if not text:
                continue
            when = stamp(e.get("timestamp") or "")
            first = first or when
            who = "человек" if p["role"] == "user" else "агент"
            if blocks and blocks[-1][0] == who == "агент":
                blocks[-1][2].append(text)
            else:
                blocks.append([who, when, [text]])
    if not sid or not any(b[0] == "человек" for b in blocks):
        return "", "", ""
    out = ["# Сессия %s" % sid, "", "Проект: %s" % (cwd or "?"), "Начало: %s" % first, "Агент: Codex", ""]
    for who, when, texts in blocks:
        out += ["## [%s] %s" % (when, who), "", "\n\n".join(texts), ""]
    return "\n".join(out), first, cwd


def sweep_codex(limit=None, dry=False):
    """То же для Codex. Что уже разобрано, помнит файл .codex.json в архиве: папка проекта у Codex
    написана внутри записи, и без этого файла каждую пришлось бы открывать заново. -> (взято, пропущено)."""
    done = empty = 0
    now = time.time()
    index_path = os.path.join(ARCHIVE, ".codex.json")
    try:
        with open(index_path, encoding="utf-8") as fh:
            index = json.load(fh)
    except Exception:
        index = {}
    changed = False
    files = sorted(glob.glob(os.path.join(CODEX_SOURCE, "*", "*", "*", "rollout-*.jsonl")), key=os.path.getmtime)
    for path in files:
        mtime = os.path.getmtime(path)
        sid = os.path.splitext(os.path.basename(path))[0][-36:]
        if now - mtime < IDLE_SECONDS or (index.get(sid) or {}).get("mtime", 0) >= mtime:
            continue
        if limit is not None and done >= limit:
            break
        if dry:
            done += 1
            continue
        text, first, cwd = convert_codex(path)
        old = (index.get(sid) or {}).get("file")
        index[sid] = {"mtime": mtime}
        changed = True
        if not text:
            empty += 1
            continue
        slug = re.sub(r"[^A-Za-z0-9]", "-", cwd) or "codex"
        # у Codex начало id — время: у сессий, начатых в одну минуту, оно общее, поэтому берём хвост
        dst = os.path.join(ARCHIVE, slug, "%s_%s.md" % (first[:10], sid[-8:]))
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        if old and old != dst and os.path.exists(old):
            os.remove(old)
        tmp = "%s.%d.tmp" % (dst, os.getpid())
        with open(tmp, "wb") as fh:
            fh.write(text.encode("utf-8"))
        os.replace(tmp, dst)
        index[sid]["file"] = dst
        done += 1
    if changed:
        os.makedirs(ARCHIVE, exist_ok=True)
        tmp = "%s.%d.tmp" % (index_path, os.getpid())
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(index, fh)
        os.replace(tmp, index_path)
    return done, empty


def main(argv):
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    quiet, dry = "--quiet" in argv, "--dry" in argv
    limit = int(argv[argv.index("--max") + 1]) if "--max" in argv else None
    done = empty = 0
    if os.path.isdir(CODEX_SOURCE):
        done, empty = sweep_codex(limit, dry)
    if not quiet or dry:
        print("архив сессий %s: %s %d, пустых %d" % (ARCHIVE.replace(os.sep, "/"),
                                                     "взял бы" if dry else "взято", done, empty))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
