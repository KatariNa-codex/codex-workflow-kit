/**
 * Общие функции хуков memory-kit: чтение настроек и адреса папок памяти.
 * Настройки лежат рядом с папкой hooks: <папка агента>/memory-kit.json
 * (их пишет install.py). Нет файла настроек — хуки молча ничего не делают.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');

function loadConfig() {
  try {
    const p = path.join(__dirname, '..', 'memory-kit.json');
    return JSON.parse(fs.readFileSync(p, 'utf-8'));
  } catch (e) {
    return null;
  }
}

/** Имя папки памяти для пути — всё, кроме букв и цифр, в дефис. */
function slug(dir) {
  return path.resolve(dir).replace(/[^A-Za-z0-9]/g, '-');
}

/** Папка памяти проекта для рабочей папки cwd. Регистр буквы диска на Windows гуляет — ищем без учёта регистра. */
function projectMemoryDir(cfg, cwd) {
  cwd = canonicalProject(cfg, projectDir(cfg, cwd));
  const want = slug(cwd).toLowerCase();
  try {
    for (const name of fs.readdirSync(cfg.projects_dir)) {
      if (name.toLowerCase() === want) return path.join(cfg.projects_dir, name, 'memory');
    }
  } catch (e) { /* папки ещё нет */ }
  return path.join(cfg.projects_dir, slug(cwd), 'memory');
}

/**
 * Свой адрес журнала из ключа journal_path: строка действует на все проекты,
 * словарь {"имя папки": "адрес"} только на названные. Нет адреса — пустая строка.
 */
function journalOverride(cfg, project) {
  project = canonicalProject(cfg, project);
  const j = cfg.journal_path;
  if (!j) return '';
  return typeof j === 'string' ? j : String(j[path.basename(project)] || '');
}

/**
 * Файл журнала проекта. По умолчанию <central>/projects/<Проект>.md. Свой адрес: journalOverride,
 * {project} заменяется именем проекта, относительный путь считается от папки проекта.
 */
function journalFile(cfg, project) {
  project = canonicalProject(cfg, project);
  const name = path.basename(project);
  const custom = journalOverride(cfg, project);
  if (!custom) return path.join(cfg.central, 'projects', name + '.md');
  const p = custom.split('{project}').join(name).replace(/^~(?=[\\/]|$)/, os.homedir());
  return path.resolve(project, p);
}

/** Explicit aliases only; one hop, absolute paths, no ambiguous duplicate keys or chains.
 * Worktree identity reads Git metadata only. No Git process, network or file mutation. */
function canonicalProject(cfg, project) {
  let result = path.resolve(project);
  try {
    const gitfile = path.join(result, '.git');
    if (fs.statSync(gitfile).isFile()) {
      const match = /^gitdir:\s*(.+)\s*$/i.exec(fs.readFileSync(gitfile, 'utf8').trim());
      if (match) {
        const admin = path.resolve(result, match[1]);
        const common = path.resolve(admin, fs.readFileSync(path.join(admin, 'commondir'), 'utf8').trim());
        if (path.basename(common).toLowerCase() === '.git' && fs.statSync(common).isDirectory())
          result = path.dirname(common);
      }
    }
  } catch (_) { /* missing/malformed metadata: retain this project */ }
  const aliases = cfg && cfg.project_aliases;
  if (!aliases || typeof aliases !== 'object' || Array.isArray(aliases)) return result;
  const rows = Object.entries(aliases);
  const matches = rows.filter(([from]) => path.isAbsolute(from) && samePath(from, result));
  if (matches.length !== 1) return result;
  const target = matches[0][1];
  if (typeof target !== 'string' || !path.isAbsolute(target)) return result;
  if (rows.some(([from]) => path.isAbsolute(from) && samePath(from, target))) return result;
  return path.resolve(target);
}

function samePath(a, b) {
  return path.resolve(a).toLowerCase() === path.resolve(b).toLowerCase();
}

/** Путь b лежит внутри a (или совпадает). */
function inside(a, b) {
  const rel = path.relative(path.resolve(a), path.resolve(b));
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

/**
 * Папка проекта для рабочей папки cwd. Агента часто запускают из подпапки (src, docs):
 * поднимаемся до ближайшей папки с HANDOFF.md. Выше корня проектов не идём, а сам корень
 * проектом считаем, только если запущены прямо в нём: иначе его записка подменила бы записку проекта.
 * Ничего не нашли — проектом остаётся сама cwd.
 */
function projectDir(cfg, cwd) {
  const start = path.resolve(cwd);
  const root = cfg && cfg.root ? path.resolve(cfg.root) : null;
  let dir = start;
  for (let i = 0; i < 12; i++) {
    if (root && samePath(dir, root) && !samePath(dir, start)) break;
    if (fs.existsSync(path.join(dir, 'HANDOFF.md'))) return dir;
    const up = path.dirname(dir);
    if (up === dir) break;
    dir = up;
  }
  return start;
}

/** Папка похожа на проект: в ней есть записка либо она лежит под корнем проектов. */
function isProject(cfg, dir) {
  if (fs.existsSync(path.join(dir, 'HANDOFF.md'))) return true;
  return !!(cfg && cfg.root) && inside(cfg.root, dir) && !samePath(cfg.root, dir);
}

// Метка «хук старта сработал». Ту же строку ищет агент по разделу правил (install.py, HOOKCHECK).
const HOOKS_ALIVE = 'memory-kit: хуки работают';

// Файлы набора в папке агента. Тот же список — в install.py и scripts/kit_check.py.
const KIT_FILES = {
  hooks: ['kit.js', 'session-start-context.js', 'session-summary-check.js', 'memory-index-hook.py',
    'memory-recall-hook.py'],
  scripts: ['memory_index.py', 'memory_search.py', 'session_archive.py', 'project_index.py', 'kit_check.py',
    'memory_report.py', 'memory_upkeep.py',
    'find-zombies.ps1'],
};

/**
 * Чем установленные файлы отличаются от папки набора (ключ kit_dir в настройках).
 * Возвращает { behind: [...], edited: [...] }: набор ушёл вперёд либо файл поправили на месте.
 * Различаем по времени правки; перевод строк не в счёт. Нет kit_dir или папки — пусто.
 */
function driftFromKit(cfg) {
  const out = { behind: [], edited: [] };
  if (!cfg || !cfg.kit_dir) return out;
  const text = p => fs.readFileSync(p, 'utf-8').split('\r\n').join('\n');
  for (const sub of Object.keys(KIT_FILES)) {
    for (const name of KIT_FILES[sub]) {
      const mine = path.join(__dirname, '..', sub, name);
      const theirs = path.join(cfg.kit_dir, sub, name);
      try {
        if (!fs.existsSync(theirs)) continue;
        if (!fs.existsSync(mine)) { out.behind.push(sub + '/' + name); continue; }
        if (text(mine) === text(theirs)) continue;
        (fs.statSync(theirs).mtimeMs >= fs.statSync(mine).mtimeMs ? out.behind : out.edited).push(sub + '/' + name);
      } catch (e) { /* не смогли прочитать — молчим */ }
    }
  }
  return out;
}

module.exports = { canonicalProject, journalFile, journalOverride, loadConfig, slug, projectMemoryDir, samePath, inside, projectDir, isProject, driftFromKit,
  KIT_FILES, HOOKS_ALIVE };
