# Changes

Based on [reels-console at b5c44a9](https://github.com/GuruDevvv/my-claude-skills/tree/b5c44a9b7ec4a2620d7c7824cc4df22b940ae6dd/mine/reels-console). The MIT attribution is in LICENSE.

- Whisper accepts optional context and transcriptions are reused only for matching audio and settings.
- FFmpeg can retry loudness normalization from the original audio with peak compression and remeasure the encoded result.
- OpenCV 4.x provides frontal-face anchoring. Horizontal input is cropped to portrait around the chosen anchor before zooming.
- The local test suite checks cache invalidation, the loudness retry, and face detector selection and fallback.
