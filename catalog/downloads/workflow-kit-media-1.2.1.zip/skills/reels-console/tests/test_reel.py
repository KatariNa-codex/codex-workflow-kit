import builtins
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from scripts import reel

class CandidateTests(unittest.TestCase):
    def test_transcription_cache_depends_on_model_context_and_audio(self):
        with tempfile.TemporaryDirectory() as directory:
            wav = Path(directory, "audio.wav")
            wav.write_bytes(b"first recording")
            cache = Path(directory, "words.json")
            with patch.object(reel, "whisper_words", return_value=("Синий круг", [])) as asr:
                reel.transcribe(wav, "tiny", "ru", cache, check=False, prompt="Синий круг")
                reel.transcribe(wav, "tiny", "ru", cache, check=False, prompt="Синий круг")
                self.assertEqual(asr.call_count, 1)
                reel.transcribe(wav, "base", "ru", cache, check=False, prompt="Синий круг")
                reel.transcribe(wav, "base", "ru", cache, check=False, prompt="Список")
                wav.write_bytes(b"second recording")
                reel.transcribe(wav, "base", "ru", cache, check=False, prompt="Список")
                self.assertEqual(asr.call_count, 4)
                self.assertEqual(asr.call_args.kwargs["prompt"], "Список")

    def test_face_detection_never_imports_insightface(self):
        frame = SimpleNamespace(shape=(720, 540))
        cascade = SimpleNamespace(empty=lambda: False, detectMultiScale=lambda *args, **kw: [(30, 50, 100, 100)])
        cv = SimpleNamespace(resize=lambda *args: frame, cvtColor=lambda *args: frame,
                             CascadeClassifier=lambda path: cascade, COLOR_BGR2GRAY=1,
                             data=SimpleNamespace(haarcascades="fixtures/"))
        ordinary_import = builtins.__import__
        attempted = []
        def only_opencv(name, *args, **kwargs):
            if name.startswith("insightface"):
                attempted.append(name)
                raise ImportError(name)
            if name == "cv2":
                return cv
            return ordinary_import(name, *args, **kwargs)
        with patch("builtins.__import__", side_effect=only_opencv):
            self.assertEqual(reel.find_face(frame), [30, 50, 130, 150])
        self.assertEqual(attempted, [])

    def test_master_retries_quiet_speech_from_original(self):
        with tempfile.TemporaryDirectory() as directory:
            out = Path(directory, "result.mp4")
            measurement = json.dumps(dict(input_i="-25.4", input_tp="-4.0",
                input_lra="3", input_thresh="-36", target_offset="0"))
            commands = []
            def render(args):
                commands.append(args)
                Path(args[-1]).write_bytes(b"rendered")
            with patch.object(reel.subprocess, "run", return_value=SimpleNamespace(stderr=measurement)), \
                 patch.object(reel, "run", side_effect=render), \
                 patch.object(reel, "loudness", side_effect=[(-15.8, -1.5), (-14.0, -1.5)]):
                self.assertEqual(reel.master("original.mp4", out), (-25.4, -14.0, -1.5, True))
            self.assertEqual(len(commands), 2)
            self.assertIn("original.mp4", commands[1])
            self.assertIn("acompressor", commands[1][commands[1].index("-af")+1])

    def test_missing_cascade_is_a_clean_fallback(self):
        frame = SimpleNamespace(shape=(720, 540))
        with patch.dict("sys.modules", {"cv2": SimpleNamespace()}), patch.object(reel, "_FACE_CASCADE", None):
            self.assertIsNone(reel.find_face(frame))

if __name__ == "__main__":
    unittest.main()

