# Changes

Based on [video-by-code at b5c44a9](https://github.com/GuruDevvv/my-claude-skills/tree/b5c44a9b7ec4a2620d7c7824cc4df22b940ae6dd/mine/video-by-code). The upstream MIT notice is in LICENSE.

The Canvas example uses AGENTS.md for Codex. Dependency guidance keeps the trial local. The original demo video is linked from README.md.
