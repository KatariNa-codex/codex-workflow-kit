"""Append global advisor hooks; never write trust or other configuration."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
from datetime import datetime

EVENTS = ('UserPromptSubmit', 'PreToolUse', 'PostToolUse', 'PreCompact', 'Stop')

def install(target, apply=False):
    target = Path(target).resolve()
    source = Path(__file__).with_name('advisor.cjs')
    hookfile = target / 'hooks.json'
    original = hookfile.read_bytes() if hookfile.exists() else b'{"hooks":{}}'
    doc = json.loads(original.decode('utf-8-sig'))
    hooks = doc.setdefault('hooks', {})
    if not isinstance(hooks, dict):
        raise ValueError('hooks must be an object')
    destination = target / 'hooks' / 'session-advisor.cjs'
    command = 'node "' + destination.as_posix() + '"'
    for event in EVENTS:
        groups = hooks.setdefault(event, [])
        if not isinstance(groups, list):
            raise ValueError('event must be an array')
        matches = [h for g in groups for h in g.get('hooks', [])
                   if 'session-advisor.cjs' in h.get('command', '')]
        if matches:
            if len(matches) != 1 or matches[0].get('command') != command:
                raise ValueError('conflicting session-advisor registration')
            continue
        groups.append({'hooks': [{'type': 'command', 'command': command, 'timeout': 5}]})
    changed = json.loads(original.decode('utf-8-sig')) != doc
    script_changed = not destination.exists() or destination.read_bytes() != source.read_bytes()
    receipt = {'events': list(EVENTS), 'target': str(target),
               'registration_changed': changed, 'script_changed': script_changed,
               'applied': apply, 'trust': 'requires user review in /hooks; never modified by installer'}
    if not apply or not (changed or script_changed):
        return receipt
    backup = target / 'backups' / 'session-advisor' / datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    backup.mkdir(parents=True)
    if hookfile.exists():
        shutil.copy2(hookfile, backup / 'hooks.json')
    if destination.exists():
        shutil.copy2(destination, backup / 'session-advisor.cjs')
    destination.parent.mkdir(parents=True, exist_ok=True)
    if script_changed:
        temp = destination.with_suffix('.tmp')
        temp.write_bytes(source.read_bytes())
        os.replace(temp, destination)
    if changed:
        # Refuse to overwrite an edit made since the initial read.
        if hookfile.exists() and hookfile.read_bytes() != original:
            raise RuntimeError('hooks.json changed concurrently; registration not written')
        temp = hookfile.with_suffix('.session-advisor.tmp')
        temp.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        os.replace(temp, hookfile)
    receipt['backup'] = str(backup)
    receipt['script_sha256'] = hashlib.sha256(destination.read_bytes()).hexdigest()
    (backup / 'receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    return receipt

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--target', default=str(Path.home() / '.codex'))
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    print(json.dumps(install(args.target, args.apply), ensure_ascii=False, indent=2))
