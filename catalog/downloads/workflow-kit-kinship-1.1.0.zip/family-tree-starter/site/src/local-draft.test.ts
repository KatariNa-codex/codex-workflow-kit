import { describe, expect, it } from 'vitest';
import { draftKey, parseDraft, type LocalDraft } from './local-draft';
import { cardHtml } from './card';
import type { Person, SiteData } from './types';

const person: Person = {
  id: 'demo-person',
  sex: 'U',
  name: { full: 'Учебное Имя', short: 'Учебное Имя', maiden: null, married: null },
  birthYear: 1904, deathYear: null, birthQualifier: 'exact', deathQualifier: null,
  names: [], relation: null, ahnentafel: null, generation: 0,
  events: [{ type: 'birth', date: '1904', year: 1904, qualifier: 'exact', claims: [
    { source: 'demo-record', confidence: 'conflict', note: 'Учебный источник указывает другой год' },
  ] }],
};

function data(publicBuild?: boolean): SiteData {
  return {
    meta: { root: person.id, title: 'Учебное древо', builtAt: '', publicBuild },
    people: [person],
    sources: [{ id: 'demo-record', kind: 'document', title: 'Учебная запись', reliability: 'original' }],
    places: [],
  };
}

const draft: LocalDraft = { given: 'Другое', surname: 'Имя', birth: '1906', note: '<только черновик>' };

describe('карточка и локальные черновики', () => {
  it('показывает источник расхождения рядом с событием', () => {
    const event = cardHtml(person, data()).match(/<section class="ev[^]*?<\/section>/)?.[0];
    expect(event).toContain('pill conflict');
    expect(event).toContain('Источник: Учебная запись');
  });
  it('разделяет ключи древа, расположения сайта и карточки', () => {
    const keys = [draftKey('/one/', 'root', 'person'), draftKey('/two/', 'root', 'person'),
      draftKey('/one/', 'other', 'person'), draftKey('/one/', 'root', 'other')];
    expect(new Set(keys).size).toBe(4);
  });
  it('игнорирует повреждённые или неподходящие записи браузера', () => {
    expect(parseDraft('{')).toBeNull();
    expect(parseDraft('{"given":42}')).toBeNull();
    expect(parseDraft(JSON.stringify(draft))).toEqual(draft);
  });
  it('показывает черновик отдельно от факта и экранирует текст', () => {
    const html = cardHtml(person, data(false), draft);
    expect(html).toContain('Локальный черновик');
    expect(html).toContain('data-edit-person="demo-person"');
    expect(html).toContain('&lt;только черновик');
    expect(html).not.toContain('<только черновик>');
    expect(html).toContain('1904');
    expect(person.events?.[0].date).toBe('1904');
  });
  it('не показывает редактор и черновик при публичной сборке или неизвестном режиме', () => {
    for (const mode of [true, undefined]) {
      const html = cardHtml(person, data(mode), draft);
      expect(html).not.toContain('data-edit-person');
      expect(html).not.toContain('Локальный черновик');
    }
  });
});
