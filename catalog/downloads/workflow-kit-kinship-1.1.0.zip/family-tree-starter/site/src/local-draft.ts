export interface LocalDraft {
  given: string;
  surname: string;
  birth: string;
  note: string;
}

export function draftKey(sitePath: string, root: string, person: string): string {
  return 'family-tree-draft:' + JSON.stringify([sitePath, root, person]);
}

export function parseDraft(raw: string | null): LocalDraft | null {
  if (!raw) return null;
  try {
    const value: unknown = JSON.parse(raw);
    if (typeof value !== 'object' || !value || Array.isArray(value)) return null;
    const { given, surname, birth, note } = value as Record<string, unknown>;
    if (typeof given !== 'string' || typeof surname !== 'string' ||
        typeof birth !== 'string' || typeof note !== 'string') return null;
    return { given, surname, birth, note };
  } catch {
    return null;
  }
}

export function readDraft(key: string): LocalDraft | null {
  try {
    return parseDraft(window.localStorage.getItem(key));
  } catch {
    return null;
  }
}

export function writeDraft(key: string, draft: LocalDraft): boolean {
  try {
    window.localStorage.setItem(key, JSON.stringify(draft));
    return true;
  } catch {
    return false;
  }
}
