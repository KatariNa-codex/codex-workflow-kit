'use strict';
// Warn about the context reserve. This process never opens chats or blocks tools.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const EVENTS = new Set(['UserPromptSubmit', 'PreToolUse', 'PostToolUse', 'PreCompact', 'Stop']);
const EARLY = 0.75;
const PREPARE = 0.80;
const TRANSFER_REMINDER = 'В связи с большой контекстной нагрузкой, рекомендую перенос диалога в новый чат. Автоматический перенос выполняется по команде "переноси"';
const COMPACTION_NOTICE = 'Контекст этого чата был сжат.';
const SCAN_BATCH = 6;
const TRANSFER = /^(?:да[,\s]+)?(?:переноси(?:\s+(?:и закоммить|в новый чат))?|продолжай перенос)[.!\s]*$/iu;
const SCAN_RANGE = /(?:кадр\p{L}*|скан\p{L}*|разворот\p{L}*|страниц\p{L}*)\s*(?:с\s+)?(\d+)\s*(?:[-–—]|\sпо\s)\s*(\d+)/giu;

function transcriptTail(file, since = 0) {
  if (!file) return '';
  let descriptor;
  try {
    descriptor = fs.openSync(file, 'r');
    const size = fs.fstatSync(descriptor).size;
    const bytes = Buffer.alloc(Math.min(Math.max(0, size - since), 512 * 1024));
    const read = fs.readSync(descriptor, bytes, 0, bytes.length, size - bytes.length);
    return bytes.toString('utf8', 0, read);
  } catch {
    return '';
  } finally {
    if (descriptor !== undefined) fs.closeSync(descriptor);
  }
}

function isCompaction(entry) {
  return entry?.type === 'compacted' || entry?.payload?.type === 'context_compacted';
}

function metrics(file) {
  for (const line of transcriptTail(file).split('\n').reverse()) {
    let entry;
    try { entry = JSON.parse(line); } catch { continue; }
    if (isCompaction(entry)) return null;
    if (entry?.type !== 'event_msg' || entry.payload?.type !== 'token_count') continue;
    const info = entry.payload.info;
    if (!info) continue;
    const used = info.last_token_usage?.input_tokens;
    const window = info.model_context_window;
    if (Number.isFinite(used) && Number.isFinite(window) && used >= 0 && window > 0 && used <= window) {
      return { used, window };
    }
    return null;
  }
  return null;
}

function scanBatch(input) {
  if (input.hook_event_name === 'UserPromptSubmit') {
    return Array.from(String(input.prompt ?? '').matchAll(SCAN_RANGE))
      .some(([, first, last]) => Number(last) - Number(first) + 1 >= SCAN_BATCH);
  }
  const args = input.tool_input;
  if (!args || typeof args !== 'object') return false;
  if (['images', 'image_paths', 'imagePaths', 'scans'].some(key =>
    Array.isArray(args[key]) && args[key].length >= SCAN_BATCH)) return true;
  const code = typeof args.code === 'string' ? args.code.slice(0, 24000) : '';
  return (code.match(/\b(?:view_image|emitImage|screenshot)\s*\(/gu) ?? []).length >= SCAN_BATCH;
}

function warn(event, message) {
  return {
    systemMessage: message,
    hookSpecificOutput: { hookEventName: event, additionalContext: message }
  };
}

function assess(input, state) {
  const event = input.hook_event_name;
  // Preserve the recommendation across compaction and upgrades from an earlier advisor.
  if (state.prepareWarned) state.transferReminderActive = true;
  if (event === 'UserPromptSubmit') {
    // This legacy hint only labels reserve diagnostics. Codex interprets transfer requests.
    const prompt = String(input.prompt ?? '').trim();
    state.transferCommand = TRANSFER.test(prompt);
    state.skipTransferNotice = state.transferCommand || /^стоп[.!…\s]*$/iu.test(prompt);
    state.batchWarned = false;
  }

  if (event === 'PreCompact') {
    const inTransfer = state.transferCommand;
    const automatic = input.trigger === 'auto';
    const message = inTransfer && automatic
      ? 'Автосжатие при переносе: резерва не хватило. Сверь сохранённые решения и уже выполненные шаги СТОП перед продолжением.'
      : 'Зафиксировано сжатие контекста. Сверь сохранённые решения и ближайшую безопасную точку.';
    if (inTransfer && automatic) state.transferCompactions = (state.transferCompactions ?? 0) + 1;
    state.afterCompact = message;
    try {
      state.compactionOffset = fs.statSync(input.transcript_path).size;
    } catch { delete state.compactionOffset; }
    state.earlyWarned = state.prepareWarned = state.batchWarned = false;
    return { systemMessage: message };
  }

  const last = metrics(input.transcript_path);
  const pressure = last ? last.used / last.window : null;
  if (pressure !== null && pressure >= PREPARE) state.transferReminderActive = true;

  if (Number.isSafeInteger(state.compactionOffset) && transcriptTail(input.transcript_path, state.compactionOffset)
    .split('\n').some(line => {
      try { return isCompaction(JSON.parse(line)); } catch { return false; }
    })) {
    state.compactionNoticePending = true;
    delete state.compactionOffset;
  }

  // Stop runs after the reply. Record any late threshold crossing for the next turn.
  if (event === 'Stop') return {};

  const messages = [];
  if (state.afterCompact) {
    messages.push(state.afterCompact + ' Обнови Оценка_контекста.md, если этого требуют правила проекта.');
    delete state.afterCompact;
  }
  if (pressure !== null && pressure >= PREPARE && !state.prepareWarned) {
    const next = state.transferCommand
      ? 'Проверь, что подготовка к СТОП уже началась, и продолжай с ближайшего незавершённого шага.'
      : 'На ближайшей безопасной границе начни подготовку к СТОП.';
    messages.push('Последний измеренный вход достиг порога 80%. ' + next + ' Новый чат открывай только по прямой команде владельца.');
    state.prepareWarned = state.earlyWarned = true;
  } else if (pressure !== null && pressure >= EARLY && !state.earlyWarned) {
    messages.push('Последний измеренный вход достиг порога 75%. До следующей партии оцени, хватит ли окна на неё и резерв 20% для полного СТОП. Это замер последнего входа.');
    state.earlyWarned = true;
  }
  if (!state.batchWarned && scanBatch(input)) {
    if (pressure === null) {
      messages.push('Намечена большая партия сканов, метрика недоступна. До начала задай ограниченную контрольную точку и оцени запас на полный СТОП.');
    } else {
      messages.push('Намечена большая партия сканов. До её начала проверь, сохранится ли резерв 20% на полный СТОП. Если есть риск израсходовать резерв, уменьши партию или начни подготовку раньше.');
    }
    state.batchWarned = true;
  }
  const result = messages.length ? warn(event, messages.join(' ')) : {};
  const showCompaction = state.compactionNoticePending && (event === 'UserPromptSubmit' || event === 'PostToolUse');
  const showTransfer = state.transferReminderActive && !state.skipTransferNotice && (event === 'UserPromptSubmit' || showCompaction);
  if (showCompaction || showTransfer) {
    const notices = [];
    if (showTransfer) notices.push(TRANSFER_REMINDER);
    if (showCompaction) {
      notices.push(COMPACTION_NOTICE);
      delete state.compactionNoticePending;
    }
    const exception = showTransfer
      ? 'Определи по смыслу всего сообщения, есть ли прямая просьба перенести чат или выполнить СТОП. Если есть, в этом ответе пропусти напоминание о переносе, а строку о сжатии, если она ниже, сохрани. Упоминание команды, обсуждение или отказ от переноса сами по себе не считаются поручением.\n'
      : '';
    const instruction = exception + (showTransfer ? 'Начни ответ со следующего напоминания' : 'Начни ответ со следующего сообщения')
      + ' дословно и ровно один раз. Затем оставь пустую строку и дай основной ответ:\n' + notices.join('\n');
    result.hookSpecificOutput = {
      hookEventName: event,
      additionalContext: [...messages, instruction].join('\n\n'),
    };
  }
  return result;
}

function run(input, { stateDir = path.join(process.env.CODEX_HOME || path.join(os.homedir(), '.codex'), 'session-advisor-reserve') } = {}) {
  if (!EVENTS.has(input?.hook_event_name) || !input.session_id) return {};
  fs.mkdirSync(stateDir, { recursive: true });
  const key = crypto.createHash('sha256').update(String(input.session_id)).digest('hex');
  const stateFile = path.join(stateDir, key + '.json');
  const lock = stateFile + '.lock';
  try { fs.mkdirSync(lock); } catch { return {}; }
  try {
    let state = {};
    try { state = JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch { /* First event. */ }
    const original = JSON.stringify(state);
    const result = assess(input, state);
    const updated = JSON.stringify(state);
    if (updated !== original) {
      const temp = stateFile + '.' + process.pid + '.tmp';
      fs.writeFileSync(temp, updated);
      fs.renameSync(temp, stateFile);
    }
    return result;
  } finally {
    fs.rmdirSync(lock);
  }
}

module.exports = { run, metrics };
if (require.main === module) {
  try {
    process.stdout.write(JSON.stringify(run(JSON.parse(fs.readFileSync(0, 'utf8')))));
  } catch {
    process.stdout.write('{}');
  }
}
