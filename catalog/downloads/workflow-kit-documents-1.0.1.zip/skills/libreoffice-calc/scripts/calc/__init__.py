"""Calc skill package."""

from __future__ import annotations

from calc.core import create_spreadsheet, export_spreadsheet
from calc.patch import PatchApplyResult, patch
from patch_base import PatchOperationResult
from calc.session import CalcSession
from calc.snapshot import snapshot_area
from calc.targets import CalcTarget, CellFormatting, ChartSpec, ValidationRule

__all__ = [
    "create_spreadsheet",
    "export_spreadsheet",
    "snapshot_area",
    "CalcSession",
    "CalcTarget",
    "CellFormatting",
    "ValidationRule",
    "ChartSpec",
    "patch",
    "PatchApplyResult",
    "PatchOperationResult",
]
