"""Shared color name helpers for LibreOffice skills."""

from __future__ import annotations

from typing import Final


CSS_COLORS: Final[dict[str, int]] = {
    "pink": 0xFFC0CB,
    "lightpink": 0xFFB6C1,
    "hotpink": 0xFF69B4,
    "deeppink": 0xFF1493,
    "palevioletred": 0xDB7093,
    "mediumvioletred": 0xC71585,
    "lavender": 0xE6E6FA,
    "thistle": 0xD8BFD8,
    "plum": 0xDDA0DD,
    "orchid": 0xDA70D6,
    "violet": 0xEE82EE,
    "fuchsia": 0xFF00FF,
    "magenta": 0xFF00FF,
    "mediumorchid": 0xBA55D3,
    "darkorchid": 0x9932CC,
    "darkviolet": 0x9400D3,
    "blueviolet": 0x8A2BE2,
    "darkmagenta": 0x8B008B,
    "purple": 0x800080,
    "mediumpurple": 0x9370DB,
    "mediumslateblue": 0x7B68EE,
    "slateblue": 0x6A5ACD,
    "darkslateblue": 0x483D8B,
    "rebeccapurple": 0x663399,
    "indigo": 0x4B0082,
    "lightsalmon": 0xFFA07A,
    "salmon": 0xFA8072,
    "darksalmon": 0xE9967A,
    "lightcoral": 0xF08080,
    "indianred": 0xCD5C5C,
    "crimson": 0xDC143C,
    "red": 0xFF0000,
    "firebrick": 0xB22222,
    "darkred": 0x8B0000,
    "orange": 0xFFA500,
    "darkorange": 0xFF8C00,
    "coral": 0xFF7F50,
    "tomato": 0xFF6347,
    "orangered": 0xFF4500,
    "gold": 0xFFD700,
    "yellow": 0xFFFF00,
    "lightyellow": 0xFFFFE0,
    "lemonchiffon": 0xFFFACD,
    "lightgoldenrodyellow": 0xFAFAD2,
    "papayawhip": 0xFFEFD5,
    "moccasin": 0xFFE4B5,
    "peachpuff": 0xFFDAB9,
    "palegoldenrod": 0xEEE8AA,
    "khaki": 0xF0E68C,
    "darkkhaki": 0xBDB76B,
    "greenyellow": 0xADFF2F,
    "chartreuse": 0x7FFF00,
    "lawngreen": 0x7CFC00,
    "lime": 0x00FF00,
    "limegreen": 0x32CD32,
    "palegreen": 0x98FB98,
    "lightgreen": 0x90EE90,
    "mediumspringgreen": 0x00FA9A,
    "springgreen": 0x00FF7F,
    "mediumseagreen": 0x3CB371,
    "seagreen": 0x2E8B57,
    "forestgreen": 0x228B22,
    "green": 0x008000,
    "darkgreen": 0x006400,
    "yellowgreen": 0x9ACD32,
    "olivedrab": 0x6B8E23,
    "darkolivegreen": 0x556B2F,
    "mediumaquamarine": 0x66CDAA,
    "darkseagreen": 0x8FBC8F,
    "lightseagreen": 0x20B2AA,
    "darkcyan": 0x008B8B,
    "teal": 0x008080,
    "aqua": 0x00FFFF,
    "cyan": 0x00FFFF,
    "lightcyan": 0xE0FFFF,
    "paleturquoise": 0xAFEEEE,
    "aquamarine": 0x7FFFD4,
    "turquoise": 0x40E0D0,
    "mediumturquoise": 0x48D1CC,
    "darkturquoise": 0x00CED1,
    "cadetblue": 0x5F9EA0,
    "steelblue": 0x4682B4,
    "lightsteelblue": 0xB0C4DE,
    "lightblue": 0xADD8E6,
    "powderblue": 0xB0E0E6,
    "lightskyblue": 0x87CEFA,
    "skyblue": 0x87CEEB,
    "cornflowerblue": 0x6495ED,
    "deepskyblue": 0x00BFFF,
    "dodgerblue": 0x1E90FF,
    "royalblue": 0x4169E1,
    "blue": 0x0000FF,
    "mediumblue": 0x0000CD,
    "darkblue": 0x00008B,
    "navy": 0x000080,
    "midnightblue": 0x191970,
    "cornsilk": 0xFFF8DC,
    "blanchedalmond": 0xFFEBCD,
    "bisque": 0xFFE4C4,
    "navajowhite": 0xFFDEAD,
    "wheat": 0xF5DEB3,
    "burlywood": 0xDEB887,
    "tan": 0xD2B48C,
    "rosybrown": 0xBC8F8F,
    "sandybrown": 0xF4A460,
    "goldenrod": 0xDAA520,
    "darkgoldenrod": 0xB8860B,
    "peru": 0xCD853F,
    "chocolate": 0xD2691E,
    "olive": 0x808000,
    "saddlebrown": 0x8B4513,
    "sienna": 0xA0522D,
    "brown": 0xA52A2A,
    "maroon": 0x800000,
    "white": 0xFFFFFF,
    "snow": 0xFFFAFA,
    "honeydew": 0xF0FFF0,
    "mintcream": 0xF5FFFA,
    "azure": 0xF0FFFF,
    "aliceblue": 0xF0F8FF,
    "ghostwhite": 0xF8F8FF,
    "whitesmoke": 0xF5F5F5,
    "seashell": 0xFFF5EE,
    "beige": 0xF5F5DC,
    "oldlace": 0xFDF5E6,
    "floralwhite": 0xFFFAF0,
    "ivory": 0xFFFFF0,
    "antiquewhite": 0xFAEBD7,
    "linen": 0xFAF0E6,
    "lavenderblush": 0xFFF0F5,
    "mistyrose": 0xFFE4E1,
    "gainsboro": 0xDCDCDC,
    "lightgray": 0xD3D3D3,
    "silver": 0xC0C0C0,
    "darkgray": 0xA9A9A9,
    "dimgray": 0x696969,
    "gray": 0x808080,
    "lightslategray": 0x778899,
    "slategray": 0x708090,
    "darkslategray": 0x2F4F4F,
    "black": 0x000000,
}


def resolve_color(color: int | str) -> int:
    """Resolve a color name or integer to an RGB int.

    Args:
        color: 0xRRGGBB integer or a named color string.

    Returns:
        Color as 0xRRGGBB integer.

    Raises:
        ValueError: If the color name is unknown.
        TypeError: If color is not an int or str.
    """
    if isinstance(color, int):
        if color < 0 or color > 0xFFFFFF:
            raise ValueError(f"Color integer out of range: {color}")
        return color
    if not isinstance(color, str):
        raise TypeError("Color must be an int or color name string")

    key = color.strip().lower().replace(" ", "").replace("-", "").replace("_", "")
    if key in CSS_COLORS:
        return CSS_COLORS[key]
    raise ValueError(f"Unknown color name: {color}")
