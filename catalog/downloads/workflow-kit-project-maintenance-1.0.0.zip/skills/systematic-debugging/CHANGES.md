# Changes

[Upstream snapshot](https://github.com/obra/superpowers/tree/22f0b463e7a5e579904dd6211a520321035526f7/skills/systematic-debugging). Original upstream license and copyright notices retained.

The Codex edition adds local Windows instructions and preserves the source examples and MIT notice.
