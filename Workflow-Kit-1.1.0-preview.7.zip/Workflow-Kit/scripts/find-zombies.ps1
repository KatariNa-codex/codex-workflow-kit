﻿<#
.SYNOPSIS
  Ищет осиротевшие инструменты и серверы в Windows.

.DESCRIPTION
  Показывает процессы с известной сигнатурой, если их исходный родитель больше не жив.
  Принадлежность найденного процесса конкретной сессии требует проверки владельцем.

.PARAMETER Kill
  Остановить только процессы, явно указанные через ProcessId.

.PARAMETER ProcessId
  PID, выбранные владельцем из результата предыдущей проверки.

.PARAMETER MinAgeHours
  Показывать кандидатов старше N часов. По умолчанию 0 (все).

.EXAMPLE
  # посмотреть всё
  powershell -NoProfile -File find-zombies.ps1
  # После согласования остановить только процесс с PID 1234
  powershell -NoProfile -File find-zombies.ps1 -Kill -ProcessId 1234
#>
param(
    [switch]$Kill,
    [double]$MinAgeHours = 0,
    [int[]]$ProcessId = @()
)

$ErrorActionPreference = 'Stop'
if ($Kill -and -not $ProcessId.Count) { throw 'Для остановки передай выбранные PID через -ProcessId.' }
if (-not $Kill -and $ProcessId.Count) { throw 'Параметр -ProcessId используется вместе с -Kill.' }

# --- 1. Снимок всех процессов -------------------------------------------------
$all = Get-CimInstance Win32_Process |
    Select-Object ProcessId, ParentProcessId, Name, CommandLine, CreationDate
$byPid = @{}
foreach ($p in $all) { $byPid[[int]$p.ProcessId] = $p }

# PID переиспользуются, поэтому более новый процесс с тем же PID не родитель.
function Test-HasLiveParent {
    param($proc)
    $parent = $byPid[[int]$proc.ParentProcessId]
    return $null -ne $parent -and $parent.CreationDate -le $proc.CreationDate
}

# --- 3. Сигнатуры того, что вообще может быть мусором -------------------------
$shellTools = 'bash.exe', 'tail.exe', 'grep.exe', 'sed.exe', 'awk.exe', 'head.exe'

$serverPatterns = @(
    'http\.server', 'http-server', '\bserve\b',
    '\bnpm\b.*\b(run\s+)?(dev|start|serve)\b',
    '\bnext\s+dev\b', '\bvite\b', '\b(yarn|pnpm|bun)\s+dev\b',
    '\buvicorn\b', '\bgunicorn\b', '\bflask\s+run\b', '\bstreamlit\s+run\b',
    '\bngrok\b', '\bwebpack(-dev-server)?\b'
)
$serverRegex = ($serverPatterns -join '|')

# --- 4. Отбор -----------------------------------------------------------------
$suspects = foreach ($p in $all) {
    $cmd = if ($p.CommandLine) { $p.CommandLine -replace '\s+', ' ' } else { '' }
    $why = $null
    if ($shellTools -contains $p.Name) { $why = 'shell-tool' }
    elseif ($cmd -match $serverRegex)  { $why = 'dev-server' }
    if (-not $why) { continue }
    if (Test-HasLiveParent $p) { continue }
    $ageH = (New-TimeSpan -Start $p.CreationDate).TotalHours
    if ($ageH -lt $MinAgeHours) { continue }
    [PSCustomObject]@{
        PID     = [int]$p.ProcessId
        Name    = $p.Name
        Why     = $why
        Age     = '{0:0.0} ч' -f $ageH
        Started = $p.CreationDate
        Cmd     = if ($cmd.Length -gt 90) { $cmd.Substring(0, 90) + '…' } else { $cmd }
    }
}
$suspects = @($suspects | Sort-Object Started)

if ($Kill) {
    $ids = @($ProcessId | Sort-Object -Unique)
    $approved = @($suspects | Where-Object { $_.PID -in $ids })
    if ($approved.Count -ne $ids.Count) {
        $missing = @($ids | Where-Object { $_ -notin $approved.PID })
        throw ("Выбранные PID отсутствуют в текущем списке кандидатов: " + ($missing -join ', '))
    }
    foreach ($item in $approved) {
        $current = Get-CimInstance Win32_Process -Filter ("ProcessId = " + $item.PID)
        if (-not $current -or $current.CreationDate -ne $item.Started) {
            throw ("Процесс {0} завершился или его PID переиспользован." -f $item.PID)
        }
    }
    $suspects = $approved
}

# --- 5. Вывод -----------------------------------------------------------------
if ($suspects.Count -eq 0) {
    Write-Output 'Зомби-процессов не найдено.'
    return
}

# какие порты они держат
$listen = @{}
try {
    foreach ($c in (Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue)) {
        $listen[[int]$c.OwningProcess] = $c.LocalPort
    }
} catch { }

$suspects |
    Select-Object PID, Name, Why, Age,
                  @{n = 'Port'; e = { if ($listen.ContainsKey($_.PID)) { $listen[$_.PID] } else { '-' } } },
                  Cmd |
    Format-Table -AutoSize -Wrap

Write-Output ''
if ($Kill) {
    Write-Output ("Выбрано для остановки: {0}." -f $suspects.Count)
    Write-Output ''
    foreach ($s in $suspects) {
        try {
            Stop-Process -Id $s.PID -Force -ErrorAction Stop
            Write-Output ("  остановлен {0} ({1})" -f $s.PID, $s.Name)
        } catch {
            Write-Warning ("Не удалось остановить {0} ({1}): {2}" -f $s.PID, $s.Name, $_.Exception.Message)
        }
    }
} else {
    Write-Output ("Кандидатов: {0}. Для остановки передай выбранные PID с -Kill -ProcessId." -f $suspects.Count)
}
