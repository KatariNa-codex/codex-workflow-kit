#!/usr/bin/env python3
"""Проверка установки memory-kit. Ничего не меняет, только смотрит и отвечает «да» или «нет».

Ставил ли набор install.py или агент по INSTALL.md — итог проверяется одинаково, этим скриптом.
Настройки берутся из memory-kit.json рядом с папкой scripts, то есть из папки агента.

  python kit_check.py                     # проверить установку, в которой лежит этот файл
  python kit_check.py --kit <папка набора>   # заодно сверить файлы с набором байт в байт
  python kit_check.py --agent-dir ~/.codex   # проверить другую папку агента

Папку набора можно один раз записать в настройки ключом "kit_dir": тогда сверка идёт всегда.
Код возврата 0 — всё на месте, 1 — есть пункты «НЕТ».
"""
import argparse
import json
import os
import re
import shlex
import shutil
import subprocess
import sys

try:
    import tomllib
except ImportError:  # Python 3.8–3.10: support a top-level numeric limit.
    tomllib = None

# Те же списки, что в install.py; совпадение сторожит tests/test_hooks.py
HOOK_FILES = ["kit.js", "session-start-context.js", "session-summary-check.js", "memory-index-hook.py",
              "memory-recall-hook.py"]
SCRIPT_FILES = ["memory_index.py", "memory_search.py", "session_archive.py", "project_index.py", "kit_check.py",
                "memory_report.py", "memory_upkeep.py",
                "find-zombies.ps1"]
HOOKS_ALIVE = "memory-kit: хуки работают"
CODEX_RULES_MAX = 32 * 1024
HANDOFF_MAX_CHARS = 5000                       # те же бюджеты, что в hooks/session-start-context.js
HANDOFF_TIGHT_SHARE = 0.38

TOOLS = {
    "codex": {"hooks_file": "hooks.json", "rules": "AGENTS.md"},
}
# событие, файл хука, режим (последнее слово команды)
WANTED = {
    "codex": [("SessionStart", "session-start-context.js", ""), ("PreCompact", "session-start-context.js", "precompact"),
              ("Stop", "session-summary-check.js", ""),
              ("Stop", "memory-index-hook.py", "stop"),
              ("PreToolUse", "memory-recall-hook.py", "pre"), ("SubagentStart", "memory-recall-hook.py", "subagent"),
              ("UserPromptSubmit", "memory-recall-hook.py", "prompt")],
}


def say(text=""):
    print(text)


def read(path):
    with open(path, encoding="utf-8", errors="replace") as fh:
        return fh.read()


def same_bytes(a, b):
    """Файлы совпадают; перевод строк не в счёт (git на Windows меняет его сам)."""
    with open(a, "rb") as fa, open(b, "rb") as fb:
        return fa.read().replace(b"\r\n", b"\n") == fb.read().replace(b"\r\n", b"\n")


def matches_hook_command(command, expected):
    if not isinstance(command, str):
        return False
    try:
        actual = shlex.split(command.replace("\\", "/"))
        wanted = shlex.split(expected.replace("\\", "/"))
    except ValueError:
        return False
    if len(wanted) < 2 or len(actual) != len(wanted) or norm(actual[1]) != norm(wanted[1]):
        return False
    if actual[2:] != wanted[2:]:
        return False
    if os.path.normcase(actual[0]) == os.path.normcase(wanted[0]):
        return True
    launcher = os.path.basename(actual[0]).casefold()
    pattern = r"node(?:\.exe)?" if wanted[1].endswith(".js") else r"(?:python[0-9.]*|py)(?:\.exe)?"
    return re.fullmatch(pattern, launcher) is not None


def hook_registration_count(settings, event, matcher, expected_command):
    hooks = settings.get("hooks") or {} if isinstance(settings, dict) else {}
    groups = hooks.get(event) or [] if isinstance(hooks, dict) else []
    if not isinstance(groups, list):
        return 0
    return sum(
        1
        for group in groups
        if isinstance(group, dict) and group.get("matcher", "") == matcher and isinstance(group.get("hooks"), list)
        for handler in group["hooks"]
        if isinstance(handler, dict) and handler.get("type") == "command"
        and matches_hook_command(handler.get("command"), expected_command)
    )


def norm(path):
    return os.path.normcase(os.path.abspath(path)).replace("\\", "/")


def codex_project_rules_budget(agent_dir, cwd):
    """Estimate the project instruction chain from user config and the given cwd."""
    config = {}
    try:
        source = read(os.path.join(agent_dir, "config.toml"))
        if tomllib is not None:
            config = tomllib.loads(source)
        else:
            top_level = re.split(r"(?m)^\s*\[", source, maxsplit=1)[0]
            match = re.search(r"(?m)^\s*project_doc_max_bytes\s*=\s*(\d[0-9_]*)\s*(?:#.*)?$", top_level)
            if match:
                config["project_doc_max_bytes"] = int(match[1].replace("_", ""))
    except (OSError, ValueError):
        pass
    limit = config.get("project_doc_max_bytes", CODEX_RULES_MAX)
    if type(limit) is not int or limit < 0:
        limit = CODEX_RULES_MAX
    markers = config.get("project_root_markers", [".git"])
    names = ["AGENTS.override.md", "AGENTS.md"] + config.get("project_doc_fallback_filenames", [])
    directory = os.path.abspath(cwd)
    chain = []
    while True:
        chain.append(directory)
        if any(os.path.exists(os.path.join(directory, marker)) for marker in markers):
            break
        parent = os.path.dirname(directory)
        if parent == directory:
            chain = chain[:1]  # Outside a project, Codex only checks cwd.
            break
        directory = parent
    total = 0
    for directory in reversed(chain):
        for name in names:
            if not isinstance(name, str) or os.path.basename(name) != name:
                continue
            path = os.path.join(directory, name)
            if os.path.isfile(path):
                total += os.path.getsize(path)
                break
    return total, limit


def run(cmd, cwd=None, stdin=None):
    return subprocess.run(cmd, cwd=cwd, input=stdin, capture_output=True, text=True, encoding="utf-8",
                          errors="replace", env=dict(os.environ, PYTHONIOENCODING="utf-8"))


def main():
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    ap = argparse.ArgumentParser(description="Проверка установки memory-kit")
    ap.add_argument("--agent-dir", help="путь к профилю Codex, по умолчанию рядом с папкой scripts")
    ap.add_argument("--kit", help="папка набора: сверить установленные файлы с ней")
    args = ap.parse_args()

    agent_dir = os.path.abspath(os.path.expanduser(args.agent_dir)) if args.agent_dir else \
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    bad = 0
    warned = 0

    def line(ok, text):
        nonlocal bad
        bad += 0 if ok else 1
        say("  [%s] %s" % ("ок" if ok else "НЕТ", text))

    def warn(ok, text):
        """Установка цела, но агент получит не всё: в итог «НЕТ» не идёт."""
        nonlocal warned
        warned += 0 if ok else 1
        say("  [%s] %s" % ("ок" if ok else "!!", text))

    say("memory-kit: проверка %s" % agent_dir.replace("\\", "/"))
    cfg_path = os.path.join(agent_dir, "memory-kit.json")
    try:
        cfg = json.loads(read(cfg_path))
    except (OSError, ValueError) as e:
        line(False, "настройки memory-kit.json читаются (%s)" % type(e).__name__)
        say()
        say("Без настроек хуки молча ничего не делают. Дальше проверять нечего.")
        return 1
    line(True, "настройки memory-kit.json читаются")

    tool = cfg.get("tool")
    line(tool in TOOLS, "в настройках назван агент: %s" % tool)
    if tool not in TOOLS:
        return 1
    for key in ("root", "central"):
        value = cfg.get(key)
        line(bool(value) and os.path.isdir(os.path.expanduser(value)), "папка %s на месте: %s" % (key, value))
    line(bool(cfg.get("projects_dir")), "в настройках есть projects_dir: %s" % cfg.get("projects_dir"))   # самой папки до первой сессии может не быть
    central = os.path.expanduser(cfg.get("central") or "")
    root = os.path.expanduser(cfg.get("root") or "")
    line(os.path.exists(os.path.join(central, "MEMORY.head.md")), "шапка оглавления общей памяти MEMORY.head.md")

    kit = args.kit or cfg.get("kit_dir")
    kit = os.path.abspath(os.path.expanduser(kit)) if kit else None
    if kit and not os.path.isdir(os.path.join(kit, "hooks")):
        line(False, "папка набора на месте: %s" % kit)
        kit = None
    say("Файлы%s:" % (" (сверка с набором %s)" % kit.replace("\\", "/") if kit else ""))
    for sub, names in (("hooks", HOOK_FILES), ("scripts", SCRIPT_FILES)):
        for name in names:
            mine = os.path.join(agent_dir, sub, name)
            if not os.path.exists(mine):
                line(False, "%s/%s есть" % (sub, name))
            elif kit and os.path.exists(os.path.join(kit, sub, name)):
                line(same_bytes(mine, os.path.join(kit, sub, name)), "%s/%s совпадает с набором" % (sub, name))
            else:
                line(True, "%s/%s есть" % (sub, name))

    say("Хуки прописаны (%s):" % TOOLS[tool]["hooks_file"])
    try:
        settings = json.loads(read(os.path.join(agent_dir, TOOLS[tool]["hooks_file"])))
    except (OSError, ValueError):
        settings = {}
    for event, name, mode in WANTED[tool]:
        here = os.path.join(agent_dir, "hooks", name).replace("\\", "/")
        python = (sys.executable or "python").replace("\\", "/")
        parts = ["node" if name.endswith(".js") else python, here] + ([mode] if mode else [])
        count = hook_registration_count(settings, event, "Bash" if event == "PreToolUse" else "", shlex.join(parts))
        label = "%s → %s%s" % (event, name, " " + mode if mode else "")
        line(count == 1, label + (" (дублируется)" if count > 1 else ""))

    def matches_kit(*paths):
        return kit and all(os.path.isfile(os.path.join(agent_dir, name))
                           and os.path.isfile(os.path.join(kit, name))
                           and same_bytes(os.path.join(agent_dir, name), os.path.join(kit, name))
                           for name in paths)

    try:
        supports_safe_check = bool(kit) and json.loads(read(os.path.join(kit, "release.json"))).get("readOnlyStartupCheck") is True
    except (OSError, ValueError, AttributeError):
        supports_safe_check = False
    say("Хуки отвечают:")
    if shutil.which("node"):
        if supports_safe_check and matches_kit("hooks/session-start-context.js", "hooks/kit.js"):
            r = run(["node", os.path.join(agent_dir, "hooks", "session-start-context.js"), "check"], cwd=root or None, stdin="{}")
            try:
                ctx = json.loads(r.stdout)["hookSpecificOutput"]["additionalContext"]
            except (ValueError, KeyError, TypeError):
                ctx = ""
            line(r.returncode == 0 and HOOKS_ALIVE in ctx, "хук начала сессии отдаёт метку «%s»" % HOOKS_ALIVE)
        else:
            line(False, "хук отличается от набора с режимом проверки без записи, запуск пропущен")
    else:
        line(False, "node установлен (без него хук начала сессии не работает)")
    if matches_kit("scripts/memory_index.py"):
        r = run([sys.executable, "-B", os.path.join(agent_dir, "scripts", "memory_index.py"), central, "--dry"])
        line(r.returncode == 0, "сборщик оглавления: " + (r.stdout + r.stderr).strip()[:160])
    if matches_kit("scripts/memory_search.py"):
        r = run([sys.executable, "-B", os.path.join(agent_dir, "scripts", "memory_search.py"), "проверка"])
        line(r.returncode == 0, "поиск по памяти запускается")
    if matches_kit("hooks/memory-recall-hook.py"):
        probe = json.dumps({"session_id": "kit-check", "cwd": root, "tool_name": "Bash", "tool_input": {"command": "echo 1"}})
        r = run([sys.executable, "-B", os.path.join(agent_dir, "hooks", "memory-recall-hook.py"), "pre"], stdin=probe)
        line(r.returncode == 0 and not r.stdout.strip(), "хук подсказки молчит на обычной команде")

    if tool == "codex":
        say("Правила Codex:")
        total, limit = codex_project_rules_budget(agent_dir, root)
        line(total <= limit, "проектные правила для %s влезают в потолок Codex: %d из %d байт"
             % (root, total, limit))

    say("Что агент получит на старте:")
    rules_text = ""
    for path in (os.path.join(agent_dir, TOOLS[tool]["rules"]), os.path.join(root, TOOLS[tool]["rules"])):
        if os.path.exists(path):
            rules_text += read(path)
    warn(HOOKS_ALIVE in rules_text, "в правилах агента есть проверка метки «%s»: без неё он не скажет, что хуки молчат"
         % HOOKS_ALIVE)
    warn("memory_search" in rules_text, "в правилах агента есть команда поиска по памяти")

    tight = int(cfg.get("start_max_chars") or 0)
    limit = round(tight * HANDOFF_TIGHT_SHARE) if tight else HANDOFF_MAX_CHARS
    projects = [root] + [os.path.join(root, n) for n in sorted(os.listdir(root))] if os.path.isdir(root) else []
    long_notes = []
    for p in projects:
        note = os.path.join(p, "HANDOFF.md")
        if os.path.isfile(note):
            size = len(read(note).strip())
            if size > limit:
                long_notes.append("%s: %d" % (os.path.basename(p), size))
    warn(not long_notes, "записки HANDOFF влезают в старт (до %d знаков)%s" % (
        limit, "; длиннее: " + ", ".join(long_notes[:5]) + (" и ещё %d" % (len(long_notes) - 5) if len(long_notes) > 5 else "")
        + ". Конец такой записки агент видит, только если откроет файл" if long_notes else ""))

    if cfg.get("journal_path") and shutil.which("node") and matches_kit("hooks/kit.js"):
        here = os.getcwd()
        result = run(["node", os.path.join(agent_dir, "hooks", "kit.js"), "--project-locations", here], cwd=here)
        try:
            paths = json.loads(result.stdout) if result.returncode == 0 else {}
        except ValueError:
            paths = {}
        if paths.get("journalOverride"):
            journal = paths["journalFile"]
            warn(os.path.isfile(journal), "свой журнал найден для папки %s: %s"
                 % (os.path.basename(paths["project"]), journal))

    say()
    if not bad and warned:
        say("Предупреждений: %d. Установка цела, но разберись с ними: агент получит не всё." % warned)
    say("Всё на месте." if not bad else "Пунктов «НЕТ»: %d. Исправь их и запусти проверку ещё раз." % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
